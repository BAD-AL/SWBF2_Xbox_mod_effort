--.\at6g_hero.lua
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("setup_teams")
ALL = 1
IMP = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
TDM = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, multiplayerScoreLimit = 100, textATT = "game.modes.tdm", textDEF = "game.modes.tdm2", multiplayerRules = false, isCelebrityDeathmatch = false })
TDM:Start()
AddAIGoal(1,"Deathmatch",100)
AddAIGoal(2,"Deathmatch",100)
end

function ScriptInit()
ReadDataFile("ingame.lvl")
SetPS2ModelMemory(5556000)
SetMaxFlyHeight(40)
SetMaxPlayerFlyHeight(40)
ReadDataFile("sound\\chr.lvl;commando_gcw")
ReadDataFile("sound\\dag.lvl;dag1gcw")
ReadDataFile("sound\\BS1.lvl;BS1gcw")
ReadDataFile("SIDE\\all.lvl","all_hero_chewbacca","all_hero_leia")
ReadDataFile("SIDE\\imp.lvl","imp_hero_bobafett")
ReadDataFile("SIDE\\cis.lvl","cis_hero_jangofett")
ReadDataFile("SIDE\\heroes.lvl","all_hero_dashrendar","all_hero_hansolo_tat","all_hero_jodokast","all_hero_lando","cis_hero_cad_bane","cis_hero_durge","imp_hero_bossk","imp_hero_greedo","imp_hero_ig88","imp_hero_thrawn","rep_inf_HD_Captain_Rex","rep_inf_commander_cody")
SetupTeams({ 
hero = { team = ALL, units = 12, reinforcements = -1, 
soldier = { "all_hero_hansolo_tat", 1, 2 }, 
assault = { "all_hero_chewbacca", 1, 2 }, 
engineer = { "all_hero_jodokast", 1, 2 }, 
sniper = { "all_hero_leia", 1, 2 }, 
officer = { "rep_inf_commander_cody", 1, 2 }, 
special = { "all_hero_dashrendar", 1, 2 } }, 
villain = { team = IMP, units = 12, reinforcements = -1, 
soldier = { "imp_hero_bobafett", 1, 2 }, 
assault = { "imp_hero_greedo", 1, 2 }, 
engineer = { "imp_hero_thrawn", 1, 2 }, 
sniper = { "cis_hero_jangofett", 1, 2 }, 
officer = { "cis_hero_durge", 1, 2 }, 
special = { "imp_hero_bossk", 1, 2 } } })
AddUnitClass(ALL,"rep_inf_HD_Captain_Rex",1,2)
AddUnitClass(ALL,"all_hero_lando",1,2)
AddUnitClass(IMP,"cis_hero_cad_bane",1,2)
AddUnitClass(IMP,"imp_hero_ig88",1,2)
AddWalkerType(0,4)
AddWalkerType(1,0)
AddWalkerType(2,0)
AddWalkerType(3,0)
SetMemoryPoolSize("Aimer",75)
SetMemoryPoolSize("AmmoCounter",1024)
SetMemoryPoolSize("BaseHint",1024)
SetMemoryPoolSize("ClothData",20)
SetMemoryPoolSize("EnergyBar",1024)
SetMemoryPoolSize("EntityCloth",32)
SetMemoryPoolSize("EntityFlyer",32)
SetMemoryPoolSize("EntityHover",4)
SetMemoryPoolSize("EntityLight",200)
SetMemoryPoolSize("EntitySoundStream",15)
SetMemoryPoolSize("EntitySoundStatic",70)
SetMemoryPoolSize("MountedTurret",32)
SetMemoryPoolSize("Navigator",128)
SetMemoryPoolSize("Obstacle",1024)
SetMemoryPoolSize("PathNode",1024)
SetMemoryPoolSize("SoldierAnimation",700)
SetMemoryPoolSize("SoundSpaceRegion",64)
SetMemoryPoolSize("TreeGridStack",1024)
SetMemoryPoolSize("UnitAgent",128)
SetMemoryPoolSize("UnitController",128)
SetMemoryPoolSize("Weapon",1024)
SetMemoryPoolSize("SoldierAnimation",500)
SetSpawnDelay(10,0.25)
ReadDataFile("AT6\\kas1.lvl","kashyyyk1_eli")
SetDenseEnvironment("false")
SetNumBirdTypes(1)
SetBirdType(0,1,"bird")
SetNumFishTypes(1)
SetFishType(0,0.80000001192093,"fish")
ScriptCB_EnableHeroMusic(0)
ScriptCB_EnableHeroVO(0)
voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
OpenAudioStream("sound\\global.lvl","gcw_music")
OpenAudioStream("sound\\tat.lvl","tat2")
SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
SetOutOfBoundsVoiceOver(1,"Allleaving")
SetOutOfBoundsVoiceOver(2,"Impleaving")
SetAmbientMusic(ALL,1,"gen_amb_celebDeathmatch",0,1)
SetAmbientMusic(IMP,1,"gen_amb_celebDeathmatch",0,1)
SetVictoryMusic(ALL,"all_dag_amb_victory")
SetDefeatMusic(ALL,"all_dag_amb_defeat")
SetVictoryMusic(IMP,"imp_dag_amb_victory")
SetDefeatMusic(IMP,"imp_dag_amb_defeat")
SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
SetAttackingTeam(ATT)
AddCameraShot(-0.42113700509071,0.025737000629306,-0.90494298934937,-0.055303998291492,216.39184570313,-19.422512054443,-249.23191833496)
AddCameraShot(0.70141100883484,0.0376220010221,-0.71074199676514,0.038123000413179,49.056308746338,-29.080774307251,-87.605171203613)
AddCameraShot(0.91685402393341,-0.0052620000205934,0.39918100833893,0.002290999982506,222.26936340332,-30.438093185425,-130.60954284668)
end

