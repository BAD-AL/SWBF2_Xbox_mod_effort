--.\kam2g_con.lua
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
ALL = 1
IMP = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
cp1 = CommandPost:New({ name = "CP10" })
cp2 = CommandPost:New({ name = "CP11" })
cp3 = CommandPost:New({ name = "CP12" })
cp4 = CommandPost:New({ name = "CP13" })
cp5 = CommandPost:New({ name = "CP2" })
cp6 = CommandPost:New({ name = "CP4" })
cp7 = CommandPost:New({ name = "CP5" })
conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = false })
conquest:AddCommandPost(cp1)
conquest:AddCommandPost(cp2)
conquest:AddCommandPost(cp3)
conquest:AddCommandPost(cp4)
conquest:AddCommandPost(cp5)
conquest:AddCommandPost(cp6)
conquest:AddCommandPost(cp7)
conquest:Start()
EnableSPHeroRules()
end

function ScriptInit()
ReadDataFile("ingame.lvl")
SetPS2ModelMemory(4056000)
ReadDataFile("sound\\chr.lvl;commando_gcw")
ReadDataFile("sound\\kam.lvl;kam1gcw")
SetMinFlyHeight(60)
SetAllowBlindJetJumps(0)
SetMaxFlyHeight(102)
SetMaxPlayerFlyHeight(102)
ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_urban","all_inf_rocketeer_fleet","all_inf_sniper_fleet","all_inf_engineer_fleet","all_inf_wookiee","all_inf_officer")
ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_bobafett")
ReadDataFile("SIDE\\tur.lvl","tur_bldg_chaingun_roof","tur_weap_built_gunturret")
ReadDataFile("SIDE\\infantry.lvl","all_inf_specialops","imp_inf_commando")
ReadDataFile("SIDE\\heroes.lvl","all_hero_hansolo_tat")
SetupTeams({ 
all = { team = ALL, units = 32, reinforcements = 150, 
soldier = { "all_inf_rifleman_urban", 9, 25 }, 
assault = { "all_inf_rocketeer_fleet", 1, 4 }, 
engineer = { "all_inf_engineer_fleet", 1, 4 }, 
sniper = { "all_inf_sniper_fleet", 1, 4 }, 
officer = { "all_inf_officer", 1, 4 }, 
special = { "all_inf_wookiee", 1, 4 } }, 
imp = { team = IMP, units = 32, reinforcements = 150, 
soldier = { "imp_inf_rifleman", 9, 25 }, 
assault = { "imp_inf_rocketeer", 1, 4 }, 
engineer = { "imp_inf_engineer", 1, 4 }, 
sniper = { "imp_inf_sniper", 1, 4 }, 
officer = { "imp_inf_officer", 1, 4 }, 
special = { "imp_inf_dark_trooper", 1, 4 } } })
AddUnitClass(ALL,"all_inf_specialops",1,2)
AddUnitClass(IMP,"imp_inf_commando",1,2)
SetHeroClass(ALL,"all_hero_hansolo_tat")
SetHeroClass(IMP,"imp_hero_bobafett")
ClearWalkers()
SetMemoryPoolSize("EntityCloth",33)
SetMemoryPoolSize("EntityLight",64)
SetMemoryPoolSize("Obstacle",800)
SetMemoryPoolSize("EntitySoundStream",3)
SetMemoryPoolSize("SoundSpaceRegion",36)
SetMemoryPoolSize("EntitySoundStatic",85)
SetMemoryPoolSize("Weapon",260)
SetMemoryPoolSize("EntityFlyer",6)
SetSpawnDelay(10,0.25)
ReadDataFile("kam\\kam2.lvl","kamino1_Conquest")
SetDenseEnvironment("false")
voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
OpenAudioStream("sound\\global.lvl","gcw_music")
OpenAudioStream("sound\\kam.lvl","kam1")
OpenAudioStream("sound\\kam.lvl","kam1")
SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
SetOutOfBoundsVoiceOver(1,"allleaving")
SetOutOfBoundsVoiceOver(2,"impleaving")
SetAmbientMusic(ALL,1,"all_kam_amb_start",0,1)
SetAmbientMusic(ALL,0.80000001192093,"all_kam_amb_middle",1,1)
SetAmbientMusic(ALL,0.20000000298023,"all_kam_amb_end",2,1)
SetAmbientMusic(IMP,1,"imp_kam_amb_start",0,1)
SetAmbientMusic(IMP,0.80000001192093,"imp_kam_amb_middle",1,1)
SetAmbientMusic(IMP,0.20000000298023,"imp_kam_amb_end",2,1)
SetVictoryMusic(ALL,"all_kam_amb_victory")
SetDefeatMusic(ALL,"all_kam_amb_defeat")
SetVictoryMusic(IMP,"imp_kam_amb_victory")
SetDefeatMusic(IMP,"imp_kam_amb_defeat")
SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
SetAttackingTeam(ATT)
AddDeathRegion("deathregion")
AddCameraShot(0.19047799706459,-0.010944999754429,-0.98001402616501,-0.056311998516321,-26.091287612915,55.96501159668,159.45809936523)
AddCameraShot(-0.37657099962234,-0.019636999815702,-0.92492300271988,0.04823200032115,176.04246520996,53.957565307617,244.26113891602)
AddCameraShot(0.63925397396088,-0.073532998561859,0.76045697927475,0.087475001811981,78.395347595215,72.538581848145,344.08660888672)
end

