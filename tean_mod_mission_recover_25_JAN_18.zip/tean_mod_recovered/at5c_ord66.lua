--.\at5c_ord66.lua
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("setup_teams")
REP = 1
JED = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
SetProperty("cp1","CaptureRegion","")
SetProperty("cp3","CaptureRegion","")
SetProperty("cp4","CaptureRegion","")
SetProperty("cp5","CaptureRegion","")
SetProperty("cp10","CaptureRegion","")
SetProperty("cp11","CaptureRegion","")
SetProperty("cp1","Team","1")
SetProperty("cp3","Team","2")
SetProperty("cp4","Team","1")
SetProperty("cp5","Team","2")
SetProperty("cp10","Team","1")
SetProperty("cp11","Team","2")
SetProperty("cp2","Team","0")
SetProperty("cp2","CaptureRegion","")
SetProperty("cp2","MapScale","0.0")
TDM = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, multiplayerScoreLimit = 75, textATT = "game.modes.tdm", textDEF = "game.modes.tdm2", multiplayerRules = false, isCelebrityDeathmatch = false })
TDM:Start()
end

function ScriptInit()
SetPS2ModelMemory(6056000)
ReadDataFile("ingame.lvl")
SetMaxFlyHeight(70)
SetMaxPlayerFlyHeight(70)
ReadDataFile("sound\\chr.lvl;commando")
ReadDataFile("sound\\kas.lvl;kas2cw")
SetMemoryPoolSize("ClothData",20)
SetMemoryPoolSize("Combo",15)
SetMemoryPoolSize("Combo::State",250)
SetMemoryPoolSize("Combo::Transition",300)
SetMemoryPoolSize("Combo::Condition",300)
SetMemoryPoolSize("Combo::Attack",250)
SetMemoryPoolSize("Combo::DamageSample",10000)
SetMemoryPoolSize("Combo::Deflect",150)
ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper")
ReadDataFile("SIDE\\jed.lvl","jed_knight_01","jed_knight_02","jed_knight_03","jed_knight_04")
ReadDataFile("SIDE\\infantry.lvl","rep_inf_commando","jed_knight_10","jed_knight_13","jed_knight_14")
SetupTeams({ 
rep = { team = REP, units = 32, reinforcements = -1, 
soldier = { "rep_inf_ep3_rifleman", 13, 16 }, 
assault = { "rep_inf_ep3_rocketeer", 5, 4 }, 
engineer = { "rep_inf_ep3_engineer", 3, 4 }, 
sniper = { "rep_inf_ep3_sniper", 2, 4 }, 
officer = { "rep_inf_ep3_officer", 2, 4 }, 
special = { "rep_inf_ep3_jettrooper", 2, 4 } }, 
jedi = { team = JED, units = 15, reinforcements = -1, 
soldier = { "jed_knight_01", 4, 6 }, 
assault = { "jed_knight_02", 4, 6 }, 
engineer = { "jed_knight_03", 3, 6 }, 
sniper = { "jed_knight_04", 2, 6 }, 
officer = { "jed_knight_10", 1, 1 }, 
special = { "jed_knight_13", 1, 1 } } })
SetTeamName(JED,"jedi")
AddUnitClass(REP,"rep_inf_commando",1,2)
AddUnitClass(JED,"jed_knight_14",1,2)
ClearWalkers()
SetMemoryPoolSize("Aimer",100)
SetMemoryPoolSize("BaseHint",240)
SetMemoryPoolSize("EntityFlyer",6)
SetMemoryPoolSize("EntityCloth",80)
SetMemoryPoolSize("EntityHover",15)
SetMemoryPoolSize("EntityLight",60)
SetMemoryPoolSize("MountedTurret",20)
SetMemoryPoolSize("Obstacle",590)
SetMemoryPoolSize("PathNode",512)
SetMemoryPoolSize("TentacleSimulator",22)
SetMemoryPoolSize("TreeGridStack",300)
SetMemoryPoolSize("Weapon",265)
SetMemoryPoolSize("EntitySoundStream",15)
SetMemoryPoolSize("EntitySoundStatic",70)
SetMemoryPoolSize("SoldierAnimation",1000)
SetSpawnDelay(10,0.25)
ReadDataFile("AT5\\kas2.lvl","kas2_conquest")
SetDenseEnvironment("false")
SetNumBirdTypes(1)
SetBirdType(0,1,"bird")
SetNumFishTypes(1)
SetFishType(0,0.80000001192093,"fish")
voiceSlow = OpenAudioStream("sound\\global.lvl","cor_objective_vo_slow")
AudioStreamAppendSegments("sound\\global.lvl","rep_unit_vo_slow",voiceSlow)
AudioStreamAppendSegments("sound\\global.lvl","all_unit_vo_slow",voiceSlow)
AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
AudioStreamAppendSegments("sound\\global.lvl","rep_unit_vo_quick",voiceQuick)
AudioStreamAppendSegments("sound\\global.lvl","global_vo_quick",voiceQuick)
OpenAudioStream("sound\\global.lvl","cw_music")
OpenAudioStream("sound\\kas.lvl","kas")
SetOutOfBoundsVoiceOver(1,"repleaving")
SetOutOfBoundsVoiceOver(2,"allleaving")
SetVictoryMusic(REP,"rep_kas_amb_victory")
SetDefeatMusic(REP,"rep_kas_amb_defeat")
SetVictoryMusic(JED,"all_kas_amb_victory")
SetDefeatMusic(JED,"all_kas_amb_defeat")
SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
SetAttackingTeam(ATT)
AddCameraShot(-0.42113700509071,0.025737000629306,-0.90494298934937,-0.055303998291492,216.39184570313,-19.422512054443,-249.23191833496)
AddCameraShot(0.70141100883484,0.0376220010221,-0.71074199676514,0.038123000413179,49.056308746338,-29.080774307251,-87.605171203613)
AddCameraShot(0.91685402393341,-0.0052620000205934,0.39918100833893,0.002290999982506,222.26936340332,-30.438093185425,-130.60954284668)
end

