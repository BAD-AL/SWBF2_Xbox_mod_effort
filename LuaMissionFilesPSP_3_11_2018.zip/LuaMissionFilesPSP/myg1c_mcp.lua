-- myg1c_mcp.lua
-- Verified
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveAssault")
ScriptCB_DoFile("MultiObjectiveContainer")
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("Ambush")
REP = 1
IMP = 2
locals = 3
ATT = 1
DEF = 2

function ScriptPostLoad()
    EnableSPHeroRules()
    missiontimer = CreateTimer("missiontimer")
    SetTimerValue(missiontimer, 300)
    StartTimer(missiontimer)
    ShowTimer(missiontimer)
    OnTimerElapse(
        function()
            MissionVictory(DEF)
        end,
        "missiontimer"
    )
    DisableBarriers("dropship")
    DisableBarriers("shield_03")
    DisableBarriers("shield_02")
    DisableBarriers("shield_01")
    DisableBarriers("ctf")
    DisableBarriers("ctf1")
    DisableBarriers("ctf2")
    DisableBarriers("ctf3")
    fourminremains = CreateTimer("fourminremains")
    SetTimerValue(fourminremains, 60)
    threeminremains = CreateTimer("threeminremains")
    SetTimerValue(threeminremains, 120)
    twominremains = CreateTimer("twominremains")
    SetTimerValue(twominremains, 180)
    oneminremains = CreateTimer("oneminremains")
    SetTimerValue(oneminremains, 240)
    thirtysecremains = CreateTimer("thirtysecremains")
    SetTimerValue(thirtysecremains, 270)
    tensecremains = CreateTimer("tensecremains")
    SetTimerValue(tensecremains, 290)
    StartTimer(fourminremains)
    StartTimer(threeminremains)
    StartTimer(twominremains)
    StartTimer(oneminremains)
    StartTimer(thirtysecremains)
    StartTimer(tensecremains)
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.4min")
        end,
        "fourminremains"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.3min")
        end,
        "threeminremains"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.2min")
        end,
        "twominremains"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.1min")
        end,
        "oneminremains"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.30sec")
        end,
        "thirtysecremains"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.10sec")
        end,
        "tensecremains"
    )
    fourminremains1 = CreateTimer("fourminremains1")
    SetTimerValue(fourminremains1, 60)
    threeminremains1 = CreateTimer("threeminremains1")
    SetTimerValue(threeminremains1, 120)
    twominremains1 = CreateTimer("twominremains1")
    SetTimerValue(twominremains1, 180)
    oneminremains1 = CreateTimer("oneminremains1")
    SetTimerValue(oneminremains1, 240)
    thirtysecremains1 = CreateTimer("thirtysecremains1")
    SetTimerValue(thirtysecremains1, 270)
    tensecremains1 = CreateTimer("tensecremains1")
    SetTimerValue(tensecremains1, 290)
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.4min")
        end,
        "fourminremains1"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.3min")
        end,
        "threeminremains1"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.2min")
        end,
        "twominremains1"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.1min")
        end,
        "oneminremains1"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.30sec")
        end,
        "thirtysecremains1"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.10sec")
        end,
        "tensecremains1"
    )
    AAB_count = 6
    AAB = TargetType:New({classname = "imp_inf_officer", killLimit = 6})

    AAB.OnDestroy = function(OnDestroyParam0, OnDestroyParam1)
        AAB_count = AAB_count - 1
        if AAB_count <= 2 then
            ShowMessageText("level.myg1c_s.merc.2-" .. AAB_count, ATT)
        end
    end

    Objective1 =
        ObjectiveAssault:New(
        {
            teamATT = ATT,
            teamDEF = DEF,
            AIGoalWeight = 1,
            textATT = "level.dag1g_m.merc.enda",
            popupText = "level.dag1g_m.merc.popup2"
        }
    )
    Objective1:AddTarget(AAB)

    Objective1.OnComplete = function(OnCompleteParam0)
        StartTimer(missiontimer3)
        StopTimer(fiveminremains)
        StopTimer(fourminremains)
        StopTimer(threeminremains)
        StopTimer(twominremains)
        StopTimer(oneminremains)
        StopTimer(thirtysecremains)
        StopTimer(tensecremains)
    end
    AAT_count = 6
    AAT = TargetType:New({classname = "imp_inf_officer", killLimit = 6})

    AAT.OnDestroy = function(OnDestroyParam0, OnDestroyParam1)
        AAT_count = AAT_count - 1
        if AAT_count <= 2 then
            ShowMessageText("level.myg1c_s.merc.1-" .. AAT_count, ATT)
        end
    end

    Objective2 =
        ObjectiveAssault:New({teamATT = ATT, teamDEF = DEF, AIGoalWeight = 1, textATT = "level.dag1g_m.merc.end2a"})
    Objective2:AddTarget(AAT)

    Objective2.OnComplete = function(OnCompleteParam0)
        MissionVictory(ATT)
    end

    TDM = ObjectiveTDM:New({teamATT = 1, teamDEF = 2, textATT = "level.dag1g_m.merc.merc1", multiplayerRules = true})
    missiontimer2 = CreateTimer("missiontimer2")
    SetTimerValue(missiontimer2, 1)
    StartTimer(missiontimer2)
    OnTimerElapse(
        function()
            Ambush("off_path", 3, 3)
            Ambush("target2", 3, 3)
            AddAIGoal(3, "Deathmatch", 9999)
            AddAIGoal(2, "Deathmatch", 2)
            followguy1 = GetTeamMember(3, 0)
            followthatguy1 = AddAIGoal(2, "Follow", 3, followguy1)
            followguy2 = GetTeamMember(3, 1)
            followthatguy2 = AddAIGoal(2, "Follow", 3, followguy2)
            followguy3 = GetTeamMember(3, 2)
            followthatguy3 = AddAIGoal(2, "Follow", 3, followguy3)
            SetAIDifficulty(2, 8, "medium")
            SetAIDifficulty(3, 9, "medium")
        end,
        "missiontimer2"
    )
    missiontimer3 = CreateTimer("missiontimer3")
    SetTimerValue(missiontimer3, 1)
    OnTimerElapse(
        function()
            Ambush("target2", 3, 3)
            Ambush("off_path", 3, 3)
            AddAIGoal(locals, "Deathmatch", 9999)
            AddAIGoal(2, "Deathmatch", 2)
            followguy4 = GetTeamMember(3, 3)
            followthatguy4 = AddAIGoal(2, "Follow", 3, followguy4)
            followguy5 = GetTeamMember(3, 4)
            followthatguy5 = AddAIGoal(2, "Follow", 3, followguy5)
            followguy6 = GetTeamMember(3, 5)
            followthatguy6 = AddAIGoal(2, "Follow", 3, followguy6)
            SetTimerValue(missiontimer, 300)
            StartTimer(fourminremains1)
            StartTimer(threeminremains1)
            StartTimer(twominremains1)
            StartTimer(oneminremains1)
            StartTimer(thirtysecremains1)
            StartTimer(tensecremains1)
            SetAIDifficulty(2, 8, "medium")
            SetAIDifficulty(3, 9, "medium")
        end,
        "missiontimer3"
    )
    objectiveSequence = MultiObjectiveContainer:New({})
    objectiveSequence:AddObjectiveSet(Objective1)
    objectiveSequence:AddObjectiveSet(Objective2)
    objectiveSequence:AddObjectiveSet(TDM)
    objectiveSequence:Start()
end

function ScriptInit()
    StealArtistHeap(155000)
    if ScriptCB_GetPlatform() == "PSP" then
        SetPSPModelMemory(2978689)
        SetPSPClipper(0)
    else
        SetPS2ModelMemory(4100000)
    end
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\myg.lvl;myg1gcw")
    SetMaxFlyHeight(20)
    SetMaxPlayerFlyHeight(20)
    ReadDataFile("SIDE\\rep.lvl", "rep_inf_ep2_jettrooper_rifleman2")
    ReadDataFile(
        "SIDE\\imp.lvl",
        "imp_inf_rifleman",
        "imp_inf_sniper",
        "imp_inf_dark_trooper",
        "imp_inf_officer",
        "imp_hero_bobafett"
    )
    ReadDataFile("SIDE\\tur.lvl", "tur_bldg_recoilless_lg")
    ClearWalkers()
    AddWalkerType(0, 4)
    AddWalkerType(2, 0)
    local weaponCnt = 165
    SetMemoryPoolSize("Aimer", 65)
    SetMemoryPoolSize("AmmoCounter", weaponCnt)
    SetMemoryPoolSize("BaseHint", 250)
    SetMemoryPoolSize("EnergyBar", weaponCnt)
    SetMemoryPoolSize("EntityCloth", 17)
    SetMemoryPoolSize("EntityHover", 8)
    SetMemoryPoolSize("EntitySoundStream", 1)
    SetMemoryPoolSize("EntitySoundStatic", 0)
    SetMemoryPoolSize("EntityFlyer", 6)
    SetMemoryPoolSize("FlagItem", 2)
    SetMemoryPoolSize("MountedTurret", 13)
    SetMemoryPoolSize("Navigator", 50)
    SetMemoryPoolSize("Obstacle", 460)
    SetMemoryPoolSize("PathFollower", 50)
    SetMemoryPoolSize("PathNode", 128)
    SetMemoryPoolSize("TentacleSimulator", 0)
    SetMemoryPoolSize("TreeGridStack", 300)
    SetMemoryPoolSize("Weapon", weaponCnt)
    SetSpawnDelay(10, 0.25)
    ReadDataFile("myg\\myg1.lvl", "myg1_merc")
    SetDenseEnvironment("false")
    AddDeathRegion("deathregion")
    SetTeamName(REP, "Republic")
    SetTeamIcon(REP, "rep_icon")
    AddUnitClass(REP, "rep_inf_ep2_jettrooper_rifleman2", 1)
    SetHeroClass(REP, "imp_hero_bobafett")
    SetTeamName(IMP, "IMP")
    SetTeamIcon(IMP, "IMP_icon")
    AddUnitClass(IMP, "imp_inf_rifleman", 6)
    AddUnitClass(IMP, "imp_inf_sniper", 3)
    AddUnitClass(IMP, "imp_inf_dark_trooper", 3)
    SetUnitCount(ATT, 4)
    SetReinforcementCount(ATT, -1)
    SetUnitCount(DEF, 12)
    SetReinforcementCount(DEF, -1)
    ForceHumansOntoTeam1()
    SetTeamName(locals, "IMP")
    AddUnitClass(locals, "imp_inf_officer", 12)
    SetUnitCount(locals, 12)
    SetTeamAsFriend(locals, IMP)
    SetTeamAsFriend(IMP, locals)
    SetTeamAsEnemy(locals, REP)
    SetTeamAsEnemy(REP, locals)
    SetReinforcementCount(locals, 12)
    OpenAudioStream("sound\\global.lvl", "gcw_music")
    SetAmbientMusic(1, 1, "all_myg_amb_start", 0, 1)
    SetAmbientMusic(1, 0.80000001192093, "all_myg_amb_middle", 1, 1)
    SetAmbientMusic(1, 0.20000000298023, "all_myg_amb_end", 2, 1)
    SetAmbientMusic(IMP, 1, "imp_myg_amb_start", 0, 1)
    SetAmbientMusic(IMP, 0.80000001192093, "imp_myg_amb_middle", 1, 1)
    SetAmbientMusic(IMP, 0.20000000298023, "imp_myg_amb_end", 2, 1)
    SetVictoryMusic(1, "all_myg_amb_victory")
    SetDefeatMusic(1, "all_myg_amb_defeat")
    SetVictoryMusic(IMP, "imp_myg_amb_victory")
    SetDefeatMusic(IMP, "imp_myg_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(
        0.94799000024796,
        -0.029190000146627,
        0.31680798530579,
        0.0097549995407462,
        -88.997039794922,
        14.15385055542,
        -17.227827072144
    )
    AddCameraShot(
        0.96342700719833,
        -0.26038599014282,
        -0.061110001057386,
        -0.016516000032425,
        -118.96892547607,
        39.055625915527,
        124.03238677979
    )
    AddCameraShot(
        0.73388397693634,
        -0.18114300072193,
        0.63560098409653,
        0.15688399970531,
        67.597633361816,
        39.055625915527,
        55.312774658203
    )
    AddCameraShot(
        0.0083149997517467,
        9.9999999747524e-007,
        -0.99996501207352,
        7.4000003223773e-005,
        -64.894348144531,
        5.541570186615,
        201.71109008789
    )
end
