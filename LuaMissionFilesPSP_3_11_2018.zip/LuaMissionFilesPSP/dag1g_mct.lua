-- dag1g_mct.lua
-- Verified
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveAssault")
ScriptCB_DoFile("MultiObjectiveContainer")
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("Ambush")
REP = 1
IMP = 2
locals = 3
ATT = 1
DEF = 2

function ScriptPostLoad()
    EnableSPHeroRules()
    missiontimer = CreateTimer("missiontimer")
    SetTimerValue(missiontimer, 300)
    StartTimer(missiontimer)
    ShowTimer(missiontimer)
    OnTimerElapse(
        function()
            MissionVictory(DEF)
        end,
        "missiontimer"
    )
    fourminremains = CreateTimer("fourminremains")
    SetTimerValue(fourminremains, 60)
    threeminremains = CreateTimer("threeminremains")
    SetTimerValue(threeminremains, 120)
    twominremains = CreateTimer("twominremains")
    SetTimerValue(twominremains, 180)
    oneminremains = CreateTimer("oneminremains")
    SetTimerValue(oneminremains, 240)
    thirtysecremains = CreateTimer("thirtysecremains")
    SetTimerValue(thirtysecremains, 270)
    tensecremains = CreateTimer("tensecremains")
    SetTimerValue(tensecremains, 290)
    StartTimer(fourminremains)
    StartTimer(threeminremains)
    StartTimer(twominremains)
    StartTimer(oneminremains)
    StartTimer(thirtysecremains)
    StartTimer(tensecremains)
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.4min")
        end,
        "fourminremains"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.3min")
        end,
        "threeminremains"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.2min")
        end,
        "twominremains"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.1min")
        end,
        "oneminremains"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.30sec")
        end,
        "thirtysecremains"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.10sec")
        end,
        "tensecremains"
    )
    fourminremains1 = CreateTimer("fourminremains1")
    SetTimerValue(fourminremains1, 60)
    threeminremains1 = CreateTimer("threeminremains1")
    SetTimerValue(threeminremains1, 120)
    twominremains1 = CreateTimer("twominremains1")
    SetTimerValue(twominremains1, 180)
    oneminremains1 = CreateTimer("oneminremains1")
    SetTimerValue(oneminremains1, 240)
    thirtysecremains1 = CreateTimer("thirtysecremains1")
    SetTimerValue(thirtysecremains1, 270)
    tensecremains1 = CreateTimer("tensecremains1")
    SetTimerValue(tensecremains1, 290)
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.4min")
        end,
        "fourminremains1"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.3min")
        end,
        "threeminremains1"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.2min")
        end,
        "twominremains1"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.1min")
        end,
        "oneminremains1"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.30sec")
        end,
        "thirtysecremains1"
    )
    OnTimerElapse(
        function()
            ShowMessageText("level.common.time.10sec")
        end,
        "tensecremains1"
    )
    AAB_count = 6
    AAB = TargetType:New({classname = "imp_inf_officer", killLimit = 6})

    AAB.OnDestroy = function(OnDestroyParam0, OnDestroyParam1)
        AAB_count = AAB_count - 1
        ShowMessageText("level.dag1g_m.merc.1-" .. AAB_count, ATT)
    end

    Objective1 =
        ObjectiveAssault:New(
        {
            teamATT = ATT,
            teamDEF = DEF,
            AIGoalWeight = 1,
            textATT = "level.dag1g_m.merc.enda",
            popupText = "level.dag1g_m.merc.popup2"
        }
    )
    Objective1:AddTarget(AAB)

    Objective1.OnComplete = function(OnCompleteParam0)
        StartTimer(missiontimer3)
        StopTimer(fourminremains)
        StopTimer(threeminremains)
        StopTimer(twominremains)
        StopTimer(oneminremains)
        StopTimer(thirtysecremains)
        StopTimer(tensecremains)
    end

    AAT_count = 6
    AAT = TargetType:New({classname = "imp_inf_officer", killLimit = 6})

    AAT.OnDestroy = function(OnDestroyParam0, OnDestroyParam1)
        AAT_count = AAT_count - 1
        ShowMessageText("level.dag1g_m.merc.2-" .. AAT_count, ATT)
    end

    Objective2 =
        ObjectiveAssault:New({teamATT = ATT, teamDEF = DEF, AIGoalWeight = 1, textATT = "level.dag1g_m.merc.end2a"})
    Objective2:AddTarget(AAT)

    Objective2.OnComplete = function(OnCompleteParam0)
        MissionVictory(ATT)
    end

    TDM = ObjectiveTDM:New({teamATT = 1, teamDEF = 2, textATT = "level.dag1g_m.merc.merc1", multiplayerRules = true})
    missiontimer2 = CreateTimer("missiontimer2")
    SetTimerValue(missiontimer2, 1)
    StartTimer(missiontimer2)
    OnTimerElapse(
        function()
            Ambush("off_path", 3, 3)
            Ambush("off_path2", 3, 3)
            AddAIGoal(3, "Deathmatch", 9999)
            AddAIGoal(2, "Deathmatch", 9999)
            SetAIDifficulty(2, 7, "medium")
            SetAIDifficulty(3, 7, "medium")
        end,
        "missiontimer2"
    )
    missiontimer3 = CreateTimer("missiontimer3")
    SetTimerValue(missiontimer3, 2)
    OnTimerElapse(
        function()
            Ambush("off_path", 3, 3)
            Ambush("off_path2", 3, 3)
            AddAIGoal(3, "Deathmatch", 9999)
            AddAIGoal(2, "Deathmatch", 9999)
            SetTimerValue(missiontimer, 300)
            AddAIGoal(2, "Deathmatch", 1)
            SetAIDifficulty(2, 7, "medium")
            SetAIDifficulty(3, 7, "medium")
            StartTimer(fourminremains1)
            StartTimer(threeminremains1)
            StartTimer(twominremains1)
            StartTimer(oneminremains1)
            StartTimer(thirtysecremains1)
            StartTimer(tensecremains1)
        end,
        "missiontimer3"
    )
    objectiveSequence = MultiObjectiveContainer:New({})
    objectiveSequence:AddObjectiveSet(Objective1)
    objectiveSequence:AddObjectiveSet(Objective2)
    objectiveSequence:AddObjectiveSet(TDM)
    objectiveSequence:Start()
end

function ScriptInit()
    if ScriptCB_GetPlatform() == "PSP" then
        SetPSPModelMemory(1616077)
        SetPSPClipper(0)
    else
        SetPS2ModelMemory(2497152 + 65536 * 0)
    end
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\dag.lvl;dag1gcw")
    SetMaxFlyHeight(20)
    SetMaxPlayerFlyHeight(20)
    ReadDataFile("SIDE\\rep.lvl", "rep_inf_ep2_jettrooper_rifleman2")
    ReadDataFile(
        "SIDE\\imp.lvl",
        "imp_inf_rifleman",
        "imp_inf_sniper",
        "imp_inf_dark_trooper",
        "imp_inf_officer",
        "imp_hero_bobafett"
    )
    ClearWalkers()
    AddWalkerType(0, 4)
    SetMemoryPoolSize("EntityHover", 0)
    SetMemoryPoolSize("EntityFlyer", 0)
    SetMemoryPoolSize("EntityDroid", 10)
    SetMemoryPoolSize("EntityCarrier", 0)
    SetMemoryPoolSize("Obstacle", 118)
    SetMemoryPoolSize("Weapon", 260)
    SetTeamName(REP, "Republic")
    SetTeamIcon(REP, "rep_icon")
    AddUnitClass(REP, "rep_inf_ep2_jettrooper_rifleman2", 1)
    SetHeroClass(REP, "imp_hero_bobafett")
    SetTeamName(IMP, "IMP")
    SetTeamIcon(IMP, "IMP_icon")
    AddUnitClass(IMP, "imp_inf_rifleman", 6)
    AddUnitClass(IMP, "imp_inf_sniper", 5)
    AddUnitClass(IMP, "imp_inf_dark_trooper", 3)
    SetUnitCount(ATT, 4)
    SetReinforcementCount(ATT, -1)
    SetUnitCount(DEF, 14)
    SetReinforcementCount(DEF, -1)
    ForceHumansOntoTeam1()
    SetTeamName(locals, "IMP")
    AddUnitClass(locals, "imp_inf_officer", 12)
    SetUnitCount(locals, 12)
    SetTeamAsFriend(locals, IMP)
    SetTeamAsFriend(IMP, locals)
    SetTeamAsEnemy(locals, REP)
    SetTeamAsEnemy(REP, locals)
    SetReinforcementCount(locals, 12)
    SetSpawnDelay(10, 0.25)
    ReadDataFile("dag\\dag1.lvl", "dag1_merc")
    SetDenseEnvironment("false")
    SetAIViewMultiplier(0.34999999403954)
    OpenAudioStream("sound\\global.lvl", "gcw_music")
    SetAmbientMusic(1, 1, "all_dag_amb_start", 0, 1)
    SetAmbientMusic(1, 0.80000001192093, "all_dag_amb_middle", 1, 1)
    SetAmbientMusic(1, 0.20000000298023, "all_dag_amb_end", 2, 1)
    SetAmbientMusic(2, 1, "imp_dag_amb_start", 0, 1)
    SetAmbientMusic(2, 0.80000001192093, "imp_dag_amb_middle", 1, 1)
    SetAmbientMusic(2, 0.20000000298023, "imp_dag_amb_end", 2, 1)
    SetVictoryMusic(1, "all_dag_amb_victory")
    SetDefeatMusic(1, "all_dag_amb_defeat")
    SetVictoryMusic(2, "imp_dag_amb_victory")
    SetDefeatMusic(2, "imp_dag_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    AddCameraShot(
        -0.40489500761032,
        0.0009919999865815,
        -0.91435998678207,
        -0.0022400000598282,
        -85.539894104004,
        20.536296844482,
        141.6994934082
    )
    AddCameraShot(
        0.040922001004219,
        0.004048999864608,
        -0.99429899454117,
        0.098380997776985,
        -139.72952270508,
        17.546598434448,
        -34.360893249512
    )
    AddCameraShot(
        -0.31235998868942,
        0.016223000362515,
        -0.94854700565338,
        -0.049263000488281,
        -217.38148498535,
        20.150953292847,
        54.514324188232
    )
end
