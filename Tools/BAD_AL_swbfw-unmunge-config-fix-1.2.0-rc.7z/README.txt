This is a branch from Sleepkiller's swbf Unmunge Program (BAD_AL Aug 2020).
Functionality added:
   unmunge .mcfg files
   unmunge .snd files
   unmunge .mus files
   unmunge .ffx files
   Dynamic hash lookup dictionaries (dictionary.txt [program dir], tmp_dict.txt[local dir])
   Single threaded mode (-st switch) 
   Skip models mode (-skipmodels switch) (because currently saving models is sometimes crashy)

The 'dictionary.txt' file is meant to contain strings that you'd like to lookup every time the program is run (this stays in the same folder as swbf-unmunge.exe).
The 'tmp_dict.txt' file is meant to contain strings pertaining to the .lvls you are currently interested in.
It is not necessary to have a tmp_dict.txt, but if one exists in your current directory then the strings inside it will be loaded.

The StringExtractor.exe program is meant to aide in creating tmp_dict.txt files.
Drag in .lvl files to the file name text box and it'll rip through them looking for strings.
There are 2 methods of lookup ['Read Raw', 'Only Lua'].
'Read Raw' will just rip through the file (any file) looking for strings. (it's kinda fun to use this mode to see all the strings the executable has)
'Only Lua' uses a UCFB reader and will only work on UCFB files (like .lvl or .script). 
