--yav2c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")
ATT = 1
DEF = 2
REP = ATT
CIS = DEF

function ScriptPostLoad()
    SoundEvent_SetupTeams(CIS,"cis",REP,"rep")
    KillObject("TempleBlastDoor")
    SetProperty("flag1","GeometryName","com_icon_cis_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_cis_flag_carried")
    SetProperty("flag2","GeometryName","com_icon_republic_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_republic_flag_carried")
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 5, textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag_capture1", captureRegion = "flag_capture1", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag_capture2", captureRegion = "flag_capture2", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",20)
    SetMemoryPoolSize("Combo::State",300)
    SetMemoryPoolSize("Combo::Transition",300)
    SetMemoryPoolSize("Combo::Condition",300)
    SetMemoryPoolSize("Combo::Attack",150)
    SetMemoryPoolSize("Combo::DamageSample",1800)
    SetMemoryPoolSize("Combo::Deflect",50)
    SetMaxFlyHeight(-22)
    SetMaxPlayerFlyHeight(-22)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\hero.lvl;herogcw")
    ReadDataFile("sound\\yav.lvl;yav1cw")
    ReadDataFile("SIDE\\heroes.lvl","rep_hero_anakin")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper","rep_hero_anakin","rep_hover_fightertank")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka","cis_hover_aat")
    ReadDataFile("SIDE\\dlc.lvl","dlc_hero_ventress")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_laser","tur_bldg_tower")
    SetupTeams({ 
        rep =         { team = REP, units = 32, reinforcements = 200, 
          soldier =           { "rep_inf_ep3_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep3_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 1, 4 }, 
          sniper =           { "rep_inf_ep3_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep3_officer", 1, 4 }, 
          special =           { "rep_inf_ep3_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 32, reinforcements = 200, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_engineer", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          officer =           { "cis_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    SetHeroClass(CIS,"dlc_hero_ventress")
    SetHeroClass(REP,"rep_hero_anakin")
    AddWalkerType(0,3)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",24)
    SetMemoryPoolSize("AmmoCounter",230)
    SetMemoryPoolSize("BaseHint",1000)
    SetMemoryPoolSize("EnergyBar",230)
    SetMemoryPoolSize("EntityCloth",25)
    SetMemoryPoolSize("EntityLight",40)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",20)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("MountedTurret",13)
    SetMemoryPoolSize("Navigator",47)
    SetMemoryPoolSize("Obstacle",750)
    SetMemoryPoolSize("PathFollower",47)
    SetMemoryPoolSize("PathNode",256)
    SetMemoryPoolSize("SoundSpaceRegion",48)
    SetMemoryPoolSize("TentacleSimulator",0)
    SetMemoryPoolSize("TreeGridStack",500)
    SetMemoryPoolSize("UnitAgent",47)
    SetMemoryPoolSize("UnitController",47)
    SetMemoryPoolSize("Weapon",230)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntityHover",2)
    SetSpawnDelay(10,0.25)
    ReadDataFile("YAV\\yav2.lvl","yav2_ctf")
    SetDenseEnvironment("false")
    SetNumBirdTypes(2)
    SetBirdType(0,1,"bird")
    SetBirdType(1,1.5,"bird2")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1_emt")
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetAmbientMusic(REP,1,"rep_yav_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_yav_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_yav_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_yav_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_yav_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_yav_amb_end",2,1)
    SetVictoryMusic(REP,"rep_yav_amb_victory")
    SetDefeatMusic(REP,"rep_yav_amb_defeat")
    SetVictoryMusic(CIS,"cis_yav_amb_victory")
    SetDefeatMusic(CIS,"cis_yav_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.90838599205017,-0.2090950012207,-0.35287299752235,-0.081225998699665,-45.922508239746,-19.114112854004,77.022636413574)
    AddCameraShot(-0.48117300868034,0.024248000234365,-0.87518101930618,-0.044103000313044,14.767292022705,-30.602321624756,-144.50685119629)
    AddCameraShot(0.99991399049759,-0.012494999915361,-0.00441600009799,-5.5000000429573e-005,1.1432529687881,-33.602313995361,-76.884429931641)
    AddCameraShot(0.8391609787941,0.012047999538481,-0.54369801282883,0.0078059998340905,19.152437210083,-49.802272796631,24.337316513062)
    AddCameraShot(0.46732398867607,0.0067090000957251,-0.88397198915482,0.012690999545157,11.825211524963,-49.802272796631,-7.0007200241089)
    AddCameraShot(0.8617969751358,0.0017859999788925,-0.50725299119949,0.0010509999701753,-11.986042976379,-59.702247619629,23.263164520264)
    AddCameraShot(0.62854599952698,-0.042608998715878,-0.7748309969902,-0.052524998784065,20.429927825928,-48.302276611328,9.7717142105103)
    AddCameraShot(0.76521301269531,-0.051872998476028,0.64021497964859,0.043400000780821,57.692474365234,-48.302276611328,16.540723800659)
    AddCameraShot(0.26403200626373,-0.01528500020504,-0.96278202533722,-0.055734001100063,-16.681797027588,-42.902290344238,129.55326843262)
    AddCameraShot(-0.38231998682022,0.022131999954581,-0.92222201824188,-0.053385999053717,20.670976638794,-42.902290344238,135.51300048828)
end

