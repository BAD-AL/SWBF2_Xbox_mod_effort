--bs1c_1flag.lua
-- Decompiled with SWBF2CodeHelper
Conquest = ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = REP
DEF = CIS

function ScriptPostLoad()
    SoundEvent_SetupTeams(REP,"rep",CIS,"cis")
    ctf = ObjectiveOneFlagCTF:New({ teamATT = REP, teamDEF = CIS, textATT = "game.modes.1flag", textDEF = "game.modes.1flag2", captureLimit = 5, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "homeregion", captureRegionATT = "team1_capture", captureRegionDEF = "team2_capture", capRegionMarkerATT = "hud_objective_icon_circle", capRegionMarkerDEF = "hud_objective_icon_circle", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3, multiplayerRules = true })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(225)
    SetMaxPlayerFlyHeight(225)
    SetGroundFlyerMap(1)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\BS1.lvl;BS1cw")
    ReadDataFile("sound\\cor.lvl;cor1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep2_rocketeer","rep_inf_ep2_rifleman","rep_inf_ep2_jettrooper","rep_inf_ep2_sniper","rep_inf_ep2_pilot")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_pilot","cis_inf_sniper","cis_inf_officer","cis_inf_droideka")
    ReadDataFile("SIDE\\swbf1.lvl","cis_fly_droidfighter","rep_fly_jedifighter")
    ReadDataFile("SIDE\\heroes.lvl","rep_hero_plokoon","cis_hero_durge")
    ReadDataFile("SIDE\\vehicles.lvl","rep_fly_arc170fighter","rep_fly_vwing","cis_fly_tridroidfighter","cis_fly_greviousfighter")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_ep2_officer","rep_inf_commando","cis_inf_commando")
    ReadDataFile("SIDE\\all.lvl","all_hero_luke_jedi")
    SetupTeams({ 
        rep =         { team = REP, units = 30, reinforcements = 150, 
          soldier =           { "rep_inf_ep2_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep2_rocketeer", 1, 4 }, 
          pilot =           { "rep_inf_ep2_pilot", 1, 4 }, 
          sniper =           { "rep_inf_ep2_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep2_officer", 1, 4 }, 
          special =           { "rep_inf_ep2_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 30, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          pilot =           { "cis_inf_pilot", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          officer =           { "cis_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    AddUnitClass(REP,"rep_inf_commando",1,2)
    AddUnitClass(CIS,"cis_inf_commando",1,2)
    SetHeroClass(REP,"rep_hero_plokoon")
    SetHeroClass(CIS,"cis_hero_durge")
    AddWalkerType(0,8)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("AmmoCounter",512)
    SetMemoryPoolSize("BaseHint",1000)
    SetMemoryPoolSize("EnergyBar",512)
    SetMemoryPoolSize("EntityFlyer",50)
    SetMemoryPoolSize("EntityLight",50)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",20)
    SetMemoryPoolSize("MountedTurret",40)
    SetMemoryPoolSize("Obstacle",760)
    SetMemoryPoolSize("PathNode",512)
    SetMemoryPoolSize("SoundSpaceRegion",46)
    SetMemoryPoolSize("Weapon",512)
    SetMemoryPoolSize("SoldierAnimation",650)
    SetMemoryPoolSize("Aimer",250)
    SetMemoryPoolSize("ConnectivityGraphFollower",55)
    SetMemoryPoolSize("EntityCloth",41)
    SetMemoryPoolSize("EntityDefenseGridTurret",0)
    SetMemoryPoolSize("EntityPortableTurret",20)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",120)
    SetMemoryPoolSize("Navigator",80)
    SetMemoryPoolSize("Ordnance",80)
    SetMemoryPoolSize("ParticleEmitter",512)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("PathFollower",80)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("TreeGridStack",340)
    SetMemoryPoolSize("UnitAgent",100)
    SetMemoryPoolSize("UnitController",110)
    SetMemoryPoolSize("Music",60)
    SetMemoryPoolSize("FlagItem",1)
    SetSpawnDelay(10,0.25)
    ReadDataFile("BS1\\BS1.lvl","BS1_1flag")
    SetDenseEnvironment("false")
    OpenAudioStream("sound\\global.lvl","spa1_objective_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","rep_unit_vo_slow",OpenAudioStream())
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",OpenAudioStream())
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",OpenAudioStream())
    OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",OpenAudioStream())
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\cor.lvl","cor1")
    OpenAudioStream("sound\\cor.lvl","cor1")
    OpenAudioStream("sound\\BS1.lvl")
    OpenAudioStream("sound\\BS1.lvl")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(REP,REP,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(REP,CIS,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,CIS,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,REP,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(REP,"Repleaving")
    SetOutOfBoundsVoiceOver(CIS,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_cor_amb_start",0,1)
    SetAmbientMusic(REP,0.99000000953674,"rep_cor_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_cor_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_cor_amb_start",0,1)
    SetAmbientMusic(CIS,0.99000000953674,"cis_cor_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_cor_amb_end",2,1)
    SetVictoryMusic(REP,"rep_cor_amb_victory")
    SetDefeatMusic(REP,"rep_cor_amb_defeat")
    SetVictoryMusic(CIS,"cis_cor_amb_victory")
    SetDefeatMusic(CIS,"cis_cor_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.79310500621796,-0.062986001372337,-0.60391801595688,-0.047961998730898,-170.58361816406,118.98154449463,-150.44325256348)
    AddCameraShot(0.18971599638462,0.00094400002853945,-0.98182600736618,0.0048870001919568,-27.594291687012,100.58374023438,-176.47801208496)
    AddCameraShot(0.49240100383759,0.010386999696493,-0.87011301517487,0.018354000523686,19.590665817261,100.49359893799,-47.846900939941)
end

