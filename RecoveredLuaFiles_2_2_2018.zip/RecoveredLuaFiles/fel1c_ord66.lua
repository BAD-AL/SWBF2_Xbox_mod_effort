--fel1c_ord66.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("setup_teams")
REP = 1
JED = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    SetProperty("cp1-1","CaptureRegion","")
    SetProperty("cp2-1","CaptureRegion","")
    SetProperty("cp3-1","CaptureRegion","")
    SetProperty("cp4-1","CaptureRegion","")
    SetProperty("cp5-1","CaptureRegion","")
    SetProperty("cp6-1","CaptureRegion","")
    SetProperty("cp1-1","Team","1")
    SetProperty("cp2-1","Team","2")
    SetProperty("cp3-1","Team","2")
    SetProperty("cp4-1","Team","1")
    SetProperty("cp5-1","Team","2")
    SetProperty("cp6-1","Team","1")
    TDM = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, multiplayerScoreLimit = 75, textATT = "game.modes.tdm", textDEF = "game.modes.tdm2", multiplayerRules = true, isCelebrityDeathmatch = true })
    TDM:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(53)
    SetMaxPlayerFlyHeight(53)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",15)
    SetMemoryPoolSize("Combo::State",250)
    SetMemoryPoolSize("Combo::Transition",300)
    SetMemoryPoolSize("Combo::Condition",300)
    SetMemoryPoolSize("Combo::Attack",250)
    SetMemoryPoolSize("Combo::DamageSample",10000)
    SetMemoryPoolSize("Combo::Deflect",150)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\fel.lvl;fel1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper")
    ReadDataFile("SIDE\\jed.lvl","jed_knight_01","jed_knight_02","jed_knight_03","jed_knight_04")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_commando","jed_knight_10","jed_knight_13","jed_knight_14")
    SetupTeams({ 
        rep =         { team = REP, units = 32, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman", 13, 16 }, 
          assault =           { "rep_inf_ep3_rocketeer", 5, 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 3, 4 }, 
          sniper =           { "rep_inf_ep3_sniper", 2, 4 }, 
          officer =           { "rep_inf_ep3_officer", 2, 4 }, 
          special =           { "rep_inf_ep3_jettrooper", 2, 4 }
         }, 
        locals =         { team = JED, units = 15, reinforcements = -1, 
          soldier =           { "jed_knight_01", 4, 6 }, 
          assault =           { "jed_knight_02", 4, 6 }, 
          engineer =           { "jed_knight_03", 3, 6 }, 
          sniper =           { "jed_knight_04", 2, 6 }, 
          officer =           { "jed_knight_10", 1, 1 }, 
          special =           { "jed_knight_13", 1, 1 }
         }
       })
    AddUnitClass(REP,"rep_inf_commando",1,2)
    AddUnitClass(JED,"jed_knight_14",1,2)
    ClearWalkers()
    SetMemoryPoolSize("Aimer",20)
    SetMemoryPoolSize("AmmoCounter",260)
    SetMemoryPoolSize("BaseHint",200)
    SetMemoryPoolSize("EnergyBar",260)
    SetMemoryPoolSize("EntityHover",3)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntitySoundStream",1)
    SetMemoryPoolSize("EntitySoundStatic",0)
    SetMemoryPoolSize("EntityWalker",5)
    SetMemoryPoolSize("MountedTurret",6)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("PathNode",512)
    SetMemoryPoolSize("TreeGridStack",280)
    SetMemoryPoolSize("Weapon",260)
    SetMemoryPoolSize("Music",39)
    SetSpawnDelay(10,0.25)
    ReadDataFile("fel\\fel1.lvl","fel1_conquest")
    SetDenseEnvironment("false")
    SetAIViewMultiplier(0.64999997615814)
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    voiceSlow = OpenAudioStream("sound\\global.lvl","cor_objective_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","rep_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","all_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","rep_unit_vo_quick",voiceQuick)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\fel.lvl","fel1")
    OpenAudioStream("sound\\fel.lvl","fel1")
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetOutOfBoundsVoiceOver(2,"allleaving")
    SetVictoryMusic(REP,"rep_cor_amb_victory")
    SetDefeatMusic(REP,"rep_cor_amb_defeat")
    SetVictoryMusic(JED,"all_cor_amb_victory")
    SetDefeatMusic(JED,"all_cor_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.89630699157715,-0.17134800553322,-0.40171599388123,-0.076796002686024,-116.30693054199,31.039505004883,20.757469177246)
    AddCameraShot(0.90934300422668,-0.2019670009613,-0.35508298873901,-0.078864999115467,-116.30693054199,31.039505004883,20.757469177246)
    AddCameraShot(0.54319900274277,0.11552099883556,-0.81342798471451,0.17298999428749,-108.37818908691,13.564240455627,-40.644149780273)
    AddCameraShot(0.97061002254486,0.13565899431705,0.1968660056591,-0.027514999732375,-3.2143459320068,11.924586296082,-44.687294006348)
    AddCameraShot(0.34613001346588,0.046310998499393,-0.92876601219177,0.12426699697971,87.431060791016,20.881387710571,13.070729255676)
    AddCameraShot(0.4680840075016,0.095610998570919,-0.86072397232056,0.1758120059967,18.063482284546,19.360580444336,18.178157806396)
end

