--eskk_hero.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveTDM")

function ScriptPostLoad()
    EnableSPHeroRules()
    TDM = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, multiplayerScoreLimit = 100, textATT = "game.modes.tdm", textDEF = "game.modes.tdm2", multiplayerRules = true, isCelebrityDeathmatch = true })
    TDM:Start()
    AddAIGoal(1,"Deathmatch",100)
    AddAIGoal(2,"Deathmatch",100)
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    SetMemoryPoolSize("ClothData",100)
    SetMemoryPoolSize("Combo",70)
    SetMemoryPoolSize("Combo::State",850)
    SetMemoryPoolSize("Combo::Transition",850)
    SetMemoryPoolSize("Combo::Condition",850)
    SetMemoryPoolSize("Combo::Attack",750)
    SetMemoryPoolSize("Combo::DamageSample",8000)
    SetMemoryPoolSize("Combo::Deflect",140)
    ReadDataFile("ingame.lvl")
    ALL = 1
    IMP = 2
    ATT = 1
    DEF = 2
    SetMaxFlyHeight(40)
    SetMaxPlayerFlyHeight(40)
    ReadDataFile("sound\\tat.lvl;tat2gcw")
    ReadDataFile("SIDE\\rep.lvl","rep_hero_obiwan","rep_hero_kiyadimundi")
    ReadDataFile("SIDE\\cis.lvl","cis_hero_countdooku")
    ReadDataFile("SIDE\\kotor.lvl","kor_hero_atton","kor_hero_bastila","kor_hero_carth","kor_hero_hk47","kor_hero_jolee","kor_hero_nihilus","kor_hero_revan","kor_hero_sion","kor_hero_traya")
    SetupTeams({ 
        hero =         { team = ALL, units = 12, reinforcements = -1, 
          soldier =           { "kor_hero_atton", 1, 2 }, 
          assault =           { "kor_hero_bastila", 1, 2 }, 
          engineer =           { "kor_hero_carth", 1, 2 }, 
          sniper =           { "kor_hero_jolee", 1, 2 }, 
          officer =           { "kor_hero_hk47", 1, 2 }
         }, 
        villain =         { team = IMP, units = 12, reinforcements = -1, 
          soldier =           { "kor_hero_malak", 1, 2 }, 
          assault =           { "kor_hero_nihilus", 1, 2 }, 
          engineer =           { "kor_hero_revan", 1, 2 }, 
          sniper =           { "kor_hero_sion", 1, 2 }, 
          officer =           { "kor_hero_traya", 1, 2 }
         }
       })
    ClearWalkers()
    AddWalkerType(0,0)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",1)
    SetMemoryPoolSize("AmmoCounter",96)
    SetMemoryPoolSize("BaseHint",320)
    SetMemoryPoolSize("ConnectivityGraphFollower",23)
    SetMemoryPoolSize("EnergyBar",96)
    SetMemoryPoolSize("EntityCloth",41)
    SetMemoryPoolSize("EntityDefenseGridTurret",0)
    SetMemoryPoolSize("EntityDroid",0)
    SetMemoryPoolSize("EntityFlyer",5)
    SetMemoryPoolSize("EntityLight",80,80)
    SetMemoryPoolSize("EntityPortableTurret",0)
    SetMemoryPoolSize("EntitySoundStream",2)
    SetMemoryPoolSize("EntitySoundStatic",45)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",120)
    SetMemoryPoolSize("MountedTurret",0)
    SetMemoryPoolSize("Navigator",23)
    SetMemoryPoolSize("Obstacle",667)
    SetMemoryPoolSize("Ordnance",80)
    SetMemoryPoolSize("ParticleEmitter",512)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("PathFollower",23)
    SetMemoryPoolSize("PathNode",128)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("TentacleSimulator",24)
    SetMemoryPoolSize("TreeGridStack",290)
    SetMemoryPoolSize("UnitAgent",23)
    SetMemoryPoolSize("UnitController",23)
    SetMemoryPoolSize("Weapon",96)
    SetSpawnDelay(10,0.25)
    ReadDataFile("ESK\\ESK.lvl","ESK_eli")
    SetDenseEnvironment("false")
    ScriptCB_EnableHeroMusic(0)
    ScriptCB_EnableHeroVO(0)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\tat.lvl","tat2")
    OpenAudioStream("sound\\tat.lvl","tat2")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"Allleaving")
    SetOutOfBoundsVoiceOver(2,"Impleaving")
    SetAmbientMusic(ALL,1,"gen_amb_celebDeathmatch",0,1)
    SetAmbientMusic(IMP,1,"gen_amb_celebDeathmatch",0,1)
    SetVictoryMusic(REP,"rep_yav_amb_victory")
    SetDefeatMusic(REP,"rep_yav_amb_defeat")
    SetVictoryMusic(CIS,"cis_yav_amb_victory")
    SetDefeatMusic(CIS,"cis_yav_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.50274902582169,-0.011367999948561,0.86413699388504,0.019539000466466,142.58670043945,2.5306398868561,166.22665405273)
    AddCameraShot(0.86213302612305,0.012934999540448,0.5064600110054,-0.0075989998877048,50.841514587402,2.5306398868561,153.55166625977)
    AddCameraShot(0.79983997344971,0.016191000118852,0.59987199306488,-0.012143000029027,-75.426422119141,4.7940888404846,151.68447875977)
    AddCameraShot(0.63314098119736,-0.0034620000515133,-0.77401697635651,-0.004232999868691,-85.371620178223,6.2829570770264,137.96942138672)
    AddCameraShot(0.86663401126862,-0.016293000429869,0.49858999252319,0.0093740001320839,12.09645652771,4.7616291046143,113.7106552124)
    AddCameraShot(0.21403899788857,-0.00096700002904981,-0.97681498527527,-0.0044120000675321,159.55409240723,2.8692378997803,116.80983734131)
end

