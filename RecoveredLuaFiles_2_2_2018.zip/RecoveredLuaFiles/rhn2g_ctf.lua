--rhn2g_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
ALL = 2
IMP = 1
ATT = 1
DEF = 2

function ScriptPostLoad()
    SoundEvent_SetupTeams(IMP,"imp",ALL,"all")
    EnableSPHeroRules()
    SetProperty("flag1","GeometryName","com_icon_imperial_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_imperial_flag_carried")
    SetProperty("flag2","GeometryName","com_icon_alliance_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_alliance_flag_carried")
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 5, textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag2_capture", captureRegion = "flag1_capture", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag1_capture", captureRegion = "flag2_capture", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",20)
    SetMemoryPoolSize("Combo::State",300)
    SetMemoryPoolSize("Combo::Transition",300)
    SetMemoryPoolSize("Combo::Condition",300)
    SetMemoryPoolSize("Combo::Attack",150)
    SetMemoryPoolSize("Combo::DamageSample",1800)
    SetMemoryPoolSize("Combo::Deflect",50)
    ALL = 2
    IMP = 1
    ATT = 1
    DEF = 2
    SetMaxFlyHeight(30)
    SetMaxPlayerFlyHeight(30)
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\hot.lvl;hot1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_snow","all_inf_rocketeer_snow","all_inf_engineer_snow","all_inf_sniper_snow","all_inf_officer_snow","all_inf_wookiee_snow","all_hover_combatspeeder")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman_snow","imp_inf_rocketeer_snow","imp_inf_sniper_snow","imp_inf_dark_trooper","imp_inf_engineer_snow","imp_inf_officer","imp_hero_bobafett","imp_walk_atat","imp_hover_fightertank")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_laser")
    ReadDataFile("SIDE\\infantry.lvl","all_inf_specialops","imp_inf_commando")
    ReadDataFile("SIDE\\heroes.lvl","all_hero_hansolo_tat")
    SetupTeams({ 
        all =         { team = ALL, units = 19, reinforcements = 150, 
          soldier =           { "all_inf_rifleman_snow", 9, 25 }, 
          assault =           { "all_inf_rocketeer_snow", 1, 4 }, 
          engineer =           { "all_inf_engineer_snow", 1, 4 }, 
          sniper =           { "all_inf_sniper_snow", 1, 4 }, 
          officer =           { "all_inf_officer_snow", 1, 4 }, 
          special =           { "all_inf_wookiee_snow", 1, 4 }
         }, 
        imp =         { team = IMP, units = 19, reinforcements = 150, 
          soldier =           { "imp_inf_rifleman_snow", 9, 25 }, 
          assault =           { "imp_inf_rocketeer_snow", 1, 4 }, 
          engineer =           { "imp_inf_engineer_snow", 1, 4 }, 
          sniper =           { "imp_inf_sniper_snow", 1, 4 }, 
          officer =           { "imp_inf_officer", 1, 4 }, 
          special =           { "imp_inf_dark_trooper", 1, 4 }
         }
       })
    AddUnitClass(ALL,"all_inf_specialops",1,2)
    AddUnitClass(IMP,"imp_inf_commando",1,2)
    SetHeroClass(IMP,"imp_hero_bobafett")
    SetHeroClass(ALL,"all_hero_hansolo_tat")
    ClearWalkers()
    AddWalkerType(0,4)
    AddWalkerType(1,5)
    AddWalkerType(2,2)
    SetMemoryPoolSize("Aimer",80)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("AmmoCounter",221)
    SetMemoryPoolSize("BaseHint",175)
    SetMemoryPoolSize("CommandWalker",2)
    SetMemoryPoolSize("ConnectivityGraphFollower",56)
    SetMemoryPoolSize("EnergyBar",221)
    SetMemoryPoolSize("EntityCloth",41)
    SetMemoryPoolSize("EntityFlyer",10)
    SetMemoryPoolSize("EntityLight",110)
    SetMemoryPoolSize("EntitySoundStatic",16)
    SetMemoryPoolSize("EntitySoundStream",5)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",54)
    SetMemoryPoolSize("MountedTurret",30)
    SetMemoryPoolSize("Navigator",63)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("PathFollower",63)
    SetMemoryPoolSize("PathNode",160)
    SetMemoryPoolSize("ShieldEffect",4)
    SetMemoryPoolSize("TreeGridStack",300)
    SetMemoryPoolSize("UnitController",63)
    SetMemoryPoolSize("UnitAgent",63)
    SetMemoryPoolSize("Weapon",221)
    ReadDataFile("RHN\\RHN2.lvl","rhenvar2_ctf")
    SetSpawnDelay(10,0.25)
    SetDenseEnvironment("true")
    SetDefenderSnipeRange(170)
    AddDeathRegion("FalltoDeath")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(ALL,1,"all_hot_amb_start",0,1)
    SetAmbientMusic(ALL,0.80000001192093,"all_hot_amb_middle",1,1)
    SetAmbientMusic(ALL,0.20000000298023,"all_hot_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_hot_amb_start",0,1)
    SetAmbientMusic(IMP,0.80000001192093,"imp_hot_amb_middle",1,1)
    SetAmbientMusic(IMP,0.20000000298023,"imp_hot_amb_end",2,1)
    SetVictoryMusic(ALL,"all_hot_amb_victory")
    SetDefeatMusic(ALL,"all_hot_amb_defeat")
    SetVictoryMusic(IMP,"imp_hot_amb_victory")
    SetDefeatMusic(IMP,"imp_hot_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.85053902864456,-0.17890000343323,0.48395800590515,0.10179500281811,-86.326026916504,38.517925262451,-183.72145080566)
    AddCameraShot(0.078626997768879,0.0038199999835342,-0.9957230091095,0.048374000936747,-135.32171630859,2.4099950790405,-158.55506896973)
    AddCameraShot(-0.43235000967979,-0.026157999411225,-0.8996809720993,0.05443200096488,-138.08926391602,1.5099949836731,-162.38565063477)
    AddCameraShot(0.87493801116943,-0.18726800382137,-0.4366739988327,-0.093464002013206,-130.03135681152,14.409952163696,-172.02850341797)
    AddCameraShot(0.61386501789093,0.061537999659777,0.78308600187302,-0.078501999378204,-164.63346862793,13.809918403625,-190.79316711426)
    AddCameraShot(0.5497339963913,0.042633999139071,0.83175802230835,-0.064506001770496,-165.80003356934,-4.8901371955872,-104.95146942139)
    AddCameraShot(0.24495799839497,-0.063781999051571,-0.93621802330017,-0.24377100169659,-215.11689758301,22.709844589233,-115.63423919678)
    AddCameraShot(-0.47684699296951,0.088767997920513,-0.85972601175308,-0.16004300117493,-224.66749572754,22.309844970703,-159.44493103027)
    AddCameraShot(-0.19013999402523,-0.010897999629378,-0.9800900220871,0.056175999343395,-265.22821044922,17.909717559814,-187.94244384766)
    AddCameraShot(0.98370599746704,0.10078299790621,-0.14810900390148,0.015173999592662,-211.53150939941,14.309621810913,-100.22414398193)
    AddCameraShot(-0.22784100472927,0.044174998998642,-0.95491600036621,-0.18514500558376,-231.72216796875,17.509618759155,-244.99606323242)
    AddCameraShot(0.83856302499771,-0.12557899951935,0.52429401874542,0.078515999019146,-209.09350585938,20.309616088867,-182.65461730957)
    AddCameraShot(0.83298397064209,-0.15135300159454,-0.52362602949142,-0.095141999423504,-207.45223999023,5.5096249580383,-234.40676879883)
end

