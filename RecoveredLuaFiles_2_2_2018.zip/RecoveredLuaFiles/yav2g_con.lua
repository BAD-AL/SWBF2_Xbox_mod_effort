--yav2g_con.lua
-- Decompiled with SWBF2CodeHelper
Conquest = ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
KillObject("TempleBlastDoor")
ALL = 2
IMP = 1
ATT = IMP
DEF = ALL

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "CP1" })
    cp2 = CommandPost:New({ name = "CP2" })
    cp3 = CommandPost:New({ name = "CP3" })
    cp4 = CommandPost:New({ name = "CP4" })
    cp5 = CommandPost:New({ name = "CP5" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(-22)
    SetMaxPlayerFlyHeight(-22)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",20)
    SetMemoryPoolSize("Combo::State",300)
    SetMemoryPoolSize("Combo::Transition",300)
    SetMemoryPoolSize("Combo::Condition",300)
    SetMemoryPoolSize("Combo::Attack",150)
    SetMemoryPoolSize("Combo::DamageSample",1800)
    SetMemoryPoolSize("Combo::Deflect",50)
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\yav.lvl;yav1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_jungle","all_inf_rocketeer_jungle","all_inf_sniper_jungle","all_inf_engineer_jungle","all_inf_officer_jungle","all_hero_luke_jedi","all_inf_wookiee","all_hover_combatspeeder")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_bobafett","imp_hover_fightertank")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_laser","tur_bldg_tower")
    SetupTeams({ 
        all =         { team = ALL, units = 20, reinforcements = 150, 
          soldier =           { "all_inf_rifleman_jungle", 9, 25 }, 
          assault =           { "all_inf_rocketeer_jungle", 1, 4 }, 
          engineer =           { "all_inf_engineer_jungle", 1, 4 }, 
          sniper =           { "all_inf_sniper_jungle", 1, 4 }, 
          officer =           { "all_inf_officer_jungle", 1, 4 }, 
          special =           { "all_inf_wookiee", 1, 4 }
         }, 
        imp =         { team = IMP, units = 20, reinforcements = 150, 
          soldier =           { "imp_inf_rifleman", 9, 25 }, 
          assault =           { "imp_inf_rocketeer", 1, 4 }, 
          engineer =           { "imp_inf_engineer", 1, 4 }, 
          sniper =           { "imp_inf_sniper", 1, 4 }, 
          officer =           { "imp_inf_officer", 1, 4 }, 
          special =           { "imp_inf_dark_trooper", 1, 4 }
         }
       })
    SetHeroClass(ALL,"all_hero_luke_jedi")
    SetHeroClass(IMP,"imp_hero_bobafett")
    ClearWalkers()
    AddWalkerType(0,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("AmmoCounter",240)
    SetMemoryPoolSize("BaseHint",1000)
    SetMemoryPoolSize("EnergyBar",240)
    SetMemoryPoolSize("EntityCloth",17)
    SetMemoryPoolSize("EntityFlyer",7)
    SetMemoryPoolSize("EntityHover",8)
    SetMemoryPoolSize("EntityLight",50)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",20)
    SetMemoryPoolSize("MountedTurret",25)
    SetMemoryPoolSize("Navigator",49)
    SetMemoryPoolSize("Obstacle",760)
    SetMemoryPoolSize("PathNode",512)
    SetMemoryPoolSize("SoundSpaceRegion",46)
    SetMemoryPoolSize("TreeGridStack",500)
    SetMemoryPoolSize("UnitAgent",49)
    SetMemoryPoolSize("UnitController",49)
    SetMemoryPoolSize("Weapon",240)
    SetSpawnDelay(10,0.25)
    ReadDataFile("YAV\\yav2.lvl","yav2_conquest")
    SetDenseEnvironment("false")
    SetNumBirdTypes(2)
    SetBirdType(0,1,"bird")
    SetBirdType(1,1.5,"bird2")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1_emt")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"impleaving")
    SetOutOfBoundsVoiceOver(2,"allleaving")
    SetAmbientMusic(ALL,1,"all_yav_amb_start",0,1)
    SetAmbientMusic(ALL,0.80000001192093,"all_yav_amb_middle",1,1)
    SetAmbientMusic(ALL,0.20000000298023,"all_yav_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_yav_amb_start",0,1)
    SetAmbientMusic(IMP,0.80000001192093,"imp_yav_amb_middle",1,1)
    SetAmbientMusic(IMP,0.20000000298023,"imp_yav_amb_end",2,1)
    SetVictoryMusic(ALL,"all_yav_amb_victory")
    SetDefeatMusic(ALL,"all_yav_amb_defeat")
    SetVictoryMusic(IMP,"imp_yav_amb_victory")
    SetDefeatMusic(IMP,"imp_yav_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.90838599205017,-0.2090950012207,-0.35287299752235,-0.081225998699665,-45.922508239746,-19.114112854004,77.022636413574)
    AddCameraShot(-0.48117300868034,0.024248000234365,-0.87518101930618,-0.044103000313044,14.767292022705,-30.602321624756,-144.50685119629)
    AddCameraShot(0.99991399049759,-0.012494999915361,-0.00441600009799,-5.5000000429573e-005,1.1432529687881,-33.602313995361,-76.884429931641)
    AddCameraShot(0.8391609787941,0.012047999538481,-0.54369801282883,0.0078059998340905,19.152437210083,-49.802272796631,24.337316513062)
    AddCameraShot(0.46732398867607,0.0067090000957251,-0.88397198915482,0.012690999545157,11.825211524963,-49.802272796631,-7.0007200241089)
    AddCameraShot(0.8617969751358,0.0017859999788925,-0.50725299119949,0.0010509999701753,-11.986042976379,-59.702247619629,23.263164520264)
    AddCameraShot(0.62854599952698,-0.042608998715878,-0.7748309969902,-0.052524998784065,20.429927825928,-48.302276611328,9.7717142105103)
    AddCameraShot(0.76521301269531,-0.051872998476028,0.64021497964859,0.043400000780821,57.692474365234,-48.302276611328,16.540723800659)
    AddCameraShot(0.26403200626373,-0.01528500020504,-0.96278202533722,-0.055734001100063,-16.681797027588,-42.902290344238,129.55326843262)
    AddCameraShot(-0.38231998682022,0.022131999954581,-0.92222201824188,-0.053385999053717,20.670976638794,-42.902290344238,135.51300048828)
end

