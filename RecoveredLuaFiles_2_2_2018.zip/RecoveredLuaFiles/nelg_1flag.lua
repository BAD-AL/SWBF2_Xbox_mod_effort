--nelg_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ALL = 2
IMP = 1
ATT = 1
DEF = 2

function ScriptPostLoad()
    SoundEvent_SetupTeams(ALL,"all",IMP,"imp")
    ctf = ObjectiveOneFlagCTF:New({ teamATT = IMP, teamDEF = ALL, textATT = "game.modes.1flag", textDEF = "game.modes.1flag2", captureLimit = 5, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "homeregion", captureRegionATT = "team1_capture", captureRegionDEF = "team2_capture", capRegionMarkerATT = "hud_objective_icon_circle", capRegionMarkerDEF = "hud_objective_icon_circle", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3, multiplayerRules = true })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(150)
    SetMaxPlayerFlyHeight(150)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\tat.lvl;tat2gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_snow","all_inf_rocketeer_snow","all_inf_engineer_snow","all_inf_sniper_snow","all_inf_officer_snow","all_inf_wookiee_snow","all_walk_tauntaun")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman_snow","imp_inf_rocketeer_snow","imp_inf_sniper_snow","imp_inf_dark_trooper","imp_inf_engineer_snow","imp_inf_officer","imp_hero_bobafett")
    ReadDataFile("SIDE\\infantry.lvl","all_inf_specialops","imp_inf_commando")
    ReadDataFile("SIDE\\heroes.lvl","all_hero_jodokast")
    SetupTeams({ 
        all =         { team = ALL, units = 32, reinforcements = 150, 
          soldier =           { "all_inf_rifleman_snow", 9, 25 }, 
          assault =           { "all_inf_rocketeer_snow", 1, 4 }, 
          engineer =           { "all_inf_engineer_snow", 1, 4 }, 
          sniper =           { "all_inf_sniper_snow", 1, 4 }, 
          officer =           { "all_inf_officer_snow", 1, 4 }, 
          special =           { "all_inf_wookiee_snow", 1, 4 }
         }, 
        imp =         { team = IMP, units = 32, reinforcements = 150, 
          soldier =           { "imp_inf_rifleman_snow", 9, 25 }, 
          assault =           { "imp_inf_rocketeer_snow", 1, 4 }, 
          engineer =           { "imp_inf_engineer_snow", 1, 4 }, 
          sniper =           { "imp_inf_sniper_snow", 1, 4 }, 
          officer =           { "imp_inf_officer", 1, 4 }, 
          special =           { "imp_inf_dark_trooper", 1, 4 }
         }
       })
    AddUnitClass(ALL,"all_inf_specialops",1,2)
    AddUnitClass(IMP,"imp_inf_commando",1,2)
    SetHeroClass(ALL,"all_hero_jodokast")
    SetHeroClass(IMP,"imp_hero_bobafett")
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("AmmoCounter",1024)
    SetMemoryPoolSize("BaseHint",1024)
    SetMemoryPoolSize("CommandWalker",2)
    SetMemoryPoolSize("EnergyBar",1024)
    SetMemoryPoolSize("EntityCloth",32)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityHover",32)
    SetMemoryPoolSize("EntityLight",200)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",32)
    SetMemoryPoolSize("MountedTurret",32)
    SetMemoryPoolSize("Navigator",128)
    SetMemoryPoolSize("Obstacle",1024)
    SetMemoryPoolSize("PathNode",1024)
    SetMemoryPoolSize("SoldierAnimation",512)
    SetMemoryPoolSize("SoundSpaceRegion",64)
    SetMemoryPoolSize("TreeGridStack",1024)
    SetMemoryPoolSize("UnitAgent",128)
    SetMemoryPoolSize("UnitController",128)
    SetMemoryPoolSize("Weapon",1024)
    SetSpawnDelay(10,0.25)
    ReadDataFile("NEL\\NEL.lvl","NEL_conquest")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","des_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\tat.lvl","tat2")
    OpenAudioStream("sound\\tat.lvl","tat2")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(ALL,1,"all_tat_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_tat_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_tat_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_tat_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_tat_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_tat_amb_end",2,1)
    SetVictoryMusic(ALL,"all_tat_amb_victory")
    SetDefeatMusic(ALL,"all_tat_amb_defeat")
    SetVictoryMusic(IMP,"imp_tat_amb_victory")
    SetDefeatMusic(IMP,"imp_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.70252799987793,-0.18260499835014,0.66570901870728,0.1730349957943,88.019607543945,119.32252502441,6.2259159088135)
    AddCameraShot(0.94283199310303,-0.22129499912262,-0.24260100722313,-0.056940998882055,-60.964904785156,108.96562194824,81.692283630371)
    AddCameraShot(0.92140698432922,-0.097567997872829,-0.37406000494957,-0.039609000086784,-112.23388671875,108.96562194824,136.24380493164)
    AddCameraShot(0.96467399597168,-0.2520309984684,-0.07422199845314,-0.019391000270844,-2.3616919517517,103.43183898926,33.009258270264)
    AddCameraShot(0.65242999792099,-0.069912001490593,-0.75032198429108,-0.080401003360748,-117.73081970215,103.43183898926,11.439115524292)
    AddCameraShot(-0.23905900120735,0.018079999834299,-0.96807199716568,-0.073216997087002,31.372383117676,110.72171783447,69.614196777344)
    AddCameraShot(0.41184198856354,0.029211999848485,-0.90850400924683,0.064438998699188,-11.281128883362,86.811317443848,-29.294544219971)
    AddCameraShot(0.73310297727585,-0.28167900443077,-0.57785797119141,-0.22202999889851,-50.071311950684,107.50148010254,81.472244262695)
    AddDeathRegion("deathregion")
end

