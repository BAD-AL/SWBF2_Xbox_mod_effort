--korg_jubjub.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
local local_2 = 1
local local_3 = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "cp4" })
    cp2 = CommandPost:New({ name = "cp5" })
    cp3 = CommandPost:New({ name = "cp6" })
    cp4 = CommandPost:New({ name = "cp7" })
    cp5 = CommandPost:New({ name = "cp8" })
    conquest = ObjectiveConquest:New({ teamATT = local_2, teamDEF = local_3, text = "level.geo1.objectives.conquest", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:Start()
    EnableSPHeroRules()
end
local local_0 = 1
local local_1 = 2

function ScriptInit()
    SetPS2ModelMemory(4956000)
    ReadDataFile("ingame.lvl")
    SetMaxPlayerFlyHeight(37)
    SetMaxFlyHeight(20)
    SetMaxPlayerFlyHeight(20)
    ReadDataFile("sound\\dag.lvl;dag1gcw")
    ReadDataFile("sound\\BS1.lvl")
    ReadDataFile("SIDE\\jub.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_engineer","all_inf_sniper","all_inf_officer","all_inf_wookiee","rep_inf_ep2_rifleman","rep_inf_ep2_rocketeer","rep_inf_ep2_pilot","rep_inf_ep2_sniper","rep_inf_ep2_jettrooper")
    SetupTeams({ 
        all =         { team = local_0, units = 32, reinforcements = 150, 
          soldier =           { "all_inf_rifleman", 9, 25 }, 
          assault =           { "all_inf_rocketeer", 1, 4 }, 
          engineer =           { "all_inf_engineer", 1, 4 }, 
          sniper =           { "all_inf_sniper", 1, 4 }, 
          special =           { "all_inf_wookiee", 1, 4 }
         }, 
        rep =         { team = local_1, units = 32, reinforcements = 150, 
          soldier =           { "rep_inf_ep2_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep2_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep2_pilot", 1, 4 }, 
          sniper =           { "rep_inf_ep2_sniper", 1, 4 }, 
          special =           { "rep_inf_ep2_jettrooper", 1, 4 }
         }
       })
    ClearWalkers()
    SetMemoryPoolSize("Aimer",5)
    SetMemoryPoolSize("AmmoCounter",220)
    SetMemoryPoolSize("BaseHint",100)
    SetMemoryPoolSize("EnergyBar",220)
    SetMemoryPoolSize("EntityCloth",20)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntitySoundStream",2)
    SetMemoryPoolSize("EntitySoundStatic",1)
    SetMemoryPoolSize("LightFlash",25)
    SetMemoryPoolSize("MountedTurret",0)
    SetMemoryPoolSize("Navigator",50)
    SetMemoryPoolSize("Obstacle",157)
    SetMemoryPoolSize("PathFollower",50)
    SetMemoryPoolSize("PathNode",128)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("SoldierAnimation",650)
    SetMemoryPoolSize("UnitAgent",50)
    SetMemoryPoolSize("UnitController",50)
    SetMemoryPoolSize("Weapon",220)
    SetSpawnDelay(10,0.25)
    ReadDataFile("KOR\\KOR.lvl","KOR_conquest")
    SetDenseEnvironment("false")
    SetAIViewMultiplier(0.34999999403954)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\dag.lvl","dag1")
    SetBleedingVoiceOver(local_0,local_0,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(local_0,local_1,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_0,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_1,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(local_0,local_0,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_0,local_1,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_1,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_0,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(local_0,1,"all_dag_amb_start",0,1)
    SetAmbientMusic(local_0,0.80000001192093,"all_dag_amb_middle",1,1)
    SetAmbientMusic(local_0,0.20000000298023,"all_dag_amb_end",2,1)
    SetAmbientMusic(local_1,1,"imp_dag_amb_start",0,1)
    SetAmbientMusic(local_1,0.80000001192093,"imp_dag_amb_middle",1,1)
    SetAmbientMusic(local_1,0.20000000298023,"imp_dag_amb_end",2,1)
    SetVictoryMusic(local_0,"all_dag_amb_victory")
    SetDefeatMusic(local_0,"all_dag_amb_defeat")
    SetVictoryMusic(local_1,"imp_dag_amb_victory")
    SetDefeatMusic(local_1,"imp_dag_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(local_2)
    AddCameraShot(0.32128900289536,0.0042590000666678,-0.94688802957535,0.012552999891341,61.368286132813,7.6194920539856,-567.46673583984)
    AddCameraShot(-0.19268399477005,0.017214000225067,-0.97721797227859,-0.087301000952721,3.3858249187469,22.266441345215,-594.86114501953)
    AddCameraShot(0.96079498529434,0.17424599826336,0.21220399439335,-0.038483999669552,14.760915756226,16.357362747192,-407.85427856445)
    AddCameraShot(0.7258780002594,-0.017681000754237,0.68739199638367,0.016744000837207,235.56272888184,1.3307119607925,-465.75698852539)
    AddCameraShot(0.97421497106552,-0.026978999376297,0.22391800582409,0.0062009999528527,360.6123046875,-6.019552230835,-361.86694335938)
end

