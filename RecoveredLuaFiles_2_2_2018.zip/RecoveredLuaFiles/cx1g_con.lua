--cx1g_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
local local_2 = 1
local local_3 = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({name = "cp1"})
    cp2 = CommandPost:New({name = "cp2"})
    cp3 = CommandPost:New({name = "cp3"})
    cp4 = CommandPost:New({name = "cp4"})

    conquest =
        ObjectiveConquest:New(
        {
            teamATT = local_2,
            teamDEF = local_3,
            textATT = "game.modes.con",
            textDEF = "game.modes.con2",
            multiplayerRules = true
        }
    )
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:Start()
    EnableSPHeroRules()
end
local local_0 = 2
local local_1 = 1

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(40)
    SetMaxPlayerFlyHeight(40)
    SetMemoryPoolSize("ClothData", 20)
    SetMemoryPoolSize("Combo", 50)
    SetMemoryPoolSize("Combo::State", 650)
    SetMemoryPoolSize("Combo::Transition", 650)
    SetMemoryPoolSize("Combo::Condition", 650)
    SetMemoryPoolSize("Combo::Attack", 550)
    SetMemoryPoolSize("Combo::DamageSample", 6000)
    SetMemoryPoolSize("Combo::Deflect", 100)
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\pol.lvl;pol1gcw")
    ReadDataFile(
        "SIDE\\all.lvl",
        "all_inf_rifleman_urban",
        "all_inf_engineer",
        "all_inf_officer",
        "all_inf_wookiee",
        "all_hero_luke_jedi"
    )
    ReadDataFile(
        "SIDE\\imp.lvl",
        "imp_inf_rifleman",
        "imp_inf_rocketeer",
        "imp_inf_engineer",
        "imp_inf_sniper",
        "imp_inf_officer",
        "imp_inf_dark_trooper",
        "imp_hero_emperor",
        "imp_fly_destroyer_dome"
    )
    ReadDataFile("SIDE\\tur.lvl", "tur_bldg_tat_barge", "tur_bldg_laser")
    ReadDataFile(
        "SIDE\\infantry.lvl",
        "all_inf_specialops",
        "all_inf_engineer_urban",
        "all_inf_rocketeer_urban",
        "all_inf_sniper_urban",
        "imp_inf_commando"
    )
    SetupTeams(
        {
            all = {
                team = local_0,
                units = 14,
                reinforcements = 150,
                soldier = {"all_inf_rifleman_urban", 9, 25},
                assault = {"all_inf_rocketeer_urban", 1, 4},
                engineer = {"all_inf_engineer_urban", 1, 4},
                sniper = {"all_inf_sniper_urban", 1, 4},
                officer = {"all_inf_officer", 1, 4},
                special = {"all_inf_wookiee", 1, 4}
            },
            imp = {
                team = local_1,
                units = 14,
                reinforcements = 150,
                soldier = {"imp_inf_rifleman", 9, 25},
                assault = {"imp_inf_rocketeer", 1, 4},
                engineer = {"imp_inf_engineer", 1, 4},
                sniper = {"imp_inf_sniper", 1, 4},
                officer = {"imp_inf_officer", 1, 4},
                special = {"imp_inf_dark_trooper", 1, 4}
            }
        }
    )
    AddUnitClass(local_0, "all_inf_specialops", 1, 2)
    AddUnitClass(local_1, "imp_inf_commando", 1, 2)
    SetHeroClass(local_0, "all_hero_luke_jedi")
    SetHeroClass(local_1, "imp_hero_emperor")
    ClearWalkers()
    AddWalkerType(0, 0)
    AddWalkerType(1, 0)
    AddWalkerType(2, 0)
    AddWalkerType(3, 0)
    SetMemoryPoolSize("Aimer", 75)
    SetMemoryPoolSize("AmmoCounter", 1024)
    SetMemoryPoolSize("BaseHint", 1024)
    SetMemoryPoolSize("EnergyBar", 1024)
    SetMemoryPoolSize("EntityCloth", 32)
    SetMemoryPoolSize("EntityFlyer", 32)
    SetMemoryPoolSize("EntityHover", 32)
    SetMemoryPoolSize("EntityLight", 200)
    SetMemoryPoolSize("EntitySoundStream", 4)
    SetMemoryPoolSize("EntitySoundStatic", 32)
    SetMemoryPoolSize("MountedTurret", 32)
    SetMemoryPoolSize("Navigator", 128)
    SetMemoryPoolSize("Obstacle", 1024)
    SetMemoryPoolSize("PathNode", 1024)
    SetMemoryPoolSize("SoundSpaceRegion", 64)
    SetMemoryPoolSize("TreeGridStack", 1024)
    SetMemoryPoolSize("UnitAgent", 128)
    SetMemoryPoolSize("UnitController", 128)
    SetMemoryPoolSize("Weapon", 1024)
    SetSpawnDelay(10, 0.25)
    ReadDataFile("CX1\\CX1.lvl", "CX1_Conquest")
    SetDenseEnvironment("true")
    SetAIViewMultiplier(0.050000000745058)
    voiceSlow = OpenAudioStream("sound\\global.lvl", "all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_slow", voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl", "des_unit_vo_slow", voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl", "all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_quick", voiceQuick)
    OpenAudioStream("sound\\global.lvl", "gcw_music")
    OpenAudioStream("sound\\tat.lvl", "tat2")
    OpenAudioStream("sound\\tat.lvl", "tat2")
    SetBleedingVoiceOver(local_0, local_0, "all_off_com_report_us_overwhelmed", 1)
    SetBleedingVoiceOver(local_0, local_1, "all_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(local_1, local_0, "imp_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(local_1, local_1, "imp_off_com_report_us_overwhelmed", 1)
    SetLowReinforcementsVoiceOver(local_0, local_0, "all_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(local_0, local_1, "all_off_victory_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(local_1, local_1, "imp_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(local_1, local_0, "imp_off_victory_im", 0.10000000149012, 1)
    SetOutOfBoundsVoiceOver(2, "Allleaving")
    SetOutOfBoundsVoiceOver(1, "Impleaving")
    SetAmbientMusic(local_0, 1, "all_tat_amb_start", 0, 1)
    SetAmbientMusic(local_0, 0.80000001192093, "all_tat_amb_middle", 1, 1)
    SetAmbientMusic(local_0, 0.20000000298023, "all_tat_amb_end", 2, 1)
    SetAmbientMusic(local_1, 1, "imp_tat_amb_start", 0, 1)
    SetAmbientMusic(local_1, 0.80000001192093, "imp_tat_amb_middle", 1, 1)
    SetAmbientMusic(local_1, 0.20000000298023, "imp_tat_amb_end", 2, 1)
    SetVictoryMusic(local_0, "all_tat_amb_victory")
    SetDefeatMusic(local_0, "all_tat_amb_defeat")
    SetVictoryMusic(local_1, "imp_tat_amb_victory")
    SetDefeatMusic(local_1, "imp_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    AddCameraShot(
        0.014526000246406,
        -6.5000000176951e-005,
        -0.99988502264023,
        -0.0044399998150766,
        -0.044491000473499,
        2.466372013092,
        -23.57772064209
    )
    AddCameraShot(
        0.9537690281868,
        -0.022833000868559,
        0.29958701133728,
        0.0071720001287758,
        8.9305582046509,
        3.5308649539948,
        21.776279449463
    )
    AddCameraShot(
        0.9578469991684,
        -0.088636003434658,
        0.27210199832916,
        0.02517900057137,
        5.7797741889954,
        1.920480966568,
        -29.521324157715
    )
    AddCameraShot(
        0.53610801696777,
        0.0079910000786185,
        -0.84401798248291,
        0.012581000104547,
        -95.457893371582,
        1.920480966568,
        -71.743865966797
    )
end
