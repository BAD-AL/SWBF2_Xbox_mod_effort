--shac_duel.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveTDM")

function ScriptPostLoad()
    TDM = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, textATT = "game.modes.tdm", textDEF = "game.modes.tdm2", multiplayerRules = true, isDuelMode = true })
    TDM:Start()
end

function ScriptInit()
    ALL = 1
    IMP = 2
    ATT = 1
    DEF = 2
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(150)
    SetMaxPlayerFlyHeight(150)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\hot.lvl;hot1gcw")
    ReadDataFile("SIDE\\heroes.lvl","imp_hero_bossk","all_hero_dashrendar","imp_hero_greedo","all_hero_lando")
    SetupTeams({ 
        hero =         { team = ALL, units = 32, reinforcements = -1, 
          soldier =           { "all_hero_dashrendar", 1, 1 }, 
          sniper =           { "all_hero_lando", 1, 1 }
         }, 
        villain =         { team = IMP, units = 32, reinforcements = -1, 
          soldier =           { "imp_hero_bossk", 1, 1 }, 
          sniper =           { "imp_hero_greedo", 1, 1 }
         }
       })
    AddWalkerType(0,4)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("AmmoCounter",1024)
    SetMemoryPoolSize("BaseHint",1024)
    SetMemoryPoolSize("EnergyBar",1024)
    SetMemoryPoolSize("EntityCloth",32)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityHover",32)
    SetMemoryPoolSize("EntityLight",200)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",32)
    SetMemoryPoolSize("MountedTurret",32)
    SetMemoryPoolSize("Navigator",128)
    SetMemoryPoolSize("Obstacle",1024)
    SetMemoryPoolSize("PathNode",1024)
    SetMemoryPoolSize("SoundSpaceRegion",64)
    SetMemoryPoolSize("TreeGridStack",1024)
    SetMemoryPoolSize("UnitAgent",128)
    SetMemoryPoolSize("UnitController",128)
    SetMemoryPoolSize("Weapon",1024)
    SetMemoryPoolSize("SoldierAnimation",1000)
    SetSpawnDelay(10,0.25)
    ReadDataFile("SHA\\SHA.lvl","SHA_eli")
    SetDenseEnvironment("false")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetAmbientMusic(REP,1,"rep_dag_amb_start",0,1)
    SetAmbientMusic(REP,0.80000001192093,"rep_dag_amb_middle",1,1)
    SetAmbientMusic(REP,0.20000000298023,"rep_dag_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_dag_amb_start",0,1)
    SetAmbientMusic(CIS,0.80000001192093,"cis_dag_amb_middle",1,1)
    SetAmbientMusic(CIS,0.20000000298023,"cis_dag_amb_end",2,1)
    SetVictoryMusic(REP,"rep_dag_amb_victory")
    SetDefeatMusic(REP,"rep_dag_amb_defeat")
    SetVictoryMusic(CIS,"cis_dag_amb_victory")
    SetDefeatMusic(CIS,"cis_dag_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.73300802707672,-0.042259998619556,0.67777997255325,0.039076000452042,-0.302630007267,28.794353485107,75.827964782715)
    AddCameraShot(0.75283199548721,0.032205998897552,0.65682297945023,-0.028098000213504,80.700004577637,52.86413192749,7.2932300567627)
    AddCameraShot(0.73817300796509,-0.18660500645638,0.62851798534393,0.15888500213623,80.287796020508,56.51651763916,7.3138041496277)
    AddCameraShot(0.97721201181412,-0.18520499765873,0.10189999639988,0.019311999902129,68.38257598877,45.097171783447,-38.306804656982)
end

