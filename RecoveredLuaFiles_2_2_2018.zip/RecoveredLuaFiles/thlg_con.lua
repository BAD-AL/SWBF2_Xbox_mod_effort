--thlg_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
local local_2 = 2
local local_3 = 1

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "cp1" })
    cp2 = CommandPost:New({ name = "cp2" })
    cp3 = CommandPost:New({ name = "cp3" })
    cp4 = CommandPost:New({ name = "cp4" })
    conquest = ObjectiveConquest:New({ teamATT = local_2, teamDEF = local_3, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:Start()
    EnableSPHeroRules()
end
local local_0 = 2
local local_1 = 1

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(60)
    SetMaxPlayerFlyHeight(60)
    SetGroundFlyerMap(1)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\veh.lvl;atat_atpt_guns")
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\myg.lvl;myg1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_inf_officer","all_inf_wookiee","all_hero_chewbacca","all_hover_combatspeeder")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_darthvader","imp_walk_atst")
    ReadDataFile("SIDE\\swbf1.lvl","all_hover_swbf1_speeder")
    ReadDataFile("SIDE\\vehicles.lvl","all_hover_hovernaut","all_walk_atpt","imp_walk_atat","imp_walk_atpt")
    ReadDataFile("SIDE\\infantry.lvl","all_inf_specialops","imp_inf_commando")
    SetupTeams({ 
        all =         { team = local_0, units = 20, reinforcements = 150, 
          soldier =           { "all_inf_rifleman", 9, 25 }, 
          assault =           { "all_inf_rocketeer", 1, 4 }, 
          engineer =           { "all_inf_engineer", 1, 4 }, 
          sniper =           { "all_inf_sniper", 1, 4 }, 
          officer =           { "all_inf_officer", 1, 4 }, 
          special =           { "all_inf_wookiee", 1, 4 }
         }, 
        imp =         { team = local_1, units = 20, reinforcements = 150, 
          soldier =           { "imp_inf_rifleman", 9, 25 }, 
          assault =           { "imp_inf_rocketeer", 1, 4 }, 
          engineer =           { "imp_inf_engineer", 1, 4 }, 
          sniper =           { "imp_inf_sniper", 1, 4 }, 
          officer =           { "imp_inf_officer", 1, 4 }, 
          special =           { "imp_inf_dark_trooper", 1, 4 }
         }
       })
    AddUnitClass(local_0,"all_inf_specialops",1,2)
    AddUnitClass(local_1,"imp_inf_commando",1,2)
    SetHeroClass(local_0,"all_hero_chewbacca")
    SetHeroClass(local_1,"imp_hero_darthvader")
    ClearWalkers()
    AddWalkerType(0,0)
    AddWalkerType(1,5)
    AddWalkerType(2,2)
    SetMemoryPoolSize("Aimer",80)
    SetMemoryPoolSize("AmmoCounter",221)
    SetMemoryPoolSize("BaseHint",175)
    SetMemoryPoolSize("CommandHover",1)
    SetMemoryPoolSize("CommandWalker",2)
    SetMemoryPoolSize("ConnectivityGraphFollower",56)
    SetMemoryPoolSize("EnergyBar",221)
    SetMemoryPoolSize("EntityCloth",41)
    SetMemoryPoolSize("EntityHover",16)
    SetMemoryPoolSize("EntityFlyer",10)
    SetMemoryPoolSize("EntityLight",110)
    SetMemoryPoolSize("EntitySoundStatic",16)
    SetMemoryPoolSize("EntitySoundStream",5)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",54)
    SetMemoryPoolSize("MountedTurret",0)
    SetMemoryPoolSize("Navigator",63)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("PathFollower",63)
    SetMemoryPoolSize("PathNode",128)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("TreeGridStack",300)
    SetMemoryPoolSize("UnitController",63)
    SetMemoryPoolSize("UnitAgent",63)
    SetMemoryPoolSize("Weapon",221)
    SetMemoryPoolSize("SoldierAnimation",500)
    ReadDataFile("THL\\THL.lvl","THL_conquest")
    SetSpawnDelay(10,0.25)
    SetDenseEnvironment("true")
    SetDefenderSnipeRange(170)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","des_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\myg.lvl","myg1gcw")
    OpenAudioStream("sound\\myg.lvl","myg1gcw")
    SetBleedingVoiceOver(local_0,local_0,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(local_0,local_1,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_0,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_1,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(local_0,local_0,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_0,local_1,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_1,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_0,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(local_0,1,"all_myg_amb_start",0,1)
    SetAmbientMusic(local_0,0.80000001192093,"all_myg_amb_middle",1,1)
    SetAmbientMusic(local_0,0.20000000298023,"all_myg_amb_end",2,1)
    SetAmbientMusic(local_1,1,"imp_myg_amb_start",0,1)
    SetAmbientMusic(local_1,0.80000001192093,"imp_myg_amb_middle",1,1)
    SetAmbientMusic(local_1,0.20000000298023,"imp_myg_amb_end",2,1)
    SetVictoryMusic(local_0,"all_myg_amb_victory")
    SetDefeatMusic(local_0,"all_myg_amb_defeat")
    SetVictoryMusic(local_1,"imp_myg_amb_victory")
    SetDefeatMusic(local_1,"imp_myg_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraSmyg2(0.31685900688171,0.048675999045372,-0.93624001741409,0.14382499456406,-5.093300819397,-0.4767589867115,225.4052734375)
    AddCameraSmyg2(0.95786499977112,0.015587000176311,0.28675800561905,-0.0046660001389682,44.362850189209,31.322568893433,69.101692199707)
    AddCameraSmyg2(0.26821199059486,-0.042072001844645,-0.95081502199173,-0.14914399385452,-167.78086853027,63.66482925415,-54.951042175293)
    AddCameraSmyg2(0.93150001764297,0.13357900083065,-0.33489999175072,0.048025000840425,-230.71159362793,0.84246402978897,341.54949951172)
end

