--kam1c_hunt.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveTDM")

function ScriptPostLoad()
    hunt = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, pointsPerKillATT = 1, pointsPerKillDEF = 1, textATT = "game.mode.tdm", textDEF = "game.mode.tdm2", multiplayerRules = true })
    hunt:Start()
    SetProperty("cp1","CaptureRegion","")
    SetProperty("cp2","CaptureRegion","")
    SetProperty("cp3","CaptureRegion","")
    SetProperty("cp4","CaptureRegion","")
    SetProperty("cp5","CaptureRegion","")
    SetProperty("cp6","CaptureRegion","")
    SetProperty("cp1","Team","1")
    SetProperty("cp2","Team","2")
    SetProperty("cp3","Team","2")
    SetProperty("cp4","Team","2")
    SetProperty("cp5","Team","1")
    SetProperty("cp6","Team","1")
end

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\kam.lvl;kam1cross")
    SetMinFlyHeight(60)
    SetAllowBlindJetJumps(0)
    SetMaxFlyHeight(102)
    SetMaxPlayerFlyHeight(102)
    SetMemoryPoolSize("ClothData",30)
    SetMemoryPoolSize("Combo",70)
    SetMemoryPoolSize("Combo::State",850)
    SetMemoryPoolSize("Combo::Transition",850)
    SetMemoryPoolSize("Combo::Condition",850)
    SetMemoryPoolSize("Combo::Attack",750)
    SetMemoryPoolSize("Combo::DamageSample",8000)
    SetMemoryPoolSize("Combo::Deflect",140)
    ALL = 1
    IMP = 2
    ATT = 1
    DEF = 2
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep2_rocketeer","rep_inf_ep2_rifleman","rep_inf_ep2_jettrooper","rep_inf_ep2_sniper","rep_inf_ep2_engineer")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_dark_trooper","imp_inf_officer")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_ep2_officer","rep_inf_commando","imp_inf_commando")
    SetupTeams({ 
        rogue =         { team = ALL, units = 20, reinforcements = 150, 
          soldier =           { "rep_inf_ep2_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep2_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep2_engineer", 1, 4 }, 
          sniper =           { "rep_inf_ep2_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep2_officer", 1, 4 }, 
          special =           { "rep_inf_ep2_jettrooper", 1, 4 }
         }, 
        imp =         { team = IMP, units = 29, reinforcements = 150, 
          soldier =           { "imp_inf_rifleman", 10, 25 }, 
          assault =           { "imp_inf_rocketeer", 1, 4 }, 
          engineer =           { "imp_inf_engineer", 1, 4 }, 
          sniper =           { "imp_inf_sniper", 1, 4 }, 
          officer =           { "imp_inf_officer", 1, 4 }, 
          special =           { "imp_inf_dark_trooper", 1, 4 }
         }
       })
    AddUnitClass(ALL,"rep_inf_commando",1,2)
    AddUnitClass(IMP,"imp_inf_commando",1,2)
    ClearWalkers()
    SetMemoryPoolSize("Aimer",1)
    SetMemoryPoolSize("AmmoCounter",150)
    SetMemoryPoolSize("BaseHint",320)
    SetMemoryPoolSize("ConnectivityGraphFollower",23)
    SetMemoryPoolSize("EnergyBar",150)
    SetMemoryPoolSize("EntityCloth",41)
    SetMemoryPoolSize("EntityDefenseGridTurret",0)
    SetMemoryPoolSize("EntityDroid",0)
    SetMemoryPoolSize("EntityFlyer",5)
    SetMemoryPoolSize("EntityLight",80,80)
    SetMemoryPoolSize("EntityPortableTurret",0)
    SetMemoryPoolSize("EntitySoundStream",2)
    SetMemoryPoolSize("EntitySoundStatic",45)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",120)
    SetMemoryPoolSize("MountedTurret",0)
    SetMemoryPoolSize("Navigator",30)
    SetMemoryPoolSize("Obstacle",667)
    SetMemoryPoolSize("Ordnance",80)
    SetMemoryPoolSize("ParticleEmitter",512)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("PathFollower",30)
    SetMemoryPoolSize("PathNode",128)
    SetMemoryPoolSize("SoldierAnimation",1200)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("TentacleSimulator",24)
    SetMemoryPoolSize("TreeGridStack",290)
    SetMemoryPoolSize("UnitAgent",30)
    SetMemoryPoolSize("UnitController",35)
    SetMemoryPoolSize("Weapon",150)
    SetSpawnDelay(10,0.25)
    ReadDataFile("kam\\kam1.lvl","kamino1_Conquest")
    SetDenseEnvironment("true")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","imp_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","rep_unit_vo_quick",voiceQuick)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\kam.lvl","kam1")
    OpenAudioStream("sound\\kam.lvl","kam1")
    SetBleedingVoiceOver(ALL,ALL,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(ALL,ALL,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(ALL,IMP,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"rep_kam_amb_start",0,1)
    SetAmbientMusic(ALL,0.80000001192093,"rep_kam_amb_middle",1,1)
    SetAmbientMusic(ALL,0.20000000298023,"rep_kam_amb_end",2,1)
    SetAmbientMusic(IMP,1,"rep_kam_amb_start",0,1)
    SetAmbientMusic(IMP,0.80000001192093,"rep_kam_amb_middle",1,1)
    SetAmbientMusic(IMP,0.20000000298023,"rep_kam_amb_end",2,1)
    SetVictoryMusic(ALL,"rep_kam_amb_victory")
    SetDefeatMusic(ALL,"rep_kam_amb_defeat")
    SetVictoryMusic(IMP,"rep_kam_amb_victory")
    SetDefeatMusic(IMP,"rep_kam_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddDeathRegion("deathregion")
    AddCameraShot(0.56461900472641,-0.12104699760675,0.79828798770905,0.17114199697971,68.19881439209,79.13761138916,110.85092163086)
    AddCameraShot(-0.28110000491142,0.066889002919197,-0.93133997917175,-0.22161599993706,10.076019287109,82.958335876465,-26.26177406311)
    AddCameraShot(0.20955300331116,-0.039035998284817,-0.96049499511719,-0.17892299592495,92.558563232422,58.820617675781,130.6759185791)
    AddCameraShot(0.96879398822784,0.15422700345516,0.19162699580193,-0.030505999922752,-173.91441345215,69.858940124512,52.532421112061)
    AddCameraShot(0.74438899755478,0.12353900074959,0.6473640203476,-0.10743699967861,97.475639343262,53.216236114502,76.477088928223)
    AddCameraShot(-0.34415200352669,0.08670199662447,-0.90657502412796,-0.22839300334454,95.062232971191,105.28582000732,-37.661552429199)
end

function OnStart(OnStartParam0)
    AddAIGoal(ATT,"Deathmatch",1000)
    AddAIGoal(DEF,"Deathmatch",1000)
end

