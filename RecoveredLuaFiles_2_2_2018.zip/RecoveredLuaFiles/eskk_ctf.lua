--eskk_ctf.lua
-- Decompiled with SWBF2CodeHelper
Conquest = ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")
ALL = 1
IMP = 2
ATT = ALL
DEF = IMP

function ScriptPostLoad()
    SoundEvent_SetupTeams(ALL,"all",IMP,"imp")
    SetProperty("flag1","GeometryName","com_icon_republic_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_republic_flag_carried")
    SetProperty("flag2","GeometryName","com_icon_cis_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_cis_flag_carried")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ALL, teamDEF = IMP, captureLimit = 5, textATT = "game.modes.ctf", textDEF = "game.modes.ctf2", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "2flag_team1_capture", captureRegion = "2flag_team2_capture", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "2flag_team2_capture", captureRegion = "2flag_team1_capture", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(30)
    SetMaxPlayerFlyHeight(30)
    SetMemoryPoolSize("ClothData",100)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\tan.lvl;tan1gcw")
    ReadDataFile("SIDE\\rep.lvl","rep_hero_obiwan","rep_hero_kiyadimundi")
    ReadDataFile("SIDE\\kotor.lvl","kor_hero_mandalore","kor_hero_nihilus","rvs_inf_rbasic","rvs_inf_sbasic","rvs_inf_rheavy","rvs_inf_sheavy","rvs_inf_rsupport","rvs_inf_ssupport","rvs_inf_rstealth","rvs_inf_sstealth","rvs_inf_sadept","rvs_inf_radept","rvs_inf_rofficer","rvs_inf_sofficer","rvs_inf_rdroid","rvs_inf_sdroid")
    SetupTeams({ 
        rep =         { team = ALL, units = 20, reinforcements = 150, 
          soldier =           { "rvs_inf_rbasic", 7, 24 }, 
          assault =           { "rvs_inf_rheavy", 2, 8 }, 
          engineer =           { "rvs_inf_rdroid", 2, 8 }, 
          sniper =           { "rvs_inf_rsupport", 2, 8 }, 
          officer =           { "rvs_inf_rofficer", 2, 8 }, 
          special =           { "rvs_inf_rstealth", 1, 4 }
         }, 
        imp =         { team = IMP, units = 20, reinforcements = 150, 
          soldier =           { "rvs_inf_sbasic", 7, 24 }, 
          assault =           { "rvs_inf_sheavy", 2, 8 }, 
          engineer =           { "rvs_inf_sdroid", 2, 8 }, 
          sniper =           { "rvs_inf_ssupport", 2, 8 }, 
          officer =           { "rvs_inf_sofficer", 2, 8 }, 
          special =           { "rvs_inf_sstealth", 1, 4 }
         }
       })
    AddUnitClass(ALL,"rvs_inf_radept",1,2)
    AddUnitClass(IMP,"rvs_inf_sadept",1,2)
    SetHeroClass(ALL,"kor_hero_mandalore")
    SetHeroClass(IMP,"kor_hero_nihilus")
    AddWalkerType(0,4)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("AmmoCounter",1024)
    SetMemoryPoolSize("BaseHint",1024)
    SetMemoryPoolSize("EnergyBar",1024)
    SetMemoryPoolSize("EntityCloth",32)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityHover",32)
    SetMemoryPoolSize("EntityLight",200)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",32)
    SetMemoryPoolSize("MountedTurret",32)
    SetMemoryPoolSize("Navigator",128)
    SetMemoryPoolSize("Obstacle",1024)
    SetMemoryPoolSize("PathNode",1024)
    SetMemoryPoolSize("SoundSpaceRegion",64)
    SetMemoryPoolSize("TreeGridStack",1024)
    SetMemoryPoolSize("UnitAgent",128)
    SetMemoryPoolSize("UnitController",128)
    SetMemoryPoolSize("Weapon",1024)
    SetMemoryPoolSize("FlagItem",2)
    SetSpawnDelay(10,0.25)
    ReadDataFile("ESK\\ESK.lvl","ESK_ctf")
    SetDenseEnvironment("true")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\ESK.lvl","ESKcross_music")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1_emt")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_allort_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_allort_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_allort_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_allort_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetAmbientMusic(ALL,1,"cross_ESK_amb_start",0,1)
    SetAmbientMusic(IMP,1,"cross_ESK_amb_start",0,1)
    SetVictoryMusic(ALL,"all_yav_amb_victory")
    SetDefeatMusic(ALL,"all_yav_amb_defeat")
    SetVictoryMusic(IMP,"imp_yav_amb_victory")
    SetDefeatMusic(IMP,"imp_yav_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.50274902582169,-0.011367999948561,0.86413699388504,0.019539000466466,142.58670043945,2.5306398868561,166.22665405273)
    AddCameraShot(0.86213302612305,0.012934999540448,0.5064600110054,-0.0075989998877048,50.841514587402,2.5306398868561,153.55166625977)
    AddCameraShot(0.79983997344971,0.016191000118852,0.59987199306488,-0.012143000029027,-75.426422119141,4.7940888404846,151.68447875977)
    AddCameraShot(0.63314098119736,-0.0034620000515133,-0.77401697635651,-0.004232999868691,-85.371620178223,6.2829570770264,137.96942138672)
    AddCameraShot(0.86663401126862,-0.016293000429869,0.49858999252319,0.0093740001320839,12.09645652771,4.7616291046143,113.7106552124)
    AddCameraShot(0.21403899788857,-0.00096700002904981,-0.97681498527527,-0.0044120000675321,159.55409240723,2.8692378997803,116.80983734131)
end

