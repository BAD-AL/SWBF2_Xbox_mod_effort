--nplc_hunt.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    SetProperty("CP1","Team","2")
    SetProperty("CP2","Team","2")
    SetProperty("CP3","Team","1")
    SetProperty("CP4","Team","1")
    SetProperty("CP1","CaptureRegion","")
    SetProperty("CP2","CaptureRegion","")
    SetProperty("CP3","CaptureRegion","")
    SetProperty("CP4","CaptureRegion","")
    SetProperty("CP11","CaptureRegion","")
    KillObject("CP11")
    hunt = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, pointsPerKillATT = 6, pointsPerKillDEF = 1, textATT = "game.modes.hunt2", textDEF = "game.modes.hunt", multiplayerRules = true })
    hunt:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(70)
    ReadDataFile("sound\\kas.lvl;kas2cw")
    ReadDataFile("SIDE\\gun.lvl","gun_inf_defender","gun_inf_rider","gun_inf_soldier")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka")
    SetupTeams({ 
        gun =         { team = REP, units = 29, reinforcements = 150, 
          soldier =           { "gun_inf_defender", 5, 20 }, 
          assault =           { "gun_inf_rider", 5, 20 }, 
          engineer =           { "gun_inf_soldier", 5, 20 }
         }, 
        cis =         { team = CIS, units = 29, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 10, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_engineer", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          officer =           { "cis_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    ClearWalkers()
    AddWalkerType(0,0)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",100)
    SetMemoryPoolSize("BaseHint",240)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntityCloth",80)
    SetMemoryPoolSize("EntityHover",15)
    SetMemoryPoolSize("EntityLight",60)
    SetMemoryPoolSize("MountedTurret",20)
    SetMemoryPoolSize("Obstacle",590)
    SetMemoryPoolSize("PathNode",512)
    SetMemoryPoolSize("TentacleSimulator",22)
    SetMemoryPoolSize("TreeGridStack",300)
    SetMemoryPoolSize("Weapon",265)
    SetSpawnDelay(10,0.25)
    ReadDataFile("NPL\\nab1.lvl","nab1_conquest")
    SetDenseEnvironment("false")
    SetMaxFlyHeight(65)
    SetMaxPlayerFlyHeight(65)
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    voiceSlow = OpenAudioStream("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","gun_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    AudioStreamAppendSegments("sound\\global.lvl","wok_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\kas.lvl","kas")
    SetAmbientMusic(REP,1,"rep_kas_amb_hunt",0,1)
    SetAmbientMusic(CIS,1,"cis_kas_amb_hunt",0,1)
    SetVictoryMusic(REP,"rep_kas_amb_victory")
    SetDefeatMusic(REP,"rep_kas_amb_defeat")
    SetVictoryMusic(CIS,"cis_kas_amb_victory")
    SetDefeatMusic(CIS,"cis_kas_amb_defeat")
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.97764199972153,-0.052163001149893,-0.20341399312019,-0.010852999985218,66.539520263672,21.86496925354,168.5984954834)
    AddCameraShot(0.9694550037384,-0.011915000155568,0.24495999515057,0.0030110001098365,219.55294799805,21.86496925354,177.67567443848)
    AddCameraShot(0.99503999948502,-0.013446999713778,0.098558001220226,0.0013320000143722,133.5712890625,16.216758728027,121.57123565674)
    AddCameraShot(0.35043299198151,-0.049724999815226,-0.92599099874496,-0.13139399886131,30.085187911987,32.105236053467,-105.32526397705)
    AddCameraShot(0.16336899995804,-0.029668999835849,-0.97024899721146,-0.17620299756527,85.474830627441,47.313362121582,-156.34562683105)
    AddCameraShot(0.09111200273037,-0.011521000415087,-0.98790699243546,-0.12492000311613,97.554061889648,53.690967559814,-179.34707641602)
    AddCameraShot(0.96495300531387,-0.059962000697851,0.25498801469803,0.015845000743866,246.47100830078,20.362142562866,153.70104980469)
end

function OnStart(OnStartParam0)
    AddAIGoal(ATT,"Deathmatch",1000)
    AddAIGoal(DEF,"Deathmatch",1000)
end

