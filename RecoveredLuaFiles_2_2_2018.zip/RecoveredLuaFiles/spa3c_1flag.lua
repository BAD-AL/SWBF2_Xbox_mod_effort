--spa3c_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("LinkedTurrets")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveOneFlagCTF:New({ teamATT = REP, teamDEF = CIS, textATT = "game.modes.1flag", textDEF = "game.modes.1flag2", flag = "cmn_flag", homeRegion = "home_1flag", captureRegionATT = "Team1capture", captureRegionDEF = "Team2capture", capRegionDummyObjectATT = "rep_cap_marker", capRegionDummyObjectDEF = "cis_cap_marker", multiplayerRules = true, hideCPs = true, AIGoalWeight = 0 })
    SoundEvent_SetupTeams(REP,"rep",CIS,"cis")
    ctf:Start()
    SetupTurrets()
    AddAIGoal(REP,"Deathmatch",100)
    AddAIGoal(CIS,"Deathmatch",100)
    SetProperty("rep_eng_door","IsLocked",1)
    SetProperty("rep_shi_door","IsLocked",1)
    SetProperty("rep_lif_door","IsLocked",1)
    SetProperty("cis_eng_door","IsLocked",1)
    SetProperty("cis_shi_door","IsLocked",1)
    SetProperty("cis_lif_door","IsLocked",1)
    SetProperty("rep_eng_lightg","IsVisible",0)
    SetProperty("rep_shi_lightg","IsVisible",0)
    SetProperty("rep_lif_lightg","IsVisible",0)
    SetProperty("cis_eng_lightg","IsVisible",0)
    SetProperty("cis_shi_lightg","IsVisible",0)
    SetProperty("cis_lif_lightg","IsVisible",0)
    BlockPlanningGraphArcs("cis_blk01","cis_blk02")
    BlockPlanningGraphArcs("rep_blk01","rep_blk02")
    SetProperty("cap_box01","IsVisible",0)
    SetProperty("cap_box01","IsCollidible ",0)
end

function SetupTurrets()
    LinkedTurretsCIS = LinkedTurrets:New({ team = CIS, mainframe = "cis_main", 
        turrets =         { "cis_obj01", "cis_obj02", "cis_obj03", "cis_obj04", "cis_obj05" }
       })
    LinkedTurretsCIS:Init()
    LinkedTurretsREP = LinkedTurrets:New({ team = REP, mainframe = "rep_main", 
        turrets =         { "rep_at01", "rep_at02", "rep_at03", "rep_at04", "rep_at05", "rep_at06" }
       })
    LinkedTurretsREP:Init()
end

function ScriptPreInit()
    SetWorldExtents(1900)
end

function ScriptInit()
    StealArtistHeap(500 * 1024)
    SetPS2ModelMemory(4680000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("SPA\\spa_sky.lvl","kas")
    SetMinFlyHeight(-1900)
    SetMaxFlyHeight(2000)
    SetMinPlayerFlyHeight(-1900)
    SetMaxPlayerFlyHeight(2000)
    SetAIVehicleNotifyRadius(100)
    ReadDataFile("sound\\spa.lvl;spa2cw")
    ScriptCB_SetDopplerFactor(0.40000000596046)
    ScaleSoundParameter("tur_weapons","MinDistance",3)
    ScaleSoundParameter("tur_weapons","MaxDistance",3)
    ScaleSoundParameter("tur_weapons","MuteDistance",3)
    ScaleSoundParameter("Ordnance_Large","MinDistance",3)
    ScaleSoundParameter("Ordnance_Large","MaxDistance",3)
    ScaleSoundParameter("Ordnance_Large","MuteDistance",3)
    ScaleSoundParameter("explosion","MaxDistance",5)
    ScaleSoundParameter("explosion","MuteDistance",5)
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_pilot","rep_inf_ep3_marine","rep_fly_assault_dome","rep_fly_anakinstarfighter_sc","rep_fly_arc170fighter_sc","rep_veh_remote_terminal","rep_fly_arc170fighter_dome","rep_fly_vwing")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_pilot","cis_inf_marine","cis_fly_fedlander_dome","cis_fly_droidfighter_sc","cis_fly_droidfighter_dome","cis_fly_greviousfighter","cis_fly_tridroidfighter")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_spa_rep_beam","tur_bldg_spa_rep_chaingun","tur_bldg_spa_cis_chaingun","tur_bldg_spa_cis_recoilless","tur_bldg_chaingun_roof")
    SetupTeams({ 
        rep =         { team = REP, units = 32, reinforcements = -1, 
          pilot =           { "rep_inf_ep3_pilot", 32 }
         }, 
        cis =         { team = CIS, units = 32, reinforcements = -1, 
          pilot =           { "cis_inf_pilot", 32 }
         }
       })
    ClearWalkers()
    SetMemoryPoolSize("Aimer",350)
    SetMemoryPoolSize("AmmoCounter",240)
    SetMemoryPoolSize("BaseHint",100)
    SetMemoryPoolSize("EnergyBar",240)
    SetMemoryPoolSize("EntityDroid",0)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityLight",90)
    SetMemoryPoolSize("EntityMine",32)
    SetMemoryPoolSize("EntityRemoteTerminal",12)
    SetMemoryPoolSize("EntitySoundStream",48)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",100)
    SetMemoryPoolSize("FlagItem",1)
    SetMemoryPoolSize("Obstacle",120)
    SetMemoryPoolSize("PathNode",48)
    SetMemoryPoolSize("TreeGridStack",200)
    SetMemoryPoolSize("UnitController",90)
    SetMemoryPoolSize("UnitAgent",90)
    SetMemoryPoolSize("Weapon",240)
    SetSpawnDelay(10,0.25)
    ReadDataFile("spa\\spa3.lvl","spa3_ctf")
    SetDenseEnvironment("false")
    AddDeathRegion("deathregionrep")
    AddDeathRegion("deathregioncis")
    SetParticleLODBias(15000)
    OpenAudioStream("sound\\global.lvl","spa1_objective_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","rep_unit_vo_slow",OpenAudioStream())
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",OpenAudioStream())
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",OpenAudioStream())
    OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",OpenAudioStream())
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\spa.lvl","spa")
    OpenAudioStream("sound\\spa.lvl","spa")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(REP,REP,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(REP,CIS,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,CIS,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,REP,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(REP,"Repleaving")
    SetOutOfBoundsVoiceOver(CIS,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_spa_amb_start",0,1)
    SetAmbientMusic(REP,0.99000000953674,"rep_spa_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_spa_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_spa_amb_start",0,1)
    SetAmbientMusic(CIS,0.99000000953674,"cis_spa_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_spa_amb_end",2,1)
    SetVictoryMusic(REP,"rep_spa_amb_victory")
    SetDefeatMusic(REP,"rep_spa_amb_defeat")
    SetVictoryMusic(CIS,"cis_spa_amb_victory")
    SetDefeatMusic(CIS,"cis_spa_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.9612529873848,-0.041343998163939,-0.27229601144791,-0.011711999773979,846.78173828125,42.129261016846,1632.9904785156)
    AddCameraShot(0.95020699501038,0.025973999872804,0.3104200065136,-0.0084849996492267,919.84033203125,42.129261016846,1735.5407714844)
    AddCameraShot(0.94821298122406,-0.12693099677563,-0.28859600424767,-0.038632001727819,-753.10620117188,743.6220703125,2686.2229003906)
    AddCameraShot(-0.32583901286125,0.049463000148535,-0.93343698978424,-0.14169600605965,2249.0834960938,743.6220703125,-1105.5325927734)
    AddLandingRegion("CP1Control")
    AddLandingRegion("CP2Control")
if gPlatformStr == "PS2" then
end
    ScriptCB_DisableFlyerShadows()
end

function OnDisableMainframe(OnDisableMainframeParam0)
    ShowMessageText("level.spa.hangar.mainframe.atk.down",REP)
    ShowMessageText("level.spa.hangar.mainframe.def.down",CIS)
    BroadcastVoiceOver("ROSMP_obj_20",REP)
    BroadcastVoiceOver("COSMP_obj_21",CIS)
end

function OnEnableMainframe(OnEnableMainframeParam0)
    ShowMessageText("level.spa.hangar.mainframe.atk.up",REP)
    ShowMessageText("level.spa.hangar.mainframe.def.up",CIS)
    BroadcastVoiceOver("ROSMP_obj_22",REP)
    BroadcastVoiceOver("COSMP_obj_23",CIS)
end

function OnDisableMainframe(OnDisableMainframeParam0)
    ShowMessageText("level.spa.hangar.mainframe.atk.down",CIS)
    ShowMessageText("level.spa.hangar.mainframe.def.down",REP)
    BroadcastVoiceOver("ROSMP_obj_21",REP)
    BroadcastVoiceOver("COSMP_obj_20",CIS)
end

function OnEnableMainframe(OnEnableMainframeParam0)
    ShowMessageText("level.spa.hangar.mainframe.atk.up",CIS)
    ShowMessageText("level.spa.hangar.mainframe.def.up",REP)
    BroadcastVoiceOver("ROSMP_obj_23",REP)
    BroadcastVoiceOver("COSMP_obj_22",CIS)
end

