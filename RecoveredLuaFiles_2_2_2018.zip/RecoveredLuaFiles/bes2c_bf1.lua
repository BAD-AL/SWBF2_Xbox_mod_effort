--bes2c_bf1.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
local local_2 = 1
local local_3 = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "CP1" })
    cp2 = CommandPost:New({ name = "CP2" })
    cp3 = CommandPost:New({ name = "CP3" })
    cp4 = CommandPost:New({ name = "CP4" })
    cp5 = CommandPost:New({ name = "CP5" })
    cp6 = CommandPost:New({ name = "CP7" })
    conquest = ObjectiveConquest:New({ teamATT = local_2, teamDEF = local_3, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)
    conquest:Start()
    EnableSPHeroRules()
end
local local_0 = 1
local local_1 = 2

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(-5)
    SetMaxPlayerFlyHeight(-5)
    ReadDataFile("sound\\hero.lvl;herogcw")
    ReadDataFile("sound\\dea.lvl;dea1cw")
    ReadDataFile("SIDE\\swbf1.lvl","rep_inf_ep2_rifleman","rep_inf_ep2_rocketeer","rep_inf_ep2_pilot","rep_inf_ep2_sniper","rep_inf_ep2_jettrooper","cis_inf_droideka_hunt","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_pilot","cis_inf_sniper")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_droideka")
    SetupTeams({ 
        rep =         { team = local_0, units = 20, reinforcements = 150, 
          soldier =           { "rep_inf_ep2_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep2_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep2_pilot", 1, 4 }, 
          sniper =           { "rep_inf_ep2_sniper", 1, 4 }, 
          special =           { "rep_inf_ep2_jettrooper", 1, 4 }
         }, 
        cis =         { team = local_1, units = 20, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_pilot", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          special =           { "cis_inf_droideka_hunt", 1, 4 }
         }
       })
    ClearWalkers()
    AddWalkerType(0,12)
    SetMemoryPoolSize("MountedTurret",10)
    SetMemoryPoolSize("Obstacle",514)
    SetMemoryPoolSize("Weapon",280)
    SetMemoryPoolSize("SoundSpaceRegion",38)
    SetSpawnDelay(10,0.25)
    ReadDataFile("BES\\bes2.lvl","bespin2_Conquest")
    SetDenseEnvironment("true")
    AddDeathRegion("DeathRegion")
    AddDeathRegion("DeathRegion2")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\dea.lvl","dea1")
    SetBleedingVoiceOver(local_0,local_0,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(local_0,local_1,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_0,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_1,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(local_0,local_0,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_0,local_1,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_1,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_0,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(local_0,1,"rep_dea_amb_start",0,1)
    SetAmbientMusic(local_0,0.80000001192093,"rep_dea_amb_middle",1,1)
    SetAmbientMusic(local_0,0.20000000298023,"rep_dea_amb_end",2,1)
    SetAmbientMusic(local_1,1,"cis_dea_amb_start",0,1)
    SetAmbientMusic(local_1,0.80000001192093,"cis_dea_amb_middle",1,1)
    SetAmbientMusic(local_1,0.20000000298023,"cis_dea_amb_end",2,1)
    SetVictoryMusic(local_0,"rep_dea_amb_victory")
    SetDefeatMusic(local_0,"rep_dea_amb_defeat")
    SetVictoryMusic(local_1,"cis_dea_amb_victory")
    SetDefeatMusic(local_1,"cis_dea_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.87934798002243,-0.14204600453377,0.4486840069294,0.072477996349335,-38.413761138916,30.986400604248,195.87962341309)
    AddCameraShot(0.75514298677444,0.032623998820782,0.65413701534271,-0.028260000050068,-80.924102783203,-32.534858703613,59.805065155029)
    AddCameraShot(0.59651398658752,-0.068856000900269,-0.79437202215195,-0.091695003211498,-139.20362854004,-28.934867858887,56.316780090332)
    AddCameraShot(0.073601998388767,-0.011602000333369,-0.98505997657776,-0.15527200698853,-118.28823852539,-28.934867858887,125.93835449219)
    AddCameraShot(0.90268701314926,0.0012740000383928,0.43029499053955,-0.00060700002359226,-90.957382202148,-47.834819793701,180.83178710938)
    AddCameraShot(-0.4188149869442,-0.024035999551415,-0.9062619805336,0.052011001855135,-162.06648254395,-47.23482131958,80.504837036133)
    AddCameraShot(0.98835700750351,0.062969997525215,0.13822799921036,-0.0088069997727871,-173.7740020752,-55.334800720215,142.56781005859)
    AddCameraShot(-0.10055399686098,0.0081599997356534,-0.99163901805878,-0.080476000905037,-246.95443725586,-31.334861755371,153.43881225586)
    AddCameraShot(0.71716398000717,-0.018075000494719,0.69644898176193,0.017552999779582,-216.82719421387,-31.334861755371,186.86364746094)
    AddCameraShot(0.84485000371933,-0.049701999872923,0.53176999092102,0.031284000724554,-247.18145751953,-45.734825134277,29.732486724854)
    AddCameraShot(0.45488101243973,0.028302000835538,-0.88838398456573,0.055273000150919,-291.63665771484,-48.734817504883,21.009202957153)
    AddCameraShot(0.81832200288773,-0.026149999350309,-0.57387399673462,-0.0183390006423,-193.43464660645,-58.634792327881,-12.443043708801)
    AddCameraShot(0.4711090028286,0.0046910000964999,-0.88201802968979,0.0087829995900393,-192.2516784668,-61.334785461426,-32.647247314453)
end

