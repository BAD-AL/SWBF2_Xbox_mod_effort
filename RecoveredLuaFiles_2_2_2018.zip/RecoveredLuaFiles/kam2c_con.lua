--kam2c_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
local local_2 = 1
local local_3 = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "CP10" })
    cp2 = CommandPost:New({ name = "CP11" })
    cp3 = CommandPost:New({ name = "CP12" })
    cp4 = CommandPost:New({ name = "CP13" })
    cp5 = CommandPost:New({ name = "CP2" })
    cp6 = CommandPost:New({ name = "CP4" })
    cp7 = CommandPost:New({ name = "CP5" })
    conquest = ObjectiveConquest:New({ teamATT = local_2, teamDEF = local_3, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)
    conquest:AddCommandPost(cp7)
    conquest:Start()
    EnableSPHeroRules()
end
local local_0 = 2
local local_1 = 1

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\kam.lvl;kam1cw")
    SetMinFlyHeight(60)
    SetAllowBlindJetJumps(0)
    SetMaxFlyHeight(102)
    SetMaxPlayerFlyHeight(102)
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_jettrooper","rep_inf_ep3_officer")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_droideka","CIS_inf_officer")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_chaingun_roof","tur_weap_built_gunturret")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_commando","cis_inf_commando")
    ReadDataFile("SIDE\\all.lvl","all_hero_luke_jedi")
    ReadDataFile("SIDE\\heroes.lvl","rep_hero_quigon","cis_hero_durge")
    SetupTeams({ 
        rep =         { team = local_0, units = 32, reinforcements = 150, 
          soldier =           { "rep_inf_ep3_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep3_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 1, 4 }, 
          sniper =           { "rep_inf_ep3_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep3_officer", 1, 4 }, 
          special =           { "rep_inf_ep3_jettrooper", 1, 4 }
         }, 
        cis =         { team = local_1, units = 32, reinforcements = 150, 
          soldier =           { "CIS_inf_rifleman", 9, 25 }, 
          assault =           { "CIS_inf_rocketeer", 1, 4 }, 
          engineer =           { "CIS_inf_engineer", 1, 4 }, 
          sniper =           { "CIS_inf_sniper", 1, 4 }, 
          officer =           { "CIS_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    AddUnitClass(local_0,"rep_inf_commando",1,2)
    AddUnitClass(local_1,"cis_inf_commando",1,2)
    SetHeroClass(local_0,"rep_hero_quigon")
    SetHeroClass(local_1,"cis_hero_durge")
    ClearWalkers()
    AddWalkerType(0,6)
    SetMemoryPoolSize("Aimer",39)
    SetMemoryPoolSize("AmmoCounter",215)
    SetMemoryPoolSize("BaseHint",210)
    SetMemoryPoolSize("EnergyBar",215)
    SetMemoryPoolSize("EntityCloth",18)
    SetMemoryPoolSize("EntityLight",70)
    SetMemoryPoolSize("EntitySoundStream",3)
    SetMemoryPoolSize("EntitySoundStatic",84)
    SetMemoryPoolSize("MountedTurret",22)
    SetMemoryPoolSize("Navigator",50)
    SetMemoryPoolSize("Obstacle",800)
    SetMemoryPoolSize("PathFollower",50)
    SetMemoryPoolSize("PathNode",256)
    SetMemoryPoolSize("SoundSpaceRegion",36)
    SetMemoryPoolSize("TentacleSimulator",0)
    SetMemoryPoolSize("TreeGridStack",338)
    SetMemoryPoolSize("UnitAgent",50)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("UnitController",50)
    SetMemoryPoolSize("Weapon",215)
    SetSpawnDelay(10,0.25)
    ReadDataFile("kam\\kam2.lvl","kamino1_Conquest")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\kam.lvl","kam1")
    OpenAudioStream("sound\\kam.lvl","kam1")
    SetBleedingVoiceOver(local_0,local_0,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(local_0,local_1,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_0,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_1,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(local_0,local_0,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_0,local_1,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_0,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_1,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(2,"repleaving")
    SetOutOfBoundsVoiceOver(1,"cisleaving")
    SetAmbientMusic(local_0,1,"rep_kam_amb_start",0,1)
    SetAmbientMusic(local_0,0.80000001192093,"rep_kam_amb_middle",1,1)
    SetAmbientMusic(local_0,0.20000000298023,"rep_kam_amb_end",2,1)
    SetAmbientMusic(local_1,1,"cis_kam_amb_start",0,1)
    SetAmbientMusic(local_1,0.80000001192093,"cis_kam_amb_middle",1,1)
    SetAmbientMusic(local_1,0.20000000298023,"cis_kam_amb_end",2,1)
    SetVictoryMusic(local_0,"rep_kam_amb_victory")
    SetDefeatMusic(local_0,"rep_kam_amb_defeat")
    SetVictoryMusic(local_1,"cis_kam_amb_victory")
    SetDefeatMusic(local_1,"cis_kam_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(local_2)
    AddDeathRegion("deathregion")
    AddCameraShot(0.19047799706459,-0.010944999754429,-0.98001402616501,-0.056311998516321,-26.091287612915,55.96501159668,159.45809936523)
    AddCameraShot(-0.37657099962234,-0.019636999815702,-0.92492300271988,0.04823200032115,176.04246520996,53.957565307617,244.26113891602)
    AddCameraShot(0.63925397396088,-0.073532998561859,0.76045697927475,0.087475001811981,78.395347595215,72.538581848145,344.08660888672)
end

