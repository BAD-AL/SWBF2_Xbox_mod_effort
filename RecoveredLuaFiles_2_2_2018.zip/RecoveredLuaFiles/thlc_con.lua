--thlc_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "cp1" })
    cp2 = CommandPost:New({ name = "cp2" })
    cp3 = CommandPost:New({ name = "cp3" })
    cp4 = CommandPost:New({ name = "cp4" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(60)
    SetMaxPlayerFlyHeight(60)
    SetGroundFlyerMap(1)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\geo.lvl;geo1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep2_rocketeer","rep_inf_ep2_rifleman","rep_inf_ep2_engineer","rep_inf_ep2_sniper","rep_inf_ep2_jettrooper","rep_hero_anakin","rep_hover_fightertank","rep_walk_atte")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka","cis_tread_snailtank","cis_walk_spider")
    ReadDataFile("SIDE\\vehicles.lvl","cis_hover_mtt","rep_walk_atxt")
    ReadDataFile("SIDE\\heroes.lvl","cis_hero_vosa","rep_hero_ferroda")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_ep2_officer","rep_inf_commando","cis_inf_commando")
    SetupTeams({ 
        rep =         { team = REP, units = 20, reinforcements = 150, 
          soldier =           { "rep_inf_ep2_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep2_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep2_engineer", 1, 4 }, 
          sniper =           { "rep_inf_ep2_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep2_officer", 1, 4 }, 
          special =           { "rep_inf_ep2_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 20, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_engineer", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          officer =           { "cis_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    AddUnitClass(REP,"rep_inf_commando",1,2)
    AddUnitClass(CIS,"cis_inf_commando",1,2)
    SetHeroClass(CIS,"cis_hero_vosa")
    SetHeroClass(REP,"rep_hero_ferroda")
    ClearWalkers()
    AddWalkerType(0,4)
    AddWalkerType(1,4)
    AddWalkerType(2,4)
    AddWalkerType(3,2)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("CommandWalker",2)
    SetMemoryPoolSize("CommandHover",1)
    SetMemoryPoolSize("AmmoCounter",1024)
    SetMemoryPoolSize("BaseHint",1024)
    SetMemoryPoolSize("EnergyBar",1024)
    SetMemoryPoolSize("EntityCloth",32)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityHover",32)
    SetMemoryPoolSize("EntityLight",200)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",32)
    SetMemoryPoolSize("MountedTurret",32)
    SetMemoryPoolSize("Navigator",128)
    SetMemoryPoolSize("Obstacle",1024)
    SetMemoryPoolSize("PathNode",1024)
    SetMemoryPoolSize("SoundSpaceRegion",64)
    SetMemoryPoolSize("TreeGridStack",1024)
    SetMemoryPoolSize("UnitAgent",128)
    SetMemoryPoolSize("UnitController",128)
    SetMemoryPoolSize("Weapon",1024)
    SetMemoryPoolSize("SoldierAnimation",600)
    SetSpawnDelay(10,0.25)
    ReadDataFile("THL\\THL.lvl","THL_conquest")
    SetDenseEnvironment("false")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\geo.lvl","geo1")
    OpenAudioStream("sound\\geo.lvl","geo1")
    OpenAudioStream("sound\\geo.lvl","geo1_emt")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetAmbientMusic(REP,1,"rep_geo_amb_start",0,1)
    SetAmbientMusic(REP,0.80000001192093,"rep_geo_amb_middle",1,1)
    SetAmbientMusic(REP,0.20000000298023,"rep_geo_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_geo_amb_start",0,1)
    SetAmbientMusic(CIS,0.80000001192093,"cis_geo_amb_middle",1,1)
    SetAmbientMusic(CIS,0.20000000298023,"cis_geo_amb_end",2,1)
    SetVictoryMusic(REP,"rep_geo_amb_victory")
    SetDefeatMusic(REP,"rep_geo_amb_defeat")
    SetVictoryMusic(CIS,"cis_geo_amb_victory")
    SetDefeatMusic(CIS,"cis_geo_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.31685900688171,0.048675999045372,-0.93624001741409,0.14382499456406,-5.093300819397,-0.4767589867115,225.4052734375)
    AddCameraShot(0.95786499977112,0.015587000176311,0.28675800561905,-0.0046660001389682,44.362850189209,31.322568893433,69.101692199707)
    AddCameraShot(0.26821199059486,-0.042072001844645,-0.95081502199173,-0.14914399385452,-167.78086853027,63.66482925415,-54.951042175293)
    AddCameraShot(0.93150001764297,0.13357900083065,-0.33489999175072,0.048025000840425,-230.71159362793,0.84246402978897,341.54949951172)
end

