-- Decompiled with SWBF2CodeHelper
-- cx1c_ctf.lua
Conquest = ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = REP
DEF = CIS

function ScriptPostLoad()
    SetProperty("cp1", "CaptureRegion", "")
    SetProperty("cp2", "CaptureRegion", "")
    SetProperty("cp3", "CaptureRegion", "")
    SetProperty("cp4", "CaptureRegion", "")

    SoundEvent_SetupTeams(REP, "rep", CIS, "cis")
    SetProperty("flag1", "GeometryName", "com_icon_republic_flag")
    SetProperty("flag1", "CarriedGeometryName", "com_icon_republic_flag_carried")
    SetProperty("flag2", "GeometryName", "com_icon_cis_flag")
    SetProperty("flag2", "CarriedGeometryName", "com_icon_cis_flag_carried")
    SetClassProperty("com_item_flag", "DroppedColorize", 1)
    ctf =
        ObjectiveCTF:New(
        {
            teamATT = REP,
            teamDEF = CIS,
            captureLimit = 5,
            textATT = "game.modes.ctf",
            textDEF = "game.modes.ctf2",
            hideCPs = true,
            multiplayerRules = true
        }
    )
    ctf:AddFlag(
        {
            name = "flag1",
            homeRegion = "team1_capture",
            captureRegion = "team2_capture",
            capRegionMarker = "hud_objective_icon_circle",
            capRegionMarkerScale = 3,
            icon = "",
            mapIcon = "flag_icon",
            mapIconScale = 3
        }
    )
    ctf:AddFlag(
        {
            name = "flag2",
            homeRegion = "team2_capture",
            captureRegion = "team1_capture",
            capRegionMarker = "hud_objective_icon_circle",
            capRegionMarkerScale = 3,
            icon = "",
            mapIcon = "flag_icon",
            mapIconScale = 3
        }
    )
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(30)
    SetMaxPlayerFlyHeight(30)
    SetMemoryPoolSize("ClothData", 20)
    SetMemoryPoolSize("Combo", 50)
    SetMemoryPoolSize("Combo::State", 650)
    SetMemoryPoolSize("Combo::Transition", 650)
    SetMemoryPoolSize("Combo::Condition", 650)
    SetMemoryPoolSize("Combo::Attack", 550)
    SetMemoryPoolSize("Combo::DamageSample", 6000)
    SetMemoryPoolSize("Combo::Deflect", 100)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\pol.lvl;pol1cw")
    ReadDataFile(
        "SIDE\\rep.lvl",
        "rep_inf_ep3_rifleman",
        "rep_inf_ep3_rocketeer",
        "rep_inf_ep3_engineer",
        "rep_inf_ep3_sniper",
        "rep_inf_ep3_officer",
        "rep_inf_ep3_jettrooper",
        "rep_hover_fightertank",
        "rep_hero_macewindu"
    )
    ReadDataFile(
        "SIDE\\cis.lvl",
        "cis_inf_rifleman",
        "cis_inf_rocketeer",
        "cis_inf_engineer",
        "cis_inf_sniper",
        "cis_inf_officer",
        "cis_inf_droideka",
        "cis_hero_darthmaul"
    )
    ReadDataFile("SIDE\\imp.lvl", "imp_hero_emperor")
    ReadDataFile("SIDE\\tur.lvl", "tur_bldg_laser", "tur_bldg_tower")
    ReadDataFile("SIDE\\infantry.lvl", "rep_inf_commando", "cis_inf_commando")
    SetupTeams(
        {
            rep = {
                team = REP,
                units = 14,
                reinforcements = 150,
                soldier = {"rep_inf_ep3_rifleman", 9, 25},
                assault = {"rep_inf_ep3_rocketeer", 1, 4},
                engineer = {"rep_inf_ep3_engineer", 1, 4},
                sniper = {"rep_inf_ep3_sniper", 1, 4},
                officer = {"rep_inf_ep3_officer", 1, 4},
                special = {"rep_inf_ep3_jettrooper", 1, 4}
            },
            cis = {
                team = CIS,
                units = 14,
                reinforcements = 150,
                soldier = {"cis_inf_rifleman", 9, 25},
                assault = {"cis_inf_rocketeer", 1, 4},
                engineer = {"cis_inf_engineer", 1, 4},
                sniper = {"cis_inf_sniper", 1, 4},
                officer = {"cis_inf_officer", 1, 4},
                special = {"cis_inf_droideka", 1, 4}
            }
        }
    )
    AddUnitClass(REP, "rep_inf_commando", 1, 2)
    AddUnitClass(CIS, "cis_inf_commando", 1, 2)
    SetHeroClass(CIS, "imp_hero_emperor")
    SetHeroClass(REP, "rep_hero_macewindu")
    AddWalkerType(0, 4)
    AddWalkerType(1, 0)
    AddWalkerType(2, 0)
    AddWalkerType(3, 0)
    SetMemoryPoolSize("Aimer", 75)
    SetMemoryPoolSize("AmmoCounter", 1024)
    SetMemoryPoolSize("BaseHint", 1024)
    SetMemoryPoolSize("EnergyBar", 1024)
    SetMemoryPoolSize("EntityCloth", 32)
    SetMemoryPoolSize("EntityFlyer", 32)
    SetMemoryPoolSize("EntityHover", 32)
    SetMemoryPoolSize("EntityLight", 200)
    SetMemoryPoolSize("EntitySoundStream", 4)
    SetMemoryPoolSize("EntitySoundStatic", 32)
    SetMemoryPoolSize("MountedTurret", 32)
    SetMemoryPoolSize("Navigator", 128)
    SetMemoryPoolSize("Obstacle", 1024)
    SetMemoryPoolSize("PathNode", 1024)
    SetMemoryPoolSize("SoundSpaceRegion", 64)
    SetMemoryPoolSize("TreeGridStack", 1024)
    SetMemoryPoolSize("UnitAgent", 128)
    SetMemoryPoolSize("UnitController", 128)
    SetMemoryPoolSize("Weapon", 1024)
    SetMemoryPoolSize("FlagItem", 2)
    SetSpawnDelay(10, 0.25)
    ReadDataFile("CX1\\CX1.lvl", "CX1_1flag")
    SetDenseEnvironment("false")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    voiceSlow = OpenAudioStream("sound\\global.lvl", "rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "cis_unit_vo_slow", voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl", "rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl", "cis_unit_vo_quick", voiceQuick)
    OpenAudioStream("sound\\global.lvl", "cw_music")
    OpenAudioStream("sound\\yav.lvl", "yav1")
    OpenAudioStream("sound\\yav.lvl", "yav1")
    OpenAudioStream("sound\\yav.lvl", "yav1_emt")
    SetBleedingVoiceOver(REP, REP, "rep_off_com_report_us_overwhelmed", 1)
    SetBleedingVoiceOver(REP, CIS, "rep_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(CIS, REP, "cis_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(CIS, CIS, "cis_off_com_report_us_overwhelmed", 1)
    SetOutOfBoundsVoiceOver(2, "cisleaving")
    SetOutOfBoundsVoiceOver(1, "repleaving")
    SetAmbientMusic(REP, 1, "rep_yav_amb_start", 0, 1)
    SetAmbientMusic(REP, 0.80000001192093, "rep_yav_amb_middle", 1, 1)
    SetAmbientMusic(REP, 0.20000000298023, "rep_yav_amb_end", 2, 1)
    SetAmbientMusic(CIS, 1, "cis_yav_amb_start", 0, 1)
    SetAmbientMusic(CIS, 0.80000001192093, "cis_yav_amb_middle", 1, 1)
    SetAmbientMusic(CIS, 0.20000000298023, "cis_yav_amb_end", 2, 1)
    SetVictoryMusic(REP, "rep_yav_amb_victory")
    SetDefeatMusic(REP, "rep_yav_amb_defeat")
    SetVictoryMusic(CIS, "cis_yav_amb_victory")
    SetDefeatMusic(CIS, "cis_yav_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    AddCameraShot(
        0.014526000246406,
        -6.5000000176951e-005,
        -0.99988502264023,
        -0.0044399998150766,
        -0.044491000473499,
        2.466372013092,
        -23.57772064209
    )
    AddCameraShot(
        0.9537690281868,
        -0.022833000868559,
        0.29958701133728,
        0.0071720001287758,
        8.9305582046509,
        3.5308649539948,
        21.776279449463
    )
    AddCameraShot(
        0.9578469991684,
        -0.088636003434658,
        0.27210199832916,
        0.02517900057137,
        5.7797741889954,
        1.920480966568,
        -29.521324157715
    )
    AddCameraShot(
        0.53610801696777,
        0.0079910000786185,
        -0.84401798248291,
        0.012581000104547,
        -95.457893371582,
        1.920480966568,
        -71.743865966797
    )
end
