--bhwk_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
IMP = 1
ALL = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    SoundEvent_SetupTeams(IMP,"imp",ALL,"all")
    SetProperty("ATT_Flag","GeometryName","com_icon_imperial_flag")
    SetProperty("ATT_Flag","CarriedGeometryName","com_icon_imperial_flag_carried")
    SetProperty("DEF_Flag","GeometryName","com_icon_alliance_flag")
    SetProperty("DEF_Flag","CarriedGeometryName","com_icon_alliance_flag_carried")
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 5, textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", multiplayerRules = true, hideCPs = true })
    ctf:AddFlag({ name = "ATT_Flag", homeRegion = "ATT_home", captureRegion = "DEF_home", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "DEF_Flag", homeRegion = "DEF_home", captureRegion = "ATT_home", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(20)
    SetMaxPlayerFlyHeight(20)
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\dea.lvl;dea1gcw")
    ReadDataFile("SIDE\\rep.lvl","rep_hero_obiwan","rep_hero_kiyadimundi")
    ReadDataFile("SIDE\\kotor.lvl","kor_hero_mandalore","kor_hero_nihilus","rvs_inf_rbasic","rvs_inf_sbasic","rvs_inf_rheavy","rvs_inf_sheavy","rvs_inf_rsupport","rvs_inf_ssupport","rvs_inf_rstealth","rvs_inf_sstealth","rvs_inf_sadept","rvs_inf_radept","rvs_inf_rofficer","rvs_inf_sofficer","rvs_inf_rdroid","rvs_inf_sdroid")
    SetupTeams({ 
        rep =         { team = ALL, units = 20, reinforcements = 150, 
          soldier =           { "rvs_inf_rbasic", 7, 24 }, 
          assault =           { "rvs_inf_rheavy", 2, 8 }, 
          engineer =           { "rvs_inf_rdroid", 2, 8 }, 
          sniper =           { "rvs_inf_rsupport", 2, 8 }, 
          officer =           { "rvs_inf_rofficer", 2, 8 }, 
          special =           { "rvs_inf_rstealth", 1, 4 }
         }, 
        imp =         { team = IMP, units = 20, reinforcements = 150, 
          soldier =           { "rvs_inf_sbasic", 7, 24 }, 
          assault =           { "rvs_inf_sheavy", 2, 8 }, 
          engineer =           { "rvs_inf_sdroid", 2, 8 }, 
          sniper =           { "rvs_inf_ssupport", 2, 8 }, 
          officer =           { "rvs_inf_sofficer", 2, 8 }, 
          special =           { "rvs_inf_sstealth", 1, 4 }
         }
       })
    AddUnitClass(ALL,"rvs_inf_radept",1,2)
    AddUnitClass(IMP,"rvs_inf_sadept",1,2)
    SetHeroClass(ALL,"kor_hero_mandalore")
    SetHeroClass(IMP,"kor_hero_nihilus")
    ClearWalkers()
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    SetMemoryPoolSize("MountedTurret",10)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("Obstacle",514)
    SetMemoryPoolSize("SoundSpaceRegion",38)
    SetSpawnDelay(10,0.25)
    ReadDataFile("BHW\\BHW.lvl","BHW_ctf")
    SetDenseEnvironment("true")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\dea.lvl","dea1")
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"all_dea_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_dea_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_dea_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_dea_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_dea_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_dea_amb_end",2,1)
    SetVictoryMusic(ALL,"all_dea_amb_victory")
    SetDefeatMusic(ALL,"all_dea_amb_defeat")
    SetVictoryMusic(IMP,"imp_dea_amb_victory")
    SetDefeatMusic(IMP,"imp_dea_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.87934798002243,-0.14204600453377,0.4486840069294,0.072477996349335,-38.413761138916,30.986400604248,195.87962341309)
    AddCameraShot(0.75514298677444,0.032623998820782,0.65413701534271,-0.028260000050068,-80.924102783203,-32.534858703613,59.805065155029)
    AddCameraShot(0.59651398658752,-0.068856000900269,-0.79437202215195,-0.091695003211498,-139.20362854004,-28.934867858887,56.316780090332)
    AddCameraShot(0.073601998388767,-0.011602000333369,-0.98505997657776,-0.15527200698853,-118.28823852539,-28.934867858887,125.93835449219)
    AddCameraShot(0.90268701314926,0.0012740000383928,0.43029499053955,-0.00060700002359226,-90.957382202148,-47.834819793701,180.83178710938)
    AddCameraShot(-0.4188149869442,-0.024035999551415,-0.9062619805336,0.052011001855135,-162.06648254395,-47.23482131958,80.504837036133)
    AddCameraShot(0.98835700750351,0.062969997525215,0.13822799921036,-0.0088069997727871,-173.7740020752,-55.334800720215,142.56781005859)
    AddCameraShot(-0.10055399686098,0.0081599997356534,-0.99163901805878,-0.080476000905037,-246.95443725586,-31.334861755371,153.43881225586)
    AddCameraShot(0.71716398000717,-0.018075000494719,0.69644898176193,0.017552999779582,-216.82719421387,-31.334861755371,186.86364746094)
    AddCameraShot(0.84485000371933,-0.049701999872923,0.53176999092102,0.031284000724554,-247.18145751953,-45.734825134277,29.732486724854)
    AddCameraShot(0.45488101243973,0.028302000835538,-0.88838398456573,0.055273000150919,-291.63665771484,-48.734817504883,21.009202957153)
    AddCameraShot(0.81832200288773,-0.026149999350309,-0.57387399673462,-0.0183390006423,-193.43464660645,-58.634792327881,-12.443043708801)
    AddCameraShot(0.4711090028286,0.0046910000964999,-0.88201802968979,0.0087829995900393,-192.2516784668,-61.334785461426,-32.647247314453)
end

