--myg1g_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
ALL = 1
IMP = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    SoundEvent_SetupTeams(IMP,"imp",ALL,"all")
    DisableBarriers("corebar1")
    DisableBarriers("corebar2")
    DisableBarriers("corebar3")
    DisableBarriers("shield_01")
    DisableBarriers("shield_02")
    DisableBarriers("shield_03")
    DisableBarriers("corebar4")
    DisableBarriers("dropship")
    DisableBarriers("coresh1")
    OnObjectRespawnName(Revived,"generator_01")
    OnObjectKillName(ShieldDied,"force_shield_01")
    OnObjectKillName(ShieldDied,"generator_01")
    OnObjectRespawnName(Revived,"generator_02")
    OnObjectKillName(ShieldDied,"force_shield_02")
    OnObjectKillName(ShieldDied,"generator_02")
    OnObjectRespawnName(Revived,"generator_03")
    OnObjectKillName(ShieldDied,"force_shield_03")
    OnObjectKillName(ShieldDied,"generator_03")
    SetProperty("flag1","GeometryName","com_icon_alliance_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_alliance_flag_carried")
    SetProperty("flag2","GeometryName","com_icon_imperial_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_imperial_flag_carried")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 5, textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag1_home", captureRegion = "flag2_home", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag2_home", captureRegion = "flag1_home", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function Init(InitParam0)
    shieldName = "force_shield_" .. InitParam0
    genName = "generator_" .. InitParam0
    upAnim = "shield_up_" .. InitParam0
    downAnim = "shield_down_" .. InitParam0
    PlayShieldUp(shieldName,genName,upAnim,downAnim)
    BlockPlanningGraphArcs("shield_" .. InitParam0)
    EnableBarriers("shield_" .. InitParam0)
end

function ShieldDied(ShieldDiedParam0)
    fullName = GetEntityName(ShieldDiedParam0)
    numberStr = string.sub(fullName,-2,-1)
    shieldName = "force_shield_" .. numberStr
    genName = "generator_" .. numberStr
    upAnim = "shield_up_" .. numberStr
    downAnim = "shield_down_" .. numberStr
    PlayShieldDown(shieldName,genName,upAnim,downAnim)
    UnblockPlanningGraphArcs("shield_" .. numberStr)
    DisableBarriers("shield_" .. numberStr)
end

function Revived(RevivedParam0)
    fullName = GetEntityName(RevivedParam0)
    numberStr = string.sub(fullName,-2,-1)
    shieldName = "force_shield_" .. numberStr
    genName = "generator_" .. numberStr
    upAnim = "shield_up_" .. numberStr
    downAnim = "shield_down_" .. numberStr
    PlayShieldUp(shieldName,genName,upAnim,downAnim)
    BlockPlanningGraphArcs("shield_" .. numberStr)
    EnableBarriers("shield_" .. numberStr)
end

function PlayShieldDown(PlayShieldDownParam0, PlayShieldDownParam1, PlayShieldDownParam2, PlayShieldDownParam3)
    RespawnObject(PlayShieldDownParam0)
    KillObject(PlayShieldDownParam1)
    PauseAnimation(PlayShieldDownParam2)
    RewindAnimation(PlayShieldDownParam3)
    PlayAnimation(PlayShieldDownParam3)
end

function PlayShieldUp(PlayShieldUpParam0, PlayShieldUpParam1, PlayShieldUpParam2, PlayShieldUpParam3)
    RespawnObject(PlayShieldUpParam0)
    RespawnObject(PlayShieldUpParam1)
    PauseAnimation(PlayShieldUpParam3)
    RewindAnimation(PlayShieldUpParam2)
    PlayAnimation(PlayShieldUpParam2)
end

function ScriptInit()
    StealArtistHeap(2048 * 1024)
    SetPS2ModelMemory(4100000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\myg.lvl;myg1gcw")
    SetMaxFlyHeight(20)
    SetMaxPlayerFlyHeight(20)
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_inf_officer","all_hero_luke_jedi","all_inf_wookiee","all_hover_combatspeeder")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_officer","imp_inf_sniper","imp_inf_engineer","imp_inf_dark_trooper","imp_hero_bobafett","imp_hover_fightertank","imp_hover_speederbike","imp_walk_atst")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_recoilless_lg")
    ReadDataFile("SIDE\\infantry.lvl","all_inf_specialops","imp_inf_commando")
    SetupTeams({ 
        all =         { team = ALL, units = 32, reinforcements = -1, 
          soldier =           { "all_inf_rifleman", 9, 25 }, 
          assault =           { "all_inf_rocketeer", 1, 4 }, 
          engineer =           { "all_inf_engineer", 1, 4 }, 
          sniper =           { "all_inf_sniper", 1, 4 }, 
          officer =           { "all_inf_officer", 1, 4 }, 
          special =           { "all_inf_wookiee", 1, 4 }
         }, 
        imp =         { team = IMP, units = 32, reinforcements = -1, 
          soldier =           { "imp_inf_rifleman", 9, 25 }, 
          assault =           { "imp_inf_rocketeer", 1, 4 }, 
          engineer =           { "imp_inf_engineer", 1, 4 }, 
          sniper =           { "imp_inf_sniper", 1, 4 }, 
          officer =           { "imp_inf_officer", 1, 4 }, 
          special =           { "imp_inf_dark_trooper", 1, 4 }
         }
       })
    AddUnitClass(ALL,"all_inf_specialops",1,2)
    AddUnitClass(IMP,"imp_inf_commando",1,2)
    SetHeroClass(IMP,"imp_hero_bobafett")
    SetHeroClass(ALL,"all_hero_luke_jedi")
    ClearWalkers()
    AddWalkerType(1,0)
    SetMemoryPoolSize("Aimer",80)
    SetMemoryPoolSize("EntityCloth",31)
    SetMemoryPoolSize("EntityHover",8)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntityLight",36)
    SetMemoryPoolSize("EntitySoundStream",1)
    SetMemoryPoolSize("EntitySoundStatic",76)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("MountedTurret",14)
    SetMemoryPoolSize("Obstacle",520)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("PathNode",512)
    SetMemoryPoolSize("TreeGridStack",300)
    SetMemoryPoolSize("Weapon",260)
    SetSpawnDelay(10,0.25)
    ReadDataFile("myg\\myg1.lvl","myg1_ctf")
    SetDenseEnvironment("false")
    AddDeathRegion("deathregion")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\myg.lvl","myg1")
    OpenAudioStream("sound\\myg.lvl","myg1")
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"all_myg_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_myg_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_myg_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_myg_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_myg_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_myg_amb_end",2,1)
    SetVictoryMusic(ALL,"all_myg_amb_victory")
    SetDefeatMusic(ALL,"all_myg_amb_defeat")
    SetVictoryMusic(IMP,"imp_myg_amb_victory")
    SetDefeatMusic(IMP,"imp_myg_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.0083149997517467,9.9999999747524e-007,-0.99996501207352,7.4000003223773e-005,-64.894348144531,5.541570186615,201.71109008789)
    AddCameraShot(0.63358402252197,-0.048454001545906,-0.76990699768066,-0.058878999203444,-171.25762939453,7.7289237976074,28.249359130859)
    AddCameraShot(-0.0017350000562146,-8.9000001025852e-005,-0.9986919760704,0.051091998815536,-146.09310913086,4.4183058738708,-167.73921203613)
    AddCameraShot(0.98418200016022,-0.04848799854517,0.17019000649452,0.0083849998190999,1.7256109714508,8.8774280548096,88.413887023926)
    AddCameraShot(0.14140699803829,-0.012273999862373,-0.98616802692413,-0.08559799939394,-77.743041992188,8.067328453064,42.336128234863)
    AddCameraShot(0.79701697826385,0.029660999774933,0.60281002521515,-0.022433999925852,-45.726467132568,7.7544350624084,-47.54471206665)
    AddCameraShot(0.99876397848129,0.044817999005318,-0.021459000185132,0.00096299999859184,-71.276565551758,4.4174318313599,221.0545501709)
end

