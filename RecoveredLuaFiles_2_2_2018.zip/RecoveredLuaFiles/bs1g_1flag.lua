--bs1g_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveOneFlagCTF")
local local_0 = 2
local local_1 = 1

function ScriptPostLoad()
    SoundEvent_SetupTeams(local_0,"all",local_1,"imp")
    ctf = ObjectiveOneFlagCTF:New({ teamATT = 1, teamDEF = 2, textATT = "game.modes.1flag", textDEF = "game.modes.1flag2", captureLimit = 8, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "homeregion", captureRegionATT = "team1_capture", captureRegionDEF = "team2_capture", capRegionMarkerATT = "hud_objective_icon_circle", capRegionMarkerDEF = "hud_objective_icon_circle", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3, multiplayerRules = true })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(225)
    SetMaxPlayerFlyHeight(225)
    SetGroundFlyerMap(1)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\BS1.lvl;BS1gcw")
    ReadDataFile("sound\\cor.lvl;cor1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_pilot","all_inf_officer","all_inf_wookiee")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_pilot","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_bobafett")
    ReadDataFile("SIDE\\swbf1.lvl","all_fly_xwing","all_fly_ywing","imp_fly_tiefighter","imp_fly_tiebomber")
    ReadDataFile("SIDE\\infantry.lvl","all_inf_specialops","imp_inf_commando")
    ReadDataFile("SIDE\\heroes.lvl","all_hero_lando")
    SetupTeams({ 
        all =         { team = local_0, units = 30, reinforcements = 150, 
          soldier =           { "all_inf_rifleman", 9, 25 }, 
          assault =           { "all_inf_rocketeer", 1, 4 }, 
          pilot =           { "all_inf_pilot", 1, 4 }, 
          sniper =           { "all_inf_sniper", 1, 4 }, 
          officer =           { "all_inf_officer", 1, 4 }, 
          special =           { "all_inf_wookiee", 1, 4 }
         }, 
        imp =         { team = local_1, units = 30, reinforcements = 150, 
          soldier =           { "imp_inf_rifleman", 9, 25 }, 
          assault =           { "imp_inf_rocketeer", 1, 4 }, 
          pilot =           { "imp_inf_pilot", 1, 4 }, 
          sniper =           { "imp_inf_sniper", 1, 4 }, 
          officer =           { "imp_inf_officer", 1, 4 }, 
          special =           { "imp_inf_dark_trooper", 1, 4 }
         }
       })
    AddUnitClass(local_0,"all_inf_specialops",1,4)
    AddUnitClass(local_1,"imp_inf_commando",1,4)
    SetHeroClass(local_0,"all_hero_lando")
    SetHeroClass(local_1,"imp_hero_bobafett")
    AddWalkerType(0,8)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("AmmoCounter",512)
    SetMemoryPoolSize("BaseHint",1000)
    SetMemoryPoolSize("EnergyBar",512)
    SetMemoryPoolSize("EntityFlyer",50)
    SetMemoryPoolSize("EntityLight",50)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",20)
    SetMemoryPoolSize("MountedTurret",40)
    SetMemoryPoolSize("Obstacle",760)
    SetMemoryPoolSize("PathNode",512)
    SetMemoryPoolSize("SoundSpaceRegion",46)
    SetMemoryPoolSize("Weapon",512)
    SetMemoryPoolSize("SoldierAnimation",650)
    SetMemoryPoolSize("Aimer",250)
    SetMemoryPoolSize("ConnectivityGraphFollower",55)
    SetMemoryPoolSize("EntityCloth",41)
    SetMemoryPoolSize("EntityDefenseGridTurret",0)
    SetMemoryPoolSize("EntityPortableTurret",20)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",120)
    SetMemoryPoolSize("Navigator",80)
    SetMemoryPoolSize("Ordnance",80)
    SetMemoryPoolSize("ParticleEmitter",512)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("PathFollower",80)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("TreeGridStack",340)
    SetMemoryPoolSize("UnitAgent",100)
    SetMemoryPoolSize("UnitController",110)
    SetMemoryPoolSize("Music",60)
    SetMemoryPoolSize("FlagItem",1)
    SetSpawnDelay(10,0.25)
    ReadDataFile("BS1\\BS1.lvl","BS1_1flag")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\cor.lvl","cor1")
    OpenAudioStream("sound\\cor.lvl","cor1")
    OpenAudioStream("sound\\BS1.lvl")
    OpenAudioStream("sound\\BS1.lvl")
    SetBleedingVoiceOver(local_0,local_0,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(local_0,local_1,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_0,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_1,"imp_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(local_0,1,"all_cor_amb_start",0,1)
    SetAmbientMusic(local_0,0.80000001192093,"all_cor_amb_middle",1,1)
    SetAmbientMusic(local_0,0.20000000298023,"all_cor_amb_end",2,1)
    SetAmbientMusic(local_1,1,"imp_cor_amb_start",0,1)
    SetAmbientMusic(local_1,0.80000001192093,"imp_cor_amb_middle",1,1)
    SetAmbientMusic(local_1,0.20000000298023,"imp_cor_amb_end",2,1)
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.79310500621796,-0.062986001372337,-0.60391801595688,-0.047961998730898,-170.58361816406,118.98154449463,-150.44325256348)
    AddCameraShot(0.18971599638462,0.00094400002853945,-0.98182600736618,0.0048870001919568,-27.594291687012,100.58374023438,-176.47801208496)
    AddCameraShot(0.49240100383759,0.010386999696493,-0.87011301517487,0.018354000523686,19.590665817261,100.49359893799,-47.846900939941)
end

