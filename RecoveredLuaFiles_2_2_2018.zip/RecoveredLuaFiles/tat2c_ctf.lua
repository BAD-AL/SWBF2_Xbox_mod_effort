--tat2c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
ATT = 1
DEF = 2
CIS = ATT
REP = DEF

function ScriptPostLoad()
    SetProperty("ctf_flag1","GeometryName","com_icon_cis_flag")
    SetProperty("ctf_flag1","CarriedGeometryName","com_icon_cis_flag_carried")
    SetProperty("ctf_flag2","GeometryName","com_icon_republic_flag")
    SetProperty("ctf_flag2","CarriedGeometryName","com_icon_republic_flag_carried")
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 5, textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", multiplayerRules = true, hideCPs = true })
    ctf:AddFlag({ name = "ctf_flag1", homeRegion = "flag1_home", captureRegion = "flag2_home", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "ctf_flag2", homeRegion = "flag2_home", captureRegion = "flag1_home", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    SoundEvent_SetupTeams(1,"cis",2,"rep")
    ctf:Start()
    KillObject("CP1")
    KillObject("CP2")
    KillObject("CP3")
    KillObject("CP4")
    KillObject("CP5")
    KillObject("CP6")
    KillObject("CP7")
    KillObject("CP8")
    AddAIGoal(3,"Deathmatch",1000)
end

function ScriptInit()
    StealArtistHeap(2048 * 1024)
    SetPS2ModelMemory(2097152 + 65536 * 6)
    ReadDataFile("ingame.lvl")
    SetTeamAggressiveness(REP,0.94999998807907)
    SetTeamAggressiveness(CIS,0.94999998807907)
    SetMaxFlyHeight(40)
    SetMaxPlayerFlyHeight(40)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\tat.lvl;tat2cw")
    ReadDataFile("SIDE\\heroes.lvl","rep_hero_obiwan")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rocketeer","rep_inf_ep3_rifleman","rep_inf_ep3_sniper","rep_inf_ep3_engineer","rep_inf_ep3_jettrooper","rep_inf_ep3_officer","rep_hero_obiwan")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_hero_darthmaul","cis_inf_droideka")
    ReadDataFile("SIDE\\des.lvl","tat_inf_jawa")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_tat_barge","tur_bldg_laser")
    SetAttackingTeam(ATT)
    SetupTeams({ 
        rep =         { team = REP, units = 28, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep3_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 1, 4 }, 
          sniper =           { "rep_inf_ep3_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep3_officer", 1, 4 }, 
          special =           { "rep_inf_ep3_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 28, reinforcements = -1, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_engineer", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          officer =           { "cis_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    SetHeroClass(REP,"rep_hero_obiwan")
    SetHeroClass(CIS,"cis_hero_darthmaul")
    SetTeamName(3,"locals")
    AddUnitClass(3,"tat_inf_jawa",7)
    SetUnitCount(3,7)
    SetTeamAsFriend(3,ATT)
    SetTeamAsFriend(3,DEF)
    SetTeamAsFriend(ATT,3)
    SetTeamAsFriend(DEF,3)
    ClearWalkers()
    AddWalkerType(0,3)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",30)
    SetMemoryPoolSize("AmmoCounter",230)
    SetMemoryPoolSize("BaseHint",325)
    SetMemoryPoolSize("EnergyBar",230)
    SetMemoryPoolSize("EntityCloth",20)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntitySoundStream",2)
    SetMemoryPoolSize("EntitySoundStatic",43)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("MountedTurret",20)
    SetMemoryPoolSize("Navigator",50)
    SetMemoryPoolSize("Obstacle",664)
    SetMemoryPoolSize("PathFollower",50)
    SetMemoryPoolSize("PathNode",256)
    SetMemoryPoolSize("TentacleSimulator",0)
    SetMemoryPoolSize("TreeGridStack",325)
    SetMemoryPoolSize("Weapon",230)
    SetSpawnDelay(10,0.25)
    ReadDataFile("TAT\\tat2.lvl","tat2_ctf")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","des_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\tat.lvl","tat2")
    OpenAudioStream("sound\\tat.lvl","tat2")
    SetOutOfBoundsVoiceOver(1,"cisleaving")
    SetOutOfBoundsVoiceOver(2,"repleaving")
    SetAmbientMusic(REP,1,"rep_tat_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_tat_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_tat_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_tat_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_tat_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_tat_amb_end",2,1)
    SetVictoryMusic(REP,"rep_tat_amb_victory")
    SetDefeatMusic(REP,"rep_tat_amb_defeat")
    SetVictoryMusic(CIS,"cis_tat_amb_victory")
    SetDefeatMusic(CIS,"cis_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.97433799505234,-0.22217999398708,0.035172000527382,0.0080199996009469,-82.664649963379,23.668300628662,43.955680847168)
    AddCameraShot(0.39019700884819,-0.089729003608227,-0.89304000139236,-0.2053620070219,23.563562393188,12.914884567261,-101.46556091309)
    AddCameraShot(0.16975900530815,0.0022249999456108,-0.98539799451828,0.012915999628603,126.97280883789,4.0396280288696,-22.020612716675)
    AddCameraShot(0.67745298147202,-0.041535001248121,0.73301601409912,0.044941999018192,97.517807006836,4.0396280288696,36.853477478027)
    AddCameraShot(0.86602902412415,-0.15650600194931,0.46729901432991,0.084449000656605,7.6856398582458,7.1306881904602,-10.895234107971)
end

