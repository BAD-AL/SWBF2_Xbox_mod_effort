--ibng_hero.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveTDM")

function ScriptPostLoad()
    SetProperty("CP1","CaptureRegion","")
    SetProperty("CP1","Team","1")
    SetProperty("CP2","CaptureRegion","")
    SetProperty("CP2","Team","2")
    SetProperty("CP3","CaptureRegion","")
    SetProperty("CP3","Team","1")
    SetProperty("CP4","CaptureRegion","")
    SetProperty("CP4","Team","2")
    KillObject("CP5")
    EnableSPHeroRules()
    TDM = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, multiplayerScoreLimit = 100, textATT = "game.modes.tdm", textDEF = "game.modes.tdm2", multiplayerRules = true, isCelebrityDeathmatch = true })
    TDM:Start()
    AddAIGoal(1,"Deathmatch",100)
    AddAIGoal(2,"Deathmatch",100)
end

function ScriptInit()
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",70)
    SetMemoryPoolSize("Combo::State",850)
    SetMemoryPoolSize("Combo::Transition",850)
    SetMemoryPoolSize("Combo::Condition",850)
    SetMemoryPoolSize("Combo::Attack",750)
    SetMemoryPoolSize("Combo::DamageSample",8000)
    SetMemoryPoolSize("Combo::Deflect",140)
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    ALL = 1
    IMP = 2
    ATT = 1
    DEF = 2
    SetMaxFlyHeight(150)
    SetMaxPlayerFlyHeight(150)
    ReadDataFile("sound\\tat.lvl;tat2gcw")
    ReadDataFile("SIDE\\all.lvl","all_hero_luke_jedi","all_hero_leia","all_hero_chewbacca")
    ReadDataFile("SIDE\\imp.lvl","imp_hero_bobafett")
    ReadDataFile("SIDE\\rep.lvl","rep_hero_macewindu","rep_hero_aalya","rep_hero_kiyadimundi","rep_hero_obiwan")
    ReadDataFile("SIDE\\cis.lvl","cis_hero_jangofett")
    ReadDataFile("SIDE\\heroes.lvl","all_hero_hansolo_tat","rep_hero_anakin","rep_hero_obiwan")
    SetupTeams({ 
        hero =         { team = ALL, units = 12, reinforcements = -1, 
          soldier =           { "all_hero_hansolo_tat", 1, 2 }, 
          assault =           { "all_hero_chewbacca", 1, 2 }, 
          engineer =           { "all_hero_luke_jedi", 1, 2 }, 
          sniper =           { "rep_hero_obiwan", 1, 2 }, 
          officer =           { "all_hero_lando", 1, 2 }, 
          special =           { "rep_hero_macewindu", 1, 2 }
         }
       })
    AddUnitClass(ALL,"all_hero_leia",1,2)
    AddUnitClass(ALL,"rep_hero_aalya",1,2)
    AddUnitClass(ALL,"rep_hero_kiyadimundi",1,2)
    AddUnitClass(ALL,"rep_hero_shaakti",1,2)
    SetupTeams({ 
        villain =         { team = IMP, units = 12, reinforcements = -1, 
          soldier =           { "imp_hero_bobafett", 1, 2 }, 
          assault =           { "cis_hero_durge", 1, 2 }, 
          engineer =           { "imp_hero_sarn", 1, 2 }, 
          sniper =           { "cis_hero_jangofett", 1, 2 }, 
          officer =           { "imp_hero_bossk", 1, 2 }, 
          special =           { "yuz_inf_yuuzhanvong", 1, 2 }
         }
       })
    AddUnitClass(IMP,"rep_hero_anakin",1,2)
    AddUnitClass(IMP,"cis_hero_vosa",1,2)
    AddUnitClass(IMP,"imp_hero_thrawn",1,2)
    AddUnitClass(IMP,"cis_hero_aurrasing",1,2)
    ClearWalkers()
    AddWalkerType(0,0)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",1)
    SetMemoryPoolSize("AmmoCounter",96)
    SetMemoryPoolSize("BaseHint",320)
    SetMemoryPoolSize("ConnectivityGraphFollower",23)
    SetMemoryPoolSize("EnergyBar",96)
    SetMemoryPoolSize("EntityCloth",41)
    SetMemoryPoolSize("EntityDefenseGridTurret",0)
    SetMemoryPoolSize("EntityDroid",0)
    SetMemoryPoolSize("EntityFlyer",5)
    SetMemoryPoolSize("EntityLight",80,80)
    SetMemoryPoolSize("EntityPortableTurret",0)
    SetMemoryPoolSize("EntitySoundStream",2)
    SetMemoryPoolSize("EntitySoundStatic",45)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",120)
    SetMemoryPoolSize("MountedTurret",0)
    SetMemoryPoolSize("Navigator",23)
    SetMemoryPoolSize("Obstacle",667)
    SetMemoryPoolSize("Ordnance",80)
    SetMemoryPoolSize("ParticleEmitter",512)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("PathFollower",23)
    SetMemoryPoolSize("PathNode",128)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("TentacleSimulator",24)
    SetMemoryPoolSize("TreeGridStack",290)
    SetMemoryPoolSize("UnitAgent",23)
    SetMemoryPoolSize("UnitController",23)
    SetMemoryPoolSize("Weapon",96)
    SetSpawnDelay(10,0.25)
    ReadDataFile("dc:IBN\\IBN.lvl","Bounty1_conquest")
    SetDenseEnvironment("false")
    ScriptCB_EnableHeroMusic(0)
    ScriptCB_EnableHeroVO(0)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\tat.lvl","tat2")
    OpenAudioStream("sound\\tat.lvl","tat2")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"Allleaving")
    SetOutOfBoundsVoiceOver(2,"Impleaving")
    SetAmbientMusic(ALL,1,"gen_amb_celebDeathmatch",0,1)
    SetAmbientMusic(IMP,1,"gen_amb_celebDeathmatch",0,1)
    SetVictoryMusic(ALL,"all_tat_amb_victory")
    SetDefeatMusic(ALL,"all_tat_amb_defeat")
    SetVictoryMusic(IMP,"imp_tat_amb_victory")
    SetDefeatMusic(IMP,"imp_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.73300802707672,-0.042259998619556,0.67777997255325,0.039076000452042,-0.302630007267,28.794353485107,75.827964782715)
    AddCameraShot(0.75283199548721,0.032205998897552,0.65682297945023,-0.028098000213504,80.700004577637,52.86413192749,7.2932300567627)
    AddCameraShot(0.73817300796509,-0.18660500645638,0.62851798534393,0.15888500213623,80.287796020508,56.51651763916,7.3138041496277)
    AddCameraShot(0.97721201181412,-0.18520499765873,0.10189999639988,0.019311999902129,68.38257598877,45.097171783447,-38.306804656982)
end

