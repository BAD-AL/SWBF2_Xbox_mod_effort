--rhn1c_bf1.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    EnableSPHeroRules()
    cp1 = CommandPost:New({ name = "cp2" })
    cp2 = CommandPost:New({ name = "CP3" })
    cp3 = CommandPost:New({ name = "CP5" })
    cp4 = CommandPost:New({ name = "CP6" })
    cp5 = CommandPost:New({ name = "CP7" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",30)
    SetMemoryPoolSize("Combo::State",500)
    SetMemoryPoolSize("Combo::Transition",500)
    SetMemoryPoolSize("Combo::Condition",500)
    SetMemoryPoolSize("Combo::Attack",400)
    SetMemoryPoolSize("Combo::DamageSample",4000)
    SetMemoryPoolSize("Combo::Deflect",88)
    ReadDataFile("sound\\hero.lvl;herogcw")
    ReadDataFile("sound\\fel.lvl;fel1cw")
    SetMaxFlyHeight(30)
    SetMaxPlayerFlyHeight(30)
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_laser")
    ReadDataFile("SIDE\\swbf1.lvl","rep_walk_atte","rep_hover_fighttank","rep_inf_ep2_rifleman","rep_inf_ep2_rocketeer","rep_inf_ep2_pilot","rep_inf_ep2_sniper","rep_inf_ep2_jettrooper","cis_inf_droideka_hunt","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_pilot","cis_inf_sniper","cis_hover_aat")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_droideka")
    SetupTeams({ 
        rep =         { team = REP, units = 20, reinforcements = 150, 
          soldier =           { "rep_inf_ep2_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep2_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep2_pilot", 1, 4 }, 
          sniper =           { "rep_inf_ep2_sniper", 1, 4 }, 
          special =           { "rep_inf_ep2_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 20, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_pilot", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          special =           { "cis_inf_droideka_hunt", 1, 4 }
         }
       })
    ClearWalkers()
    SetMemoryPoolSize("EntityWalker",-1)
    AddWalkerType(0,12)
    AddWalkerType(1,2)
    AddWalkerType(2,0)
    AddWalkerType(3,1)
    SetMemoryPoolSize("Commandwalker",1)
    SetMemoryPoolSize("EntityHover",6)
    SetMemoryPoolSize("MountedTurret",48)
    SetMemoryPoolSize("PowerupItem",60)
    SetMemoryPoolSize("EntityMine",40)
    SetMemoryPoolSize("Weapon",280)
    ReadDataFile("RHN\\RHN1b.lvl","rhenvar1_conquest")
    SetSpawnDelay(10,0.25)
    SetDenseEnvironment("false")
    SetAIVehicleNotifyRadius(80)
    SetMaxFlyHeight(30)
    SetMaxPlayerFlyHeight(30)
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\fel.lvl","fel1")
    OpenAudioStream("sound\\fel.lvl","fel1")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_fel_amb_start",0,1)
    SetAmbientMusic(REP,0.80000001192093,"rep_fel_amb_middle",1,1)
    SetAmbientMusic(REP,0.20000000298023,"rep_fel_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_fel_amb_start",0,1)
    SetAmbientMusic(CIS,0.80000001192093,"cis_fel_amb_middle",1,1)
    SetAmbientMusic(CIS,0.20000000298023,"cis_fel_amb_end",2,1)
    SetVictoryMusic(REP,"rep_fel_amb_victory")
    SetDefeatMusic(REP,"rep_fel_amb_defeat")
    SetVictoryMusic(CIS,"cis_fel_amb_victory")
    SetDefeatMusic(CIS,"cis_fel_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.87690001726151,-0.44279399514198,0.16696099936962,0.084307998418808,-92.842826843262,91.021690368652,161.35585021973)
    AddCameraShot(0.93181598186493,-0.18120600283146,-0.30867800116539,-0.060026999562979,-147.39654541016,25.021837234497,128.23318481445)
    AddCameraShot(0.90984201431274,-0.26207301020622,0.30915600061417,0.089050002396107,-91.736038208008,34.621788024902,163.73963928223)
    AddCameraShot(0.81341201066971,-0.19374799728394,-0.53354901075363,-0.12708699703217,-70.256042480469,25.6217918396,115.02828979492)
    AddCameraShot(0.96838802099228,-0.1817380040884,-0.16796100139618,-0.031520999968052,-27.984699249268,17.221786499023,142.23393249512)
    AddCameraShot(0.98570501804352,-0.078089997172356,-0.14882600307465,-0.011789999902248,-35.218330383301,15.421706199646,16.46501159668)
    AddCameraShot(0.55917698144913,-0.053045999258757,-0.82365202903748,-0.078134998679161,-71.415992736816,16.921689987183,-12.113597869873)
    AddCameraShot(0.14699600636959,-0.058008998632431,-0.91850000619888,-0.36246898770332,-220.06706237793,26.905960083008,28.651220321655)
    AddCameraShot(0.98270100355148,-0.13593299686909,-0.12459799647331,-0.01723499968648,-222.85929870605,18.505958557129,68.993171691895)
    AddCameraShot(0.80050301551819,-0.2051550000906,-0.5454940199852,-0.1397999972105,-352.6296081543,23.605941772461,117.73554992676)
    AddCameraShot(0.88270097970963,-0.040038999170065,-0.46774700284004,-0.021216999739408,-318.31625366211,3.5059549808502,125.7529296875)
    AddCameraShot(0.56367599964142,-0.10991100221872,0.80351799726486,0.15667800605297,-231.59262084961,22.405914306641,223.86767578125)
    AddCameraShot(0.93839198350906,0.11275800317526,0.32432499527931,-0.038970999419689,-251.60891723633,1.1059249639511,266.06631469727)
    AddCameraShot(0.7230190038681,0.10055500268936,0.67695397138596,-0.094148002564907,-39.843826293945,0.80589401721954,111.41689300537)
    AddCameraShot(0.96820902824402,0.021490000188351,-0.24915599822998,0.0055300001986325,-75.747406005859,12.505873680115,75.078300476074)
    AddCameraShot(0.26442900300026,-0.053654998540878,-0.94368398189545,-0.19148199260235,-125.55699920654,26.6058177948,48.87459564209)
end

