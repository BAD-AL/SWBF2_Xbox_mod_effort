--nelg_hero.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveTDM")

function ScriptPostLoad()
    EnableSPHeroRules()
    TDM = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, multiplayerScoreLimit = 100, textATT = "game.modes.tdm", textDEF = "game.modes.tdm2", multiplayerRules = true, isCelebrityDeathmatch = true })
    TDM:Start()
    AddAIGoal(1,"Deathmatch",100)
    AddAIGoal(2,"Deathmatch",100)
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    SetMemoryPoolSize("ClothData",30)
    SetMemoryPoolSize("Combo",70)
    SetMemoryPoolSize("Combo::State",850)
    SetMemoryPoolSize("Combo::Transition",850)
    SetMemoryPoolSize("Combo::Condition",850)
    SetMemoryPoolSize("Combo::Attack",750)
    SetMemoryPoolSize("Combo::DamageSample",8000)
    SetMemoryPoolSize("Combo::Deflect",140)
    ReadDataFile("ingame.lvl")
    ALL = 1
    IMP = 2
    ATT = 1
    DEF = 2
    SetMaxFlyHeight(150)
    SetMaxPlayerFlyHeight(150)
    ReadDataFile("sound\\tat.lvl;tat2gcw")
    ReadDataFile("SIDE\\all.lvl","all_hero_luke_jedi","all_hero_leia","all_hero_chewbacca")
    ReadDataFile("SIDE\\imp.lvl","imp_hero_darthvader","imp_hero_emperor","imp_hero_bobafett")
    ReadDataFile("SIDE\\heroes.lvl","all_hero_hansolo_tat","rep_hero_anakin","rep_hero_obiwan")
    ReadDataFile("SIDE\\rep.lvl","rep_hero_yoda","rep_hero_macewindu","rep_hero_kiyadimundi","rep_hero_obiwan")
    ReadDataFile("SIDE\\cis.lvl","cis_hero_darthmaul","cis_hero_countdooku","cis_hero_jangofett")
    SetupTeams({ 
        hero =         { team = ALL, units = 32, reinforcements = -1, 
          soldier =           { "all_hero_hansolo_tat", 1, 2 }, 
          assault =           { "all_hero_chewbacca", 1, 2 }, 
          engineer =           { "all_hero_luke_jedi", 1, 2 }, 
          sniper =           { "rep_hero_obiwan", 1, 2 }, 
          officer =           { "rep_hero_yoda", 1, 2 }, 
          special =           { "rep_hero_macewindu", 1, 2 }
         }
       })
    AddUnitClass(ALL,"all_hero_leia",1,2)
    AddUnitClass(ALL,"rep_hero_kiyadimundi",1,2)
    SetupTeams({ 
        villain =         { team = IMP, units = 32, reinforcements = -1, 
          soldier =           { "imp_hero_bobafett", 1, 2 }, 
          assault =           { "imp_hero_darthvader", 1, 2 }, 
          engineer =           { "cis_hero_darthmaul", 1, 2 }, 
          sniper =           { "cis_hero_jangofett", 1, 2 }, 
          officer =           { "rep_hero_anakin", 1, 2 }, 
          special =           { "imp_hero_emperor", 1, 2 }
         }
       })
    AddUnitClass(IMP,"cis_hero_countdooku",1,2)
    AddUnitClass(IMP,"cis_hero_ventress",1,2)
    ClearWalkers()
    AddWalkerType(0,0)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",1)
    SetMemoryPoolSize("AmmoCounter",150)
    SetMemoryPoolSize("BaseHint",320)
    SetMemoryPoolSize("ConnectivityGraphFollower",23)
    SetMemoryPoolSize("EnergyBar",150)
    SetMemoryPoolSize("EntityCloth",41)
    SetMemoryPoolSize("EntityDefenseGridTurret",0)
    SetMemoryPoolSize("EntityDroid",0)
    SetMemoryPoolSize("EntityFlyer",5)
    SetMemoryPoolSize("EntityLight",80,80)
    SetMemoryPoolSize("EntityPortableTurret",0)
    SetMemoryPoolSize("EntitySoundStream",2)
    SetMemoryPoolSize("EntitySoundStatic",45)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",120)
    SetMemoryPoolSize("MountedTurret",0)
    SetMemoryPoolSize("Navigator",30)
    SetMemoryPoolSize("Obstacle",667)
    SetMemoryPoolSize("Ordnance",80)
    SetMemoryPoolSize("ParticleEmitter",512)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("PathFollower",30)
    SetMemoryPoolSize("PathNode",128)
    SetMemoryPoolSize("SoldierAnimation",1200)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("TentacleSimulator",24)
    SetMemoryPoolSize("TreeGridStack",290)
    SetMemoryPoolSize("UnitAgent",30)
    SetMemoryPoolSize("UnitController",35)
    SetMemoryPoolSize("Weapon",150)
    SetSpawnDelay(10,0.25)
    ReadDataFile("NEL\\NEL.lvl","NEL_eli")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\tat.lvl","tat2")
    OpenAudioStream("sound\\tat.lvl","tat2")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"gen_amb_celebDeathmatch",0,1)
    SetAmbientMusic(IMP,1,"gen_amb_celebDeathmatch",0,1)
    SetVictoryMusic(ALL,"all_tat_amb_victory")
    SetDefeatMusic(ALL,"all_tat_amb_defeat")
    SetVictoryMusic(IMP,"imp_tat_amb_victory")
    SetDefeatMusic(IMP,"imp_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.70252799987793,-0.18260499835014,0.66570901870728,0.1730349957943,88.019607543945,119.32252502441,6.2259159088135)
    AddCameraShot(0.94283199310303,-0.22129499912262,-0.24260100722313,-0.056940998882055,-60.964904785156,108.96562194824,81.692283630371)
    AddCameraShot(0.92140698432922,-0.097567997872829,-0.37406000494957,-0.039609000086784,-112.23388671875,108.96562194824,136.24380493164)
    AddCameraShot(0.96467399597168,-0.2520309984684,-0.07422199845314,-0.019391000270844,-2.3616919517517,103.43183898926,33.009258270264)
    AddCameraShot(0.65242999792099,-0.069912001490593,-0.75032198429108,-0.080401003360748,-117.73081970215,103.43183898926,11.439115524292)
    AddCameraShot(-0.23905900120735,0.018079999834299,-0.96807199716568,-0.073216997087002,31.372383117676,110.72171783447,69.614196777344)
    AddCameraShot(0.41184198856354,0.029211999848485,-0.90850400924683,0.064438998699188,-11.281128883362,86.811317443848,-29.294544219971)
    AddCameraShot(0.73310297727585,-0.28167900443077,-0.57785797119141,-0.22202999889851,-50.071311950684,107.50148010254,81.472244262695)
    AddDeathRegion("deathregion")
end

