--shac_bf1.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "eli_cp1" })
    cp2 = CommandPost:New({ name = "eli_cp2" })
    cp3 = CommandPost:New({ name = "eli_cp3" })
    cp4 = CommandPost:New({ name = "eli_cp4" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(150)
    SetMaxPlayerFlyHeight(150)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\dag.lvl;dag1cw")
    ReadDataFile("SIDE\\swbf1.lvl","rep_inf_ep2_rifleman","rep_inf_ep2_rocketeer","rep_inf_ep2_pilot","rep_inf_ep2_sniper","rep_inf_ep2_jettrooper","cis_inf_droideka_hunt","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_pilot","cis_inf_sniper")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_droideka")
    SetupTeams({ 
        rep =         { team = 1, units = 20, reinforcements = 150, 
          soldier =           { "rep_inf_ep2_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep2_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep2_pilot", 1, 4 }, 
          sniper =           { "rep_inf_ep2_sniper", 1, 4 }, 
          special =           { "rep_inf_ep2_jettrooper", 1, 4 }
         }, 
        cis =         { team = 2, units = 20, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_pilot", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          special =           { "cis_inf_droideka_hunt", 1, 4 }
         }
       })
    AddWalkerType(0,4)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("AmmoCounter",1024)
    SetMemoryPoolSize("BaseHint",1024)
    SetMemoryPoolSize("EnergyBar",1024)
    SetMemoryPoolSize("EntityCloth",32)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityHover",32)
    SetMemoryPoolSize("EntityLight",200)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",32)
    SetMemoryPoolSize("MountedTurret",32)
    SetMemoryPoolSize("Navigator",128)
    SetMemoryPoolSize("Obstacle",1024)
    SetMemoryPoolSize("PathNode",1024)
    SetMemoryPoolSize("SoundSpaceRegion",64)
    SetMemoryPoolSize("TreeGridStack",1024)
    SetMemoryPoolSize("UnitAgent",128)
    SetMemoryPoolSize("UnitController",128)
    SetMemoryPoolSize("Weapon",1024)
    SetMemoryPoolSize("SoldierAnimation",1000)
    SetSpawnDelay(10,0.25)
    ReadDataFile("SHA\\SHA.lvl","SHA_eli")
    SetDenseEnvironment("false")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\dag.lvl","dag1")
    OpenAudioStream("sound\\dag.lvl","dag1")
    SetBleedingVoiceOver(1,1,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(1,2,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(2,1,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(2,2,"cis_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetAmbientMusic(1,1,"rep_dag_amb_start",0,1)
    SetAmbientMusic(1,0.80000001192093,"rep_dag_amb_middle",1,1)
    SetAmbientMusic(1,0.20000000298023,"rep_dag_amb_end",2,1)
    SetAmbientMusic(2,1,"cis_dag_amb_start",0,1)
    SetAmbientMusic(2,0.80000001192093,"cis_dag_amb_middle",1,1)
    SetAmbientMusic(2,0.20000000298023,"cis_dag_amb_end",2,1)
    SetVictoryMusic(1,"rep_dag_amb_victory")
    SetDefeatMusic(1,"rep_dag_amb_defeat")
    SetVictoryMusic(2,"cis_dag_amb_victory")
    SetDefeatMusic(2,"cis_dag_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.73300802707672,-0.042259998619556,0.67777997255325,0.039076000452042,-0.302630007267,28.794353485107,75.827964782715)
    AddCameraShot(0.75283199548721,0.032205998897552,0.65682297945023,-0.028098000213504,80.700004577637,52.86413192749,7.2932300567627)
    AddCameraShot(0.73817300796509,-0.18660500645638,0.62851798534393,0.15888500213623,80.287796020508,56.51651763916,7.3138041496277)
    AddCameraShot(0.97721201181412,-0.18520499765873,0.10189999639988,0.019311999902129,68.38257598877,45.097171783447,-38.306804656982)
end

