--bes2c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    SoundEvent_SetupTeams(CIS,"cis",REP,"rep")
    SetProperty("DEF_Flag","GeometryName","com_icon_cis_flag")
    SetProperty("DEF_Flag","CarriedGeometryName","com_icon_cis_flag_carried")
    SetProperty("ATT_Flag","GeometryName","com_icon_republic_flag")
    SetProperty("ATT_Flag","CarriedGeometryName","com_icon_republic_flag_carried")
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 5, textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", multiplayerRules = true, hideCPs = true })
    ctf:AddFlag({ name = "ATT_Flag", homeRegion = "ATT_home", captureRegion = "DEF_home", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "DEF_Flag", homeRegion = "DEF_home", captureRegion = "ATT_home", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(-5)
    SetMaxPlayerFlyHeight(-5)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\hero.lvl;herogcw")
    ReadDataFile("sound\\dea.lvl;dea1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_officer","cis_inf_sniper","cis_inf_droideka","cis_hover_aat")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_laser","tur_bldg_tower","tur_weap_built_gunturret")
    ReadDataFile("SIDE\\dlc.lvl","dlc_hero_fisto","dlc_hero_ventress")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_commando","cis_inf_commando")
    SetupTeams({ 
        rep =         { team = REP, units = 20, reinforcements = 150, 
          soldier =           { "rep_inf_ep3_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep3_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 1, 4 }, 
          sniper =           { "rep_inf_ep3_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep3_officer", 1, 4 }, 
          special =           { "rep_inf_ep3_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 20, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_engineer", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          officer =           { "cis_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    AddUnitClass(REP,"rep_inf_commando",1,2)
    AddUnitClass(CIS,"cis_inf_commando",1,2)
    SetHeroClass(REP,"dlc_hero_fisto")
    SetHeroClass(CIS,"dlc_hero_ventress")
    ClearWalkers()
    AddWalkerType(0,12)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",30)
    SetMemoryPoolSize("Combo::State",500)
    SetMemoryPoolSize("Combo::Transition",500)
    SetMemoryPoolSize("Combo::Condition",500)
    SetMemoryPoolSize("Combo::Attack",400)
    SetMemoryPoolSize("Combo::DamageSample",4000)
    SetMemoryPoolSize("Combo::Deflect",88)
    SetMemoryPoolSize("MountedTurret",10)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("Obstacle",514)
    SetMemoryPoolSize("Weapon",280)
    SetMemoryPoolSize("SoundSpaceRegion",38)
    SetSpawnDelay(10,0.25)
    ReadDataFile("BES\\bes2.lvl","bespin2_CTF")
    SetDenseEnvironment("true")
    AddDeathRegion("DeathRegion")
    AddDeathRegion("DeathRegion2")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\dea.lvl","dea1")
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_dea_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_dea_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_dea_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_dea_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_dea_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_dea_amb_end",2,1)
    SetVictoryMusic(REP,"rep_dea_amb_victory")
    SetDefeatMusic(REP,"rep_dea_amb_defeat")
    SetVictoryMusic(CIS,"cis_dea_amb_victory")
    SetDefeatMusic(CIS,"cis_dea_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.87934798002243,-0.14204600453377,0.4486840069294,0.072477996349335,-38.413761138916,30.986400604248,195.87962341309)
    AddCameraShot(0.75514298677444,0.032623998820782,0.65413701534271,-0.028260000050068,-80.924102783203,-32.534858703613,59.805065155029)
    AddCameraShot(0.59651398658752,-0.068856000900269,-0.79437202215195,-0.091695003211498,-139.20362854004,-28.934867858887,56.316780090332)
    AddCameraShot(0.073601998388767,-0.011602000333369,-0.98505997657776,-0.15527200698853,-118.28823852539,-28.934867858887,125.93835449219)
    AddCameraShot(0.90268701314926,0.0012740000383928,0.43029499053955,-0.00060700002359226,-90.957382202148,-47.834819793701,180.83178710938)
    AddCameraShot(-0.4188149869442,-0.024035999551415,-0.9062619805336,0.052011001855135,-162.06648254395,-47.23482131958,80.504837036133)
    AddCameraShot(0.98835700750351,0.062969997525215,0.13822799921036,-0.0088069997727871,-173.7740020752,-55.334800720215,142.56781005859)
    AddCameraShot(-0.10055399686098,0.0081599997356534,-0.99163901805878,-0.080476000905037,-246.95443725586,-31.334861755371,153.43881225586)
    AddCameraShot(0.71716398000717,-0.018075000494719,0.69644898176193,0.017552999779582,-216.82719421387,-31.334861755371,186.86364746094)
    AddCameraShot(0.84485000371933,-0.049701999872923,0.53176999092102,0.031284000724554,-247.18145751953,-45.734825134277,29.732486724854)
    AddCameraShot(0.45488101243973,0.028302000835538,-0.88838398456573,0.055273000150919,-291.63665771484,-48.734817504883,21.009202957153)
    AddCameraShot(0.81832200288773,-0.026149999350309,-0.57387399673462,-0.0183390006423,-193.43464660645,-58.634792327881,-12.443043708801)
    AddCameraShot(0.4711090028286,0.0046910000964999,-0.88201802968979,0.0087829995900393,-192.2516784668,-61.334785461426,-32.647247314453)
end

