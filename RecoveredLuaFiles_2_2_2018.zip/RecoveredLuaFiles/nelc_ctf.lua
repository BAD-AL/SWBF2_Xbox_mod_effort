--nelc_ctf.lua
-- Decompiled with SWBF2CodeHelper
Conquest = ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = REP
DEF = CIS

function ScriptPostLoad()
    SoundEvent_SetupTeams(REP,"rep",CIS,"cis")
    SetProperty("flag1","GeometryName","com_icon_republic_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_republic_flag_carried")
    SetProperty("flag2","GeometryName","com_icon_cis_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_cis_flag_carried")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = REP, teamDEF = CIS, captureLimit = 5, textATT = "game.modes.ctf", textDEF = "game.modes.ctf2", multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "team1_capture", captureRegion = "team2_capture", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "team2_capture", captureRegion = "team1_capture", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(150)
    SetMaxPlayerFlyHeight(150)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\uta.lvl;uta1cw")
    ReadDataFile("SIDE\\heroes.lvl","rep_hero_obiwan")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper","rep_hero_obiwan","rep_hero_aalya")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka")
    ReadDataFile("SIDE\\all.lvl","all_walk_tauntaun")
    ReadDataFile("SIDE\\dlc.lvl","dlc_hero_ventress")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_commando","cis_inf_commando")
    SetupTeams({ 
        rep =         { team = REP, units = 32, reinforcements = 150, 
          soldier =           { "rep_inf_ep3_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep3_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 1, 4 }, 
          sniper =           { "rep_inf_ep3_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep3_officer", 1, 4 }, 
          special =           { "rep_inf_ep3_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 32, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_engineer", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          officer =           { "cis_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    AddUnitClass(REP,"rep_inf_commando",1,2)
    AddUnitClass(CIS,"cis_inf_commando",1,2)
    SetHeroClass(CIS,"dlc_hero_ventress")
    SetHeroClass(REP,"rep_hero_obiwan")
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("AmmoCounter",1024)
    SetMemoryPoolSize("BaseHint",1024)
    SetMemoryPoolSize("CommandWalker",2)
    SetMemoryPoolSize("EnergyBar",1024)
    SetMemoryPoolSize("EntityCloth",32)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityHover",32)
    SetMemoryPoolSize("EntityLight",200)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",32)
    SetMemoryPoolSize("MountedTurret",32)
    SetMemoryPoolSize("Navigator",128)
    SetMemoryPoolSize("Obstacle",1024)
    SetMemoryPoolSize("PathNode",1024)
    SetMemoryPoolSize("SoldierAnimation",512)
    SetMemoryPoolSize("SoundSpaceRegion",64)
    SetMemoryPoolSize("TreeGridStack",1024)
    SetMemoryPoolSize("UnitAgent",128)
    SetMemoryPoolSize("UnitController",128)
    SetMemoryPoolSize("Weapon",1024)
    SetSpawnDelay(10,0.25)
    ReadDataFile("NEL\\NEL.lvl","NEL_conquest")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\uta.lvl","uta1")
    OpenAudioStream("sound\\uta.lvl","uta1")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetAmbientMusic(REP,1,"rep_uta_amb_start",0,1)
    SetAmbientMusic(REP,0.80000001192093,"rep_uta_amb_middle",1,1)
    SetAmbientMusic(REP,0.20000000298023,"rep_uta_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_uta_amb_start",0,1)
    SetAmbientMusic(CIS,0.80000001192093,"cis_uta_amb_middle",1,1)
    SetAmbientMusic(CIS,0.20000000298023,"cis_uta_amb_end",2,1)
    SetVictoryMusic(REP,"rep_uta_amb_victory")
    SetDefeatMusic(REP,"rep_uta_amb_defeat")
    SetVictoryMusic(CIS,"cis_uta_amb_victory")
    SetDefeatMusic(CIS,"cis_uta_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.70252799987793,-0.18260499835014,0.66570901870728,0.1730349957943,88.019607543945,119.32252502441,6.2259159088135)
    AddCameraShot(0.94283199310303,-0.22129499912262,-0.24260100722313,-0.056940998882055,-60.964904785156,108.96562194824,81.692283630371)
    AddCameraShot(0.92140698432922,-0.097567997872829,-0.37406000494957,-0.039609000086784,-112.23388671875,108.96562194824,136.24380493164)
    AddCameraShot(0.96467399597168,-0.2520309984684,-0.07422199845314,-0.019391000270844,-2.3616919517517,103.43183898926,33.009258270264)
    AddCameraShot(0.65242999792099,-0.069912001490593,-0.75032198429108,-0.080401003360748,-117.73081970215,103.43183898926,11.439115524292)
    AddCameraShot(-0.23905900120735,0.018079999834299,-0.96807199716568,-0.073216997087002,31.372383117676,110.72171783447,69.614196777344)
    AddCameraShot(0.41184198856354,0.029211999848485,-0.90850400924683,0.064438998699188,-11.281128883362,86.811317443848,-29.294544219971)
    AddCameraShot(0.73310297727585,-0.28167900443077,-0.57785797119141,-0.22202999889851,-50.071311950684,107.50148010254,81.472244262695)
    AddDeathRegion("deathregion")
end

