-- Decompiled with SWBF2CodeHelper
-- cx1g_hero.lua

ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveTDM")

function ScriptPostLoad()
    --removeCapture({ "cp1", "cp2", "cp3", "cp4" })
    SetProperty("cp1", "CaptureRegion", "")
    SetProperty("cp2", "CaptureRegion", "")
    SetProperty("cp3", "CaptureRegion", "")
    SetProperty("cp4", "CaptureRegion", "")

    EnableSPHeroRules()
    TDM =
        ObjectiveTDM:New(
        {
            teamATT = 1,
            teamDEF = 2,
            multiplayerScoreLimit = 100,
            textATT = "game.modes.tdm",
            textDEF = "game.modes.tdm2",
            multiplayerRules = true,
            isCelebrityDeathmatch = true
        }
    )
    TDM:Start()
    AddAIGoal(1, "Deathmatch", 100)
    AddAIGoal(2, "Deathmatch", 100)
end

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMemoryPoolSize("ClothData", 20)
    SetMemoryPoolSize("Combo", 70)
    SetMemoryPoolSize("Combo::State", 850)
    SetMemoryPoolSize("Combo::Transition", 850)
    SetMemoryPoolSize("Combo::Condition", 850)
    SetMemoryPoolSize("Combo::Attack", 750)
    SetMemoryPoolSize("Combo::DamageSample", 8000)
    SetMemoryPoolSize("Combo::Deflect", 140)
    ALL = 1
    IMP = 2
    ATT = 1
    DEF = 2
    SetMaxFlyHeight(40)
    SetMaxPlayerFlyHeight(40)
    ReadDataFile("sound\\tat.lvl;tat2gcw")
    ReadDataFile("SIDE\\heroes.lvl", "rep_hero_anakin", "rep_hero_obiwan", "rep_hero_quigon", "imp_hero_starkiller")
    ReadDataFile("SIDE\\all.lvl", "all_hero_luke_jedi")
    ReadDataFile("SIDE\\imp.lvl", "imp_hero_darthvader", "imp_hero_emperor")
    ReadDataFile("SIDE\\heroes.lvl", "rep_hero_obiwan")
    ReadDataFile("SIDE\\rep.lvl", "rep_hero_yoda", "rep_hero_macewindu", "rep_hero_aalya", "rep_hero_obiwan")
    ReadDataFile("SIDE\\cis.lvl", "cis_hero_grievous", "cis_hero_countdooku", "cis_hero_darthmaul")
    ReadDataFile("SIDE\\dlc.lvl", "dlc_hero_fisto", "dlc_hero_ventress")
    SetupTeams(
        {
            hero = {
                team = ALL,
                units = 12,
                reinforcements = -1,
                soldier = {"rep_hero_quigon", 1, 2},
                assault = {"all_hero_chewbacca", 1, 2},
                engineer = {"all_hero_luke_jedi", 1, 2},
                sniper = {"rep_hero_obiwan", 1, 2},
                officer = {"rep_hero_yoda", 1, 2},
                special = {"rep_hero_macewindu", 1, 2}
            }
        }
    )
    AddUnitClass(ALL, "rep_hero_aalya", 1, 2)
    AddUnitClass(ALL, "dlc_hero_fisto", 1, 2)
    SetupTeams(
        {
            villain = {
                team = IMP,
                units = 12,
                reinforcements = -1,
                soldier = {"cis_hero_darthmaul", 1, 2},
                assault = {"imp_hero_darthvader", 1, 2},
                engineer = {"rep_hero_anakin", 1, 2},
                sniper = {"imp_hero_starkiller", 1, 2},
                officer = {"cis_hero_grievous", 1, 2},
                special = {"imp_hero_emperor", 1, 2}
            }
        }
    )
    AddUnitClass(IMP, "dlc_hero_ventress", 1, 2)
    AddUnitClass(IMP, "cis_hero_countdooku", 1, 2)
    ClearWalkers()
    AddWalkerType(0, 0)
    AddWalkerType(1, 0)
    AddWalkerType(2, 0)
    AddWalkerType(3, 0)
    SetMemoryPoolSize("Aimer", 1)
    SetMemoryPoolSize("AmmoCounter", 96)
    SetMemoryPoolSize("BaseHint", 320)
    SetMemoryPoolSize("ConnectivityGraphFollower", 23)
    SetMemoryPoolSize("EnergyBar", 96)
    SetMemoryPoolSize("EntityCloth", 41)
    SetMemoryPoolSize("EntityDefenseGridTurret", 0)
    SetMemoryPoolSize("EntityDroid", 0)
    SetMemoryPoolSize("EntityFlyer", 5)
    SetMemoryPoolSize("EntityLight", 80, 80)
    SetMemoryPoolSize("EntityPortableTurret", 0)
    SetMemoryPoolSize("EntitySoundStream", 2)
    SetMemoryPoolSize("EntitySoundStatic", 45)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix", 120)
    SetMemoryPoolSize("MountedTurret", 0)
    SetMemoryPoolSize("Navigator", 23)
    SetMemoryPoolSize("Obstacle", 667)
    SetMemoryPoolSize("Ordnance", 80)
    SetMemoryPoolSize("ParticleEmitter", 512)
    SetMemoryPoolSize("ParticleEmitterInfoData", 512)
    SetMemoryPoolSize("PathFollower", 23)
    SetMemoryPoolSize("PathNode", 128)
    SetMemoryPoolSize("ShieldEffect", 0)
    SetMemoryPoolSize("TentacleSimulator", 24)
    SetMemoryPoolSize("TreeGridStack", 290)
    SetMemoryPoolSize("UnitAgent", 23)
    SetMemoryPoolSize("UnitController", 23)
    SetMemoryPoolSize("Weapon", 96)
    SetSpawnDelay(10, 0.25)
    ReadDataFile("CX1\\CX1.lvl", "CX1_eli")
    SetDenseEnvironment("false")
    ScriptCB_EnableHeroMusic(0)
    ScriptCB_EnableHeroVO(0)
    voiceSlow = OpenAudioStream("sound\\global.lvl", "all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_slow", voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl", "all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_quick", voiceQuick)
    OpenAudioStream("sound\\global.lvl", "gcw_music")
    OpenAudioStream("sound\\tat.lvl", "tat2")
    OpenAudioStream("sound\\tat.lvl", "tat2")
    SetBleedingVoiceOver(ALL, ALL, "all_off_com_report_us_overwhelmed", 1)
    SetBleedingVoiceOver(ALL, IMP, "all_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(IMP, ALL, "imp_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(IMP, IMP, "imp_off_com_report_us_overwhelmed", 1)
    SetLowReinforcementsVoiceOver(ALL, ALL, "all_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(ALL, IMP, "all_off_victory_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(IMP, IMP, "imp_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(IMP, ALL, "imp_off_victory_im", 0.10000000149012, 1)
    SetOutOfBoundsVoiceOver(1, "Allleaving")
    SetOutOfBoundsVoiceOver(2, "Impleaving")
    SetAmbientMusic(ALL, 1, "gen_amb_celebDeathmatch", 0, 1)
    SetAmbientMusic(IMP, 1, "gen_amb_celebDeathmatch", 0, 1)
    SetVictoryMusic(ALL, "all_tat_amb_victory")
    SetDefeatMusic(ALL, "all_tat_amb_defeat")
    SetVictoryMusic(IMP, "imp_tat_amb_victory")
    SetDefeatMusic(IMP, "imp_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(
        0.014526000246406,
        -6.5000000176951e-005,
        -0.99988502264023,
        -0.0044399998150766,
        -0.044491000473499,
        2.466372013092,
        -23.57772064209
    )
    AddCameraShot(
        0.9537690281868,
        -0.022833000868559,
        0.29958701133728,
        0.0071720001287758,
        8.9305582046509,
        3.5308649539948,
        21.776279449463
    )
    AddCameraShot(
        0.9578469991684,
        -0.088636003434658,
        0.27210199832916,
        0.02517900057137,
        5.7797741889954,
        1.920480966568,
        -29.521324157715
    )
    AddCameraShot(
        0.53610801696777,
        0.0079910000786185,
        -0.84401798248291,
        0.012581000104547,
        -95.457893371582,
        1.920480966568,
        -71.743865966797
    )
end

function removeCapture(removeCaptureParam0)
    print("ERROR: NO CPS")
end
