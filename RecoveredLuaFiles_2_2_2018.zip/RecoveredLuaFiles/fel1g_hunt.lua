--fel1g_hunt.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("setup_teams")

function ScriptPostLoad()
    SetProperty("cp1-1","CaptureRegion","")
    SetProperty("cp2-1","CaptureRegion","")
    SetProperty("cp3-1","CaptureRegion","")
    SetProperty("cp4-1","CaptureRegion","")
    SetProperty("cp5-1","CaptureRegion","")
    SetProperty("cp6-1","CaptureRegion","")
    SetProperty("cp1-1","Team","1")
    SetProperty("cp2-1","Team","2")
    SetProperty("cp3-1","Team","2")
    SetProperty("cp4-1","Team","1")
    SetProperty("cp5-1","Team","2")
    SetProperty("cp6-1","Team","1")
    hunt = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, pointsPerKillATT = 1, pointsPerKillDEF = 2, textATT = "level.geo1.objectives.hunt_att", textDEF = "level.geo1.objectives.hunt_def", multiplayerRules = true })
    hunt:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\fel.lvl;fel1gcw")
    SetMaxFlyHeight(53)
    SetMaxPlayerFlyHeight(53)
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_dark_trooper","imp_inf_officer")
    ReadDataFile("SIDE\\infantry.lvl","geo_inf_acklay","geo_inf_acklay_blue","geo_inf_acklay_brown","geo_inf_acklay_red")
    SetupTeams({ 
        acklay =         { team = 2, units = 8, reinforcements = -1, 
          soldier =           { "geo_inf_acklay", 1, 3 }, 
          assault =           { "geo_inf_acklay_blue", 1, 3 }, 
          engineer =           { "geo_inf_acklay_brown", 1, 3 }, 
          sniper =           { "geo_inf_acklay_red", 1, 3 }
         }, 
        imp =         { team = 1, units = 32, reinforcements = -1, 
          soldier =           { "imp_inf_rifleman", 9, 25 }, 
          assault =           { "imp_inf_rocketeer", 1, 4 }, 
          engineer =           { "imp_inf_engineer", 1, 4 }, 
          sniper =           { "imp_inf_sniper", 1, 4 }, 
          officer =           { "imp_inf_officer", 1, 4 }, 
          special =           { "imp_inf_dark_trooper", 1, 4 }
         }
       })
    ClearWalkers()
    SetMemoryPoolSize("EntityWalker",3)
    AddWalkerType(0,0)
    AddWalkerType(2,3)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("EntityCloth",21)
    SetMemoryPoolSize("EntityHover",3)
    SetMemoryPoolSize("Obstacle",500)
    SetMemoryPoolSize("TreeGridStack",261)
    SetMemoryPoolSize("Weapon",230)
    SetMemoryPoolSize("EntityFlyer",6)
    SetSpawnDelay(10,0.25)
    ReadDataFile("fel\\fel1.lvl","fel1_conquest")
    SetDenseEnvironment("false")
    SetAIViewMultiplier(0.64999997615814)
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\fel.lvl","fel1")
    OpenAudioStream("sound\\fel.lvl","fel1")
    SetBleedingVoiceOver(2,2,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(2,1,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(1,2,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(1,1,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(2,2,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(2,1,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(1,1,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(1,2,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"impleaving")
    SetOutOfBoundsVoiceOver(2,"allleaving")
    SetAmbientMusic(2,1,"all_fel_amb_start",0,1)
    SetAmbientMusic(2,0.80000001192093,"all_fel_amb_middle",1,1)
    SetAmbientMusic(2,0.20000000298023,"all_fel_amb_end",2,1)
    SetAmbientMusic(1,1,"imp_fel_amb_start",0,1)
    SetAmbientMusic(1,0.80000001192093,"imp_fel_amb_middle",1,1)
    SetAmbientMusic(1,0.20000000298023,"imp_fel_amb_end",2,1)
    SetVictoryMusic(2,"all_fel_amb_victory")
    SetDefeatMusic(2,"all_fel_amb_defeat")
    SetVictoryMusic(1,"imp_fel_amb_victory")
    SetDefeatMusic(1,"imp_fel_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(1)
    AddCameraShot(0.89630699157715,-0.17134800553322,-0.40171599388123,-0.076796002686024,-116.30693054199,31.039505004883,20.757469177246)
    AddCameraShot(0.90934300422668,-0.2019670009613,-0.35508298873901,-0.078864999115467,-116.30693054199,31.039505004883,20.757469177246)
    AddCameraShot(0.54319900274277,0.11552099883556,-0.81342798471451,0.17298999428749,-108.37818908691,13.564240455627,-40.644149780273)
    AddCameraShot(0.97061002254486,0.13565899431705,0.1968660056591,-0.027514999732375,-3.2143459320068,11.924586296082,-44.687294006348)
    AddCameraShot(0.34613001346588,0.046310998499393,-0.92876601219177,0.12426699697971,87.431060791016,20.881387710571,13.070729255676)
    AddCameraShot(0.4680840075016,0.095610998570919,-0.86072397232056,0.1758120059967,18.063482284546,19.360580444336,18.178157806396)
end

function OnStart(OnStartParam0)
    AddAIGoal(ATT,"Deathmatch",1000)
    AddAIGoal(DEF,"Deathmatch",1000)
end

