--tat2c_bf1.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "cp1" })
    cp2 = CommandPost:New({ name = "cp2" })
    cp3 = CommandPost:New({ name = "cp3" })
    cp6 = CommandPost:New({ name = "cp6" })
    cp7 = CommandPost:New({ name = "cp7" })
    cp8 = CommandPost:New({ name = "cp8" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp6)
    conquest:AddCommandPost(cp7)
    conquest:AddCommandPost(cp8)
    conquest:Start()
    AddAIGoal(1,"conquest",1000)
    AddAIGoal(2,"conquest",1000)
    AddAIGoal(3,"conquest",1000)
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    REP = 1
    CIS = 2
    DES = 3
    ATT = 1
    DEF = 2
    SetTeamAggressiveness(REP,0.94999998807907)
    SetTeamAggressiveness(CIS,0.94999998807907)
    SetMaxFlyHeight(40)
    SetMaxPlayerFlyHeight(40)
    ReadDataFile("sound\\tat.lvl;tat2cw")
    SetAttackingTeam(ATT)
    ReadDataFile("SIDE\\swbf1.lvl","rep_inf_ep2_rifleman","rep_inf_ep2_rocketeer","rep_inf_ep2_pilot","rep_inf_ep2_sniper","rep_inf_ep2_jettrooper","cis_inf_droideka_hunt","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_pilot","cis_inf_sniper","cis_hover_aat")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_droideka")
    ReadDataFile("SIDE\\des.lvl","tat_inf_jawa")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_tat_barge","tur_bldg_laser")
    SetupTeams({ 
        rep =         { team = REP, units = 20, reinforcements = 150, 
          soldier =           { "rep_inf_ep2_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep2_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep2_pilot", 1, 4 }, 
          sniper =           { "rep_inf_ep2_sniper", 1, 4 }, 
          special =           { "rep_inf_ep2_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 20, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_pilot", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          special =           { "cis_inf_droideka_hunt", 1, 4 }
         }
       })
    SetTeamName(3,"locals")
    AddUnitClass(3,"tat_inf_jawa",7)
    SetUnitCount(3,7)
    SetTeamAsFriend(3,ATT)
    SetTeamAsFriend(3,DEF)
    SetTeamAsFriend(ATT,3)
    SetTeamAsFriend(DEF,3)
    ClearWalkers()
    AddWalkerType(0,3)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",23)
    SetMemoryPoolSize("AmmoCounter",230)
    SetMemoryPoolSize("BaseHint",325)
    SetMemoryPoolSize("EnergyBar",230)
    SetMemoryPoolSize("EntityCloth",19)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntityHover",3)
    SetMemoryPoolSize("EntitySoundStream",2)
    SetMemoryPoolSize("EntitySoundStatic",43)
    SetMemoryPoolSize("MountedTurret",15)
    SetMemoryPoolSize("Navigator",50)
    SetMemoryPoolSize("Obstacle",667)
    SetMemoryPoolSize("PathFollower",50)
    SetMemoryPoolSize("PathNode",256)
    SetMemoryPoolSize("TreeGridStack",325)
    SetMemoryPoolSize("UnitAgent",50)
    SetMemoryPoolSize("UnitController",50)
    SetMemoryPoolSize("Weapon",230)
    SetSpawnDelay(10,0.25)
    ReadDataFile("TAT\\tat2.lvl","tat2_con")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","des_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\tat.lvl","tat2")
    OpenAudioStream("sound\\tat.lvl","tat2")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(REP,REP,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(REP,CIS,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,CIS,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,REP,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetAmbientMusic(REP,1,"rep_tat_amb_start",0,1)
    SetAmbientMusic(REP,0.80000001192093,"rep_tat_amb_middle",1,1)
    SetAmbientMusic(REP,0.20000000298023,"rep_tat_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_tat_amb_start",0,1)
    SetAmbientMusic(CIS,0.80000001192093,"cis_tat_amb_middle",1,1)
    SetAmbientMusic(CIS,0.20000000298023,"cis_tat_amb_end",2,1)
    SetVictoryMusic(REP,"rep_tat_amb_victory")
    SetDefeatMusic(REP,"rep_tat_amb_defeat")
    SetVictoryMusic(CIS,"cis_tat_amb_victory")
    SetDefeatMusic(CIS,"cis_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.97433799505234,-0.22217999398708,0.035172000527382,0.0080199996009469,-82.664649963379,23.668300628662,43.955680847168)
    AddCameraShot(0.39019700884819,-0.089729003608227,-0.89304000139236,-0.2053620070219,23.563562393188,12.914884567261,-101.46556091309)
    AddCameraShot(0.16975900530815,0.0022249999456108,-0.98539799451828,0.012915999628603,126.97280883789,4.0396280288696,-22.020612716675)
    AddCameraShot(0.67745298147202,-0.041535001248121,0.73301601409912,0.044941999018192,97.517807006836,4.0396280288696,36.853477478027)
    AddCameraShot(0.86602902412415,-0.15650600194931,0.46729901432991,0.084449000656605,7.6856398582458,7.1306881904602,-10.895234107971)
end

