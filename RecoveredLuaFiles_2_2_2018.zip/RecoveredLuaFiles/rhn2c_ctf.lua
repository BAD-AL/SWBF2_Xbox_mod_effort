--rhn2c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    SoundEvent_SetupTeams(CIS,"cis",REP,"rep")
    SetProperty("flag2","GeometryName","com_icon_cis_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_cis_flag_carried")
    SetProperty("flag1","GeometryName","com_icon_republic_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_republic_flag_carried")
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 5, textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag2_capture", captureRegion = "flag1_capture", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag1_capture", captureRegion = "flag2_capture", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\hero.lvl;herogcw")
    ReadDataFile("sound\\geo.lvl;geo1cw")
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",20)
    SetMemoryPoolSize("Combo::State",300)
    SetMemoryPoolSize("Combo::Transition",300)
    SetMemoryPoolSize("Combo::Condition",300)
    SetMemoryPoolSize("Combo::Attack",150)
    SetMemoryPoolSize("Combo::DamageSample",1800)
    SetMemoryPoolSize("Combo::Deflect",50)
    SetMaxFlyHeight(30)
    SetMaxPlayerFlyHeight(30)
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_officer","cis_inf_sniper","cis_inf_droideka","cis_hero_darthmaul")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_laser")
    ReadDataFile("SIDE\\dlc.lvl","dlc_hero_fisto")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_commando","cis_inf_commando")
    SetupTeams({ 
        rep =         { team = REP, units = 20, reinforcements = 150, 
          soldier =           { "rep_inf_ep3_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep3_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 1, 4 }, 
          sniper =           { "rep_inf_ep3_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep3_officer", 1, 4 }, 
          special =           { "rep_inf_ep3_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 20, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_engineer", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          officer =           { "cis_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    AddUnitClass(REP,"rep_inf_commando",1,2)
    AddUnitClass(CIS,"cis_inf_commando",1,2)
    SetHeroClass(REP,"dlc_hero_fisto")
    SetHeroClass(CIS,"cis_hero_darthmaul")
    ClearWalkers()
    AddWalkerType(0,4)
    AddWalkerType(1,5)
    AddWalkerType(2,2)
    SetMemoryPoolSize("Aimer",80)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("AmmoCounter",221)
    SetMemoryPoolSize("BaseHint",175)
    SetMemoryPoolSize("CommandWalker",2)
    SetMemoryPoolSize("ConnectivityGraphFollower",56)
    SetMemoryPoolSize("EnergyBar",221)
    SetMemoryPoolSize("EntityCloth",41)
    SetMemoryPoolSize("EntityFlyer",10)
    SetMemoryPoolSize("EntityLight",110)
    SetMemoryPoolSize("EntitySoundStatic",16)
    SetMemoryPoolSize("EntitySoundStream",5)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",54)
    SetMemoryPoolSize("MountedTurret",30)
    SetMemoryPoolSize("Navigator",63)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("PathFollower",63)
    SetMemoryPoolSize("PathNode",160)
    SetMemoryPoolSize("ShieldEffect",4)
    SetMemoryPoolSize("TreeGridStack",300)
    SetMemoryPoolSize("UnitController",63)
    SetMemoryPoolSize("UnitAgent",63)
    SetMemoryPoolSize("Weapon",221)
    ReadDataFile("RHN\\RHN2.lvl","rhenvar2_ctf")
    SetSpawnDelay(10,0.25)
    SetDenseEnvironment("true")
    SetDefenderSnipeRange(170)
    AddDeathRegion("FalltoDeath")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\geo.lvl","geo1cw")
    OpenAudioStream("sound\\geo.lvl","geo1cw")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(REP,REP,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(REP,CIS,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,CIS,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,REP,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetAmbientMusic(REP,1,"rep_GEO_amb_start",0,1)
    SetAmbientMusic(REP,0.80000001192093,"rep_GEO_amb_middle",1,1)
    SetAmbientMusic(REP,0.20000000298023,"rep_GEO_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_GEO_amb_start",0,1)
    SetAmbientMusic(CIS,0.80000001192093,"cis_GEO_amb_middle",1,1)
    SetAmbientMusic(CIS,0.20000000298023,"cis_GEO_amb_end",2,1)
    SetVictoryMusic(REP,"rep_geo_amb_victory")
    SetDefeatMusic(REP,"rep_geo_amb_defeat")
    SetVictoryMusic(CIS,"cis_geo_amb_victory")
    SetDefeatMusic(CIS,"cis_geo_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.99400502443314,-0.10907299816608,0.0074860001914203,0.00082100002327934,-203.09790039063,26.624816894531,-101.68248748779)
    AddCameraShot(0.10432799905539,-0.022316999733448,-0.97229599952698,-0.20798400044441,-266.39813232422,24.95322227478,-251.51359558105)
    AddCameraShot(0.90822702646255,0.026134999468923,0.4174889922142,-0.01201399974525,-101.17641448975,12.784149169922,-199.05393981934)
end

