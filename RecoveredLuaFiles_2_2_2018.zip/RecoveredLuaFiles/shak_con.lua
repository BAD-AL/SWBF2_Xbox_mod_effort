--shak_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "eli_cp1" })
    cp2 = CommandPost:New({ name = "eli_cp2" })
    cp3 = CommandPost:New({ name = "eli_cp3" })
    cp4 = CommandPost:New({ name = "eli_cp4" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(150)
    SetMaxPlayerFlyHeight(150)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\hot.lvl;hot1gcw")
    ReadDataFile("SIDE\\rep.lvl","rep_hero_obiwan","rep_hero_kiyadimundi")
    ReadDataFile("SIDE\\cis.lvl","cis_hero_countdooku")
    ReadDataFile("SIDE\\kotor.lvl","kor_hero_bastila","kor_hero_sion","rvs_inf_rbasic","rvs_inf_sbasic","rvs_inf_rheavy","rvs_inf_sheavy","rvs_inf_rsupport","rvs_inf_ssupport","rvs_inf_rstealth","rvs_inf_sstealth","rvs_inf_sadept","rvs_inf_radept","rvs_inf_rofficer","rvs_inf_sofficer","rvs_inf_rdroid","rvs_inf_sdroid")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_tat_barge","tur_bldg_laser")
    SetupTeams({ 
        rep =         { team = 1, units = 20, reinforcements = 150, 
          soldier =           { "rvs_inf_rbasic", 7, 24 }, 
          assault =           { "rvs_inf_rheavy", 2, 8 }, 
          engineer =           { "rvs_inf_rdroid", 2, 8 }, 
          sniper =           { "rvs_inf_rsupport", 2, 8 }, 
          officer =           { "rvs_inf_rofficer", 2, 8 }, 
          special =           { "rvs_inf_rstealth", 1, 4 }
         }, 
        imp =         { team = 2, units = 20, reinforcements = 150, 
          soldier =           { "rvs_inf_sbasic", 7, 24 }, 
          assault =           { "rvs_inf_sheavy", 2, 8 }, 
          engineer =           { "rvs_inf_sdroid", 2, 8 }, 
          sniper =           { "rvs_inf_ssupport", 2, 8 }, 
          officer =           { "rvs_inf_sofficer", 2, 8 }, 
          special =           { "rvs_inf_sstealth", 1, 4 }
         }
       })
    AddUnitClass(1,"rvs_inf_radept",1,2)
    AddUnitClass(2,"rvs_inf_sadept",1,2)
    SetHeroClass(1,"kor_hero_bastila")
    SetHeroClass(2,"kor_hero_sion")
    AddWalkerType(0,4)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("AmmoCounter",1024)
    SetMemoryPoolSize("BaseHint",1024)
    SetMemoryPoolSize("EnergyBar",1024)
    SetMemoryPoolSize("EntityCloth",32)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityHover",32)
    SetMemoryPoolSize("EntityLight",200)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",32)
    SetMemoryPoolSize("MountedTurret",32)
    SetMemoryPoolSize("Navigator",128)
    SetMemoryPoolSize("Obstacle",1024)
    SetMemoryPoolSize("PathNode",1024)
    SetMemoryPoolSize("SoundSpaceRegion",64)
    SetMemoryPoolSize("TreeGridStack",1024)
    SetMemoryPoolSize("UnitAgent",128)
    SetMemoryPoolSize("UnitController",128)
    SetMemoryPoolSize("Weapon",1024)
    SetMemoryPoolSize("SoldierAnimation",1000)
    SetSpawnDelay(10,0.25)
    ReadDataFile("SHA\\SHA.lvl","SHA_eli")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    SetBleedingVoiceOver(1,1,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(1,2,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(2,1,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(2,2,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(1,1,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(1,2,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(2,2,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(2,1,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(1,1,"all_hot_amb_start",0,1)
    SetAmbientMusic(1,0.80000001192093,"all_hot_amb_middle",1,1)
    SetAmbientMusic(1,0.20000000298023,"all_hot_amb_end",2,1)
    SetAmbientMusic(2,1,"imp_hot_amb_start",0,1)
    SetAmbientMusic(2,0.80000001192093,"imp_hot_amb_middle",1,1)
    SetAmbientMusic(2,0.20000000298023,"imp_hot_amb_end",2,1)
    SetVictoryMusic(1,"all_hot_amb_victory")
    SetDefeatMusic(1,"all_hot_amb_defeat")
    SetVictoryMusic(2,"imp_hot_amb_victory")
    SetDefeatMusic(2,"imp_hot_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.73300802707672,-0.042259998619556,0.67777997255325,0.039076000452042,-0.302630007267,28.794353485107,75.827964782715)
    AddCameraShot(0.75283199548721,0.032205998897552,0.65682297945023,-0.028098000213504,80.700004577637,52.86413192749,7.2932300567627)
    AddCameraShot(0.73817300796509,-0.18660500645638,0.62851798534393,0.15888500213623,80.287796020508,56.51651763916,7.3138041496277)
    AddCameraShot(0.97721201181412,-0.18520499765873,0.10189999639988,0.019311999902129,68.38257598877,45.097171783447,-38.306804656982)
end

