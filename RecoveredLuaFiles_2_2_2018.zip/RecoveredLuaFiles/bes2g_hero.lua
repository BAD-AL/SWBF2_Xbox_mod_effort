--bes2g_hero.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("setup_teams")
ALL = 1
IMP = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    TDM = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, multiplayerScoreLimit = 100, textATT = "game.modes.tdm", textDEF = "game.modes.tdm2", multiplayerRules = true, isCelebrityDeathmatch = true })
    TDM:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMemoryPoolSize("Combo",30)
    SetMemoryPoolSize("Combo::State",500)
    SetMemoryPoolSize("Combo::Transition",500)
    SetMemoryPoolSize("Combo::Condition",500)
    SetMemoryPoolSize("Combo::Attack",400)
    SetMemoryPoolSize("Combo::DamageSample",4000)
    SetMemoryPoolSize("Combo::Deflect",88)
    ReadDataFile("sound\\chr.lvl;bossk")
    ReadDataFile("sound\\chr.lvl;cad_bane")
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\hero.lvl;herogcw")
    ReadDataFile("sound\\tat.lvl;tat2gcw")
    SetMapNorthAngle(180,1)
    SetMaxFlyHeight(-5)
    SetMaxPlayerFlyHeight(-5)
    AISnipeSuitabilityDist(30)
    ReadDataFile("SIDE\\all.lvl","all_hero_luke_jedi")
    ReadDataFile("SIDE\\imp.lvl","imp_hero_darthvader","imp_hero_emperor","imp_hero_bobafett")
    ReadDataFile("SIDE\\cis.lvl","cis_hero_grievous","cis_hero_darthmaul","cis_hero_jangofett")
    ReadDataFile("SIDE\\dlc.lvl","dlc_hero_fisto","dlc_hero_ventress")
    ReadDataFile("SIDE\\heroes.lvl","all_hero_hansolo_tat","rep_hero_anakin","rep_hero_luminara","rep_hero_obiwan","rep_hero_quigon","rep_inf_commander_cody","imp_hero_ig88","imp_hero_maw","all_hero_bespin_luke")
    ReadDataFile("SIDE\\rep.lvl","rep_hero_yoda","rep_hero_aalya","rep_hero_obiwan")
    SetupTeams({ 
        hero =         { team = ALL, units = 12, reinforcements = -1, 
          soldier =           { "all_hero_hansolo_tat", 1, 2 }, 
          assault =           { "rep_hero_luminara", 1, 2 }, 
          engineer =           { "all_hero_bespin_luke", 1, 2 }, 
          sniper =           { "rep_hero_obiwan", 1, 2 }, 
          officer =           { "rep_hero_yoda", 1, 2 }, 
          special =           { "rep_hero_quigon", 1, 2 }
         }
       })
    AddUnitClass(ALL,"rep_hero_aalya",1,2)
    AddUnitClass(ALL,"dlc_hero_fisto",1,2)
    AddUnitClass(ALL,"rep_inf_commander_cody",1,2)
    SetupTeams({ 
        villain =         { team = IMP, units = 12, reinforcements = -1, 
          soldier =           { "imp_hero_bobafett", 1, 2 }, 
          assault =           { "imp_hero_darthvader", 1, 2 }, 
          engineer =           { "cis_hero_darthmaul", 1, 2 }, 
          sniper =           { "cis_hero_jangofett", 1, 2 }, 
          officer =           { "cis_hero_grievous", 1, 2 }, 
          special =           { "imp_hero_maw", 1, 2 }
         }
       })
    AddUnitClass(IMP,"rep_hero_anakin",1,2)
    AddUnitClass(IMP,"dlc_hero_ventress",1,2)
    AddUnitClass(IMP,"imp_hero_ig88",1,2)
    ClearWalkers()
    SetMemoryPoolSize("AmmoCounter",96)
    SetMemoryPoolSize("EnergyBar",96)
    SetMemoryPoolSize("EntityLight",96)
    SetMemoryPoolSize("MountedTurret",13)
    SetMemoryPoolSize("PathFollower",50)
    SetMemoryPoolSize("Navigator",50)
    SetMemoryPoolSize("SoundSpaceRegion",38)
    SetMemoryPoolSize("TreeGridStack",256)
    SetMemoryPoolSize("Weapon",96)
    SetMemoryPoolSize("Aimer",1)
    SetMemoryPoolSize("AmmoCounter",96)
    SetMemoryPoolSize("BaseHint",320)
    SetMemoryPoolSize("ConnectivityGraphFollower",23)
    SetMemoryPoolSize("EnergyBar",96)
    SetMemoryPoolSize("EntityCloth",41)
    SetMemoryPoolSize("EntityDefenseGridTurret",0)
    SetMemoryPoolSize("EntityDroid",0)
    SetMemoryPoolSize("EntityPortableTurret",0)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",120)
    SetMemoryPoolSize("Navigator",23)
    SetMemoryPoolSize("Ordnance",80)
    SetMemoryPoolSize("ParticleEmitter",512)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("PathFollower",23)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("TentacleSimulator",24)
    SetMemoryPoolSize("UnitAgent",23)
    SetMemoryPoolSize("UnitController",23)
    SetMemoryPoolSize("Weapon",96)
    SetSpawnDelay(10,0.25)
    ReadDataFile("bes\\bes2.lvl","bespin2_Celeb")
    SetDenseEnvironment("True")
    AddDeathRegion("DeathRegion")
    AddDeathRegion("DeathRegion2")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","des_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\tat.lvl","tat2")
    OpenAudioStream("sound\\tat.lvl","tat2")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(ALL,1,"gen_amb_celebDeathmatch",0,1)
    SetAmbientMusic(IMP,1,"gen_amb_celebDeathmatch",0,1)
    SetVictoryMusic(ALL,"all_tat_amb_victory")
    SetDefeatMusic(ALL,"all_tat_amb_defeat")
    SetVictoryMusic(IMP,"imp_tat_amb_victory")
    SetDefeatMusic(IMP,"imp_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.87934798002243,-0.14204600453377,0.4486840069294,0.072477996349335,-38.413761138916,30.986400604248,195.87962341309)
    AddCameraShot(0.75514298677444,0.032623998820782,0.65413701534271,-0.028260000050068,-80.924102783203,-32.534858703613,59.805065155029)
    AddCameraShot(0.59651398658752,-0.068856000900269,-0.79437202215195,-0.091695003211498,-139.20362854004,-28.934867858887,56.316780090332)
    AddCameraShot(0.073601998388767,-0.011602000333369,-0.98505997657776,-0.15527200698853,-118.28823852539,-28.934867858887,125.93835449219)
    AddCameraShot(0.90268701314926,0.0012740000383928,0.43029499053955,-0.00060700002359226,-90.957382202148,-47.834819793701,180.83178710938)
    AddCameraShot(-0.4188149869442,-0.024035999551415,-0.9062619805336,0.052011001855135,-162.06648254395,-47.23482131958,80.504837036133)
    AddCameraShot(0.98835700750351,0.062969997525215,0.13822799921036,-0.0088069997727871,-173.7740020752,-55.334800720215,142.56781005859)
    AddCameraShot(-0.10055399686098,0.0081599997356534,-0.99163901805878,-0.080476000905037,-246.95443725586,-31.334861755371,153.43881225586)
    AddCameraShot(0.71716398000717,-0.018075000494719,0.69644898176193,0.017552999779582,-216.82719421387,-31.334861755371,186.86364746094)
    AddCameraShot(0.84485000371933,-0.049701999872923,0.53176999092102,0.031284000724554,-247.18145751953,-45.734825134277,29.732486724854)
    AddCameraShot(0.45488101243973,0.028302000835538,-0.88838398456573,0.055273000150919,-291.63665771484,-48.734817504883,21.009202957153)
    AddCameraShot(0.81832200288773,-0.026149999350309,-0.57387399673462,-0.0183390006423,-193.43464660645,-58.634792327881,-12.443043708801)
    AddCameraShot(0.4711090028286,0.0046910000964999,-0.88201802968979,0.0087829995900393,-192.2516784668,-61.334785461426,-32.647247314453)
end

