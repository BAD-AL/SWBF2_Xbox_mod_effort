--ed7g_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
local local_2 = 1
local local_3 = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "cp1" })
    cp2 = CommandPost:New({ name = "cp2" })
    cp3 = CommandPost:New({ name = "cp3" })
    cp4 = CommandPost:New({ name = "cp4" })
    cp5 = CommandPost:New({ name = "cp5" })
    cp6 = CommandPost:New({ name = "cp6" })
    conquest = ObjectiveConquest:New({ teamATT = local_2, teamDEF = local_3, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)
    conquest:Start()
    EnableSPHeroRules()
end
local local_0 = 2
local local_1 = 1

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(200)
    SetMaxPlayerFlyHeight(200)
    SetGroundFlyerMap(1)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\spa.lvl;spa1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_inf_officer","all_inf_wookiee")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper")
    ReadDataFile("SIDE\\swbf1.lvl","imp_fly_tiefighter","imp_fly_tiebomber","all_fly_xwing","all_fly_ywing")
    ReadDataFile("SIDE\\heroes.lvl","all_hero_dashrendar","imp_hero_greedo")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_laser")
    ReadDataFile("SIDE\\infantry.lvl","all_inf_specialops","imp_inf_commando")
    SetupTeams({ 
        all =         { team = local_0, units = 32, reinforcements = 150, 
          soldier =           { "all_inf_rifleman", 9, 25 }, 
          assault =           { "all_inf_rocketeer", 1, 4 }, 
          engineer =           { "all_inf_engineer", 1, 4 }, 
          sniper =           { "all_inf_sniper", 1, 4 }, 
          officer =           { "all_inf_officer", 1, 4 }, 
          special =           { "all_inf_wookiee", 1, 4 }
         }, 
        imp =         { team = local_1, units = 32, reinforcements = 150, 
          soldier =           { "imp_inf_rifleman", 9, 25 }, 
          assault =           { "imp_inf_rocketeer", 1, 4 }, 
          engineer =           { "imp_inf_engineer", 1, 4 }, 
          sniper =           { "imp_inf_sniper", 1, 4 }, 
          officer =           { "imp_inf_officer", 1, 4 }, 
          special =           { "imp_inf_dark_trooper", 1, 4 }
         }
       })
    AddUnitClass(local_0,"all_inf_specialops",1,2)
    AddUnitClass(local_1,"imp_inf_commando",1,2)
    SetHeroClass(local_0,"all_hero_dashrendar")
    SetHeroClass(local_1,"imp_hero_greedo")
    SetNumBirdTypes(2)
    SetBirdType(0,1,"bird")
    SetBirdType(1,1.5,"bird2")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    ClearWalkers()
    AddWalkerType(0,4)
    AddWalkerType(1,0)
    AddWalkerType(2,1)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",65)
    SetMemoryPoolSize("AmmoCounter",300)
    SetMemoryPoolSize("BaseHint",220)
    SetMemoryPoolSize("EnergyBar",300)
    SetMemoryPoolSize("EntityCloth",58)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntityHover",13)
    SetMemoryPoolSize("EntityLight",60)
    SetMemoryPoolSize("EntitySoundStream",3)
    SetMemoryPoolSize("EntitySoundStatic",111)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",87)
    SetMemoryPoolSize("MountedTurret",18)
    SetMemoryPoolSize("Navigator",58)
    SetMemoryPoolSize("Obstacle",300)
    SetMemoryPoolSize("PathFollower",58)
    SetMemoryPoolSize("PathNode",256)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("TentacleSimulator",12)
    SetMemoryPoolSize("TreeGridStack",275)
    SetMemoryPoolSize("Weapon",300)
    SetSpawnDelay(10,0.25)
    ReadDataFile("ED7\\ED7.lvl","ED7_conquest")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\spa.lvl","spa")
    OpenAudioStream("sound\\spa.lvl","spa")
    SetBleedingVoiceOver(local_0,local_0,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(local_0,local_1,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_0,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_1,"imp_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(local_0,1,"all_spa_amb_start",0,1)
    SetAmbientMusic(local_0,0.80000001192093,"all_spa_amb_middle",1,1)
    SetAmbientMusic(local_0,0.20000000298023,"all_spa_amb_end",2,1)
    SetAmbientMusic(local_1,1,"imp_spa_amb_start",0,1)
    SetAmbientMusic(local_1,0.80000001192093,"imp_spa_amb_middle",1,1)
    SetAmbientMusic(local_1,0.20000000298023,"imp_spa_amb_end",2,1)
    SetVictoryMusic(local_0,"all_spa_amb_victory")
    SetDefeatMusic(local_0,"all_spa_amb_defeat")
    SetVictoryMusic(local_1,"imp_spa_amb_victory")
    SetDefeatMusic(local_1,"imp_spa_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.87113898992538,0.047056999057531,-0.48806500434875,0.02636400051415,254.6488494873,46.490013122559,-112.64440155029)
    AddCameraShot(-0.42447900772095,-0.021712999790907,-0.90399599075317,0.046241998672485,-345.75158691406,29.577821731567,-185.22410583496)
    AddCameraShot(-0.28469800949097,-0.026691000908613,-0.95406198501587,0.089445002377033,29.068208694458,5.0240759849548,115.10986328125)
    AddCameraShot(0.77734798192978,0.059085998684168,-0.62448799610138,0.04746700078249,143.17353820801,13.492456436157,5.9867420196533)
    AddCameraShot(0.92422300577164,-0.013925000093877,0.38155600428581,0.0057489997707307,116.36988067627,37.454612731934,-170.91055297852)
    AddCameraShot(0.6676179766655,0.11011199653149,0.72650098800659,-0.11982399970293,31.222745895386,14.073572158813,-103.91887664795)
end

