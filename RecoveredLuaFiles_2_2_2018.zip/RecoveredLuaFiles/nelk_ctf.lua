--nelk_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
local local_0 = 2
local local_1 = 1

function ScriptPostLoad()
    SoundEvent_SetupTeams(local_0,"all",local_1,"imp")
    SetProperty("flag1","GeometryName","com_icon_republic_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_republic_flag_carried")
    SetProperty("flag2","GeometryName","com_icon_cis_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_cis_flag_carried")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = REP, teamDEF = CIS, captureLimit = 5, textATT = "game.modes.ctf", textDEF = "game.modes.ctf2", multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "team1_capture", captureRegion = "team2_capture", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "team2_capture", captureRegion = "team1_capture", capRegionMarker = "hud_objective_icon_circle", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(150)
    SetMaxPlayerFlyHeight(150)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\tat.lvl;tat2gcw")
    ReadDataFile("SIDE\\rep.lvl","rep_hero_obiwan","rep_hero_kiyadimundi")
    ReadDataFile("SIDE\\kotor.lvl","kor_hero_carth","kor_hero_nihilus","rvs_inf_rbasic","rvs_inf_sbasic","rvs_inf_rheavy","rvs_inf_sheavy","rvs_inf_rsupport","rvs_inf_ssupport","rvs_inf_rstealth","rvs_inf_sstealth","rvs_inf_sadept","rvs_inf_radept","rvs_inf_rofficer","rvs_inf_sofficer","rvs_inf_rdroid","rvs_inf_sdroid")
    SetupTeams({ 
        rep =         { team = local_0, units = 20, reinforcements = 150, 
          soldier =           { "rvs_inf_rbasic", 7, 24 }, 
          assault =           { "rvs_inf_rheavy", 2, 8 }, 
          engineer =           { "rvs_inf_rdroid", 2, 8 }, 
          sniper =           { "rvs_inf_rsupport", 2, 8 }, 
          officer =           { "rvs_inf_rofficer", 2, 8 }, 
          special =           { "rvs_inf_rstealth", 1, 4 }
         }, 
        imp =         { team = local_1, units = 20, reinforcements = 150, 
          soldier =           { "rvs_inf_sbasic", 7, 24 }, 
          assault =           { "rvs_inf_sheavy", 2, 8 }, 
          engineer =           { "rvs_inf_sdroid", 2, 8 }, 
          sniper =           { "rvs_inf_ssupport", 2, 8 }, 
          officer =           { "rvs_inf_sofficer", 2, 8 }, 
          special =           { "rvs_inf_sstealth", 1, 4 }
         }
       })
    AddUnitClass(local_0,"rvs_inf_radept",1,2)
    AddUnitClass(local_1,"rvs_inf_sadept",1,2)
    SetHeroClass(local_0,"kor_hero_carth")
    SetHeroClass(local_1,"kor_hero_nihilus")
    ClearWalkers()
    AddWalkerType(2,2)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("AmmoCounter",1024)
    SetMemoryPoolSize("BaseHint",1024)
    SetMemoryPoolSize("EnergyBar",1024)
    SetMemoryPoolSize("EntityCloth",32)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityHover",32)
    SetMemoryPoolSize("EntityLight",200)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",32)
    SetMemoryPoolSize("MountedTurret",32)
    SetMemoryPoolSize("Navigator",128)
    SetMemoryPoolSize("Obstacle",1024)
    SetMemoryPoolSize("PathNode",1024)
    SetMemoryPoolSize("SoldierAnimation",512)
    SetMemoryPoolSize("SoundSpaceRegion",64)
    SetMemoryPoolSize("TreeGridStack",1024)
    SetMemoryPoolSize("UnitAgent",128)
    SetMemoryPoolSize("UnitController",128)
    SetMemoryPoolSize("Weapon",1024)
    SetMemoryPoolSize("FlagItem",2)
    SetSpawnDelay(10,0.25)
    ReadDataFile("NEL\\NEL.lvl","NEL_ctf")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","des_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\tat.lvl","tat2")
    OpenAudioStream("sound\\tat.lvl","tat2")
    OpenAudioStream("dc:sound\\nel.lvl","nel")
    OpenAudioStream("dc:sound\\nel.lvl","nel")
    SetBleedingVoiceOver(local_0,local_0,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(local_0,local_1,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_0,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_1,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(local_0,local_0,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_0,local_1,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_1,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_0,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(local_0,1,"all_tat_amb_start",0,1)
    SetAmbientMusic(local_0,0.89999997615814,"all_tat_amb_middle",1,1)
    SetAmbientMusic(local_0,0.10000000149012,"all_tat_amb_end",2,1)
    SetAmbientMusic(local_1,1,"imp_tat_amb_start",0,1)
    SetAmbientMusic(local_1,0.89999997615814,"imp_tat_amb_middle",1,1)
    SetAmbientMusic(local_1,0.10000000149012,"imp_tat_amb_end",2,1)
    SetVictoryMusic(local_0,"all_tat_amb_victory")
    SetDefeatMusic(local_0,"all_tat_amb_defeat")
    SetVictoryMusic(local_1,"imp_tat_amb_victory")
    SetDefeatMusic(local_1,"imp_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.70252799987793,-0.18260499835014,0.66570901870728,0.1730349957943,88.019607543945,119.32252502441,6.2259159088135)
    AddCameraShot(0.94283199310303,-0.22129499912262,-0.24260100722313,-0.056940998882055,-60.964904785156,108.96562194824,81.692283630371)
    AddCameraShot(0.92140698432922,-0.097567997872829,-0.37406000494957,-0.039609000086784,-112.23388671875,108.96562194824,136.24380493164)
    AddCameraShot(0.96467399597168,-0.2520309984684,-0.07422199845314,-0.019391000270844,-2.3616919517517,103.43183898926,33.009258270264)
    AddCameraShot(0.65242999792099,-0.069912001490593,-0.75032198429108,-0.080401003360748,-117.73081970215,103.43183898926,11.439115524292)
    AddCameraShot(-0.23905900120735,0.018079999834299,-0.96807199716568,-0.073216997087002,31.372383117676,110.72171783447,69.614196777344)
    AddCameraShot(0.41184198856354,0.029211999848485,-0.90850400924683,0.064438998699188,-11.281128883362,86.811317443848,-29.294544219971)
    AddCameraShot(0.73310297727585,-0.28167900443077,-0.57785797119141,-0.22202999889851,-50.071311950684,107.50148010254,81.472244262695)
    AddDeathRegion("deathregion")
end

