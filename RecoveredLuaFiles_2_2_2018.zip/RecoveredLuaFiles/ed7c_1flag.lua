--ed7c_1flag.lua
-- Decompiled with SWBF2CodeHelper
Conquest = ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = REP
DEF = CIS

function ScriptPostLoad()
    SoundEvent_SetupTeams(REP,"rep",CIS,"cis")
    ctf = ObjectiveOneFlagCTF:New({ teamATT = REP, teamDEF = CIS, textATT = "game.modes.1flag", textDEF = "game.modes.1flag2", captureLimit = 5, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "homeregion", captureRegionATT = "team1_capture", captureRegionDEF = "team2_capture", capRegionMarkerATT = "hud_objective_icon_circle", capRegionMarkerDEF = "hud_objective_icon_circle", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3, multiplayerRules = true })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(200)
    SetMaxPlayerFlyHeight(200)
    SetGroundFlyerMap(1)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\spa.lvl;spa2cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep2_rocketeer","rep_inf_ep2_rifleman","rep_inf_ep2_jettrooper","rep_inf_ep2_sniper","rep_inf_ep2_pilot")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_pilot","cis_inf_sniper","cis_inf_officer","cis_inf_droideka")
    ReadDataFile("SIDE\\vehicles.lvl","rep_fly_arc170fighter","rep_fly_vwing","cis_fly_droidfighter","cis_fly_greviousfighter")
    ReadDataFile("SIDE\\heroes.lvl","cis_hero_Cad_Bane","rep_hero_quigon")
    ReadDataFile("SIDE\\all.lvl","all_hero_luke_jedi")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_ep2_officer","rep_inf_commando","cis_inf_commando")
    SetupTeams({ 
        rep =         { team = REP, units = 30, reinforcements = 150, 
          soldier =           { "rep_inf_ep2_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep2_rocketeer", 1, 4 }, 
          pilot =           { "rep_inf_ep2_pilot", 1, 4 }, 
          sniper =           { "rep_inf_ep2_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep2_officer", 1, 4 }, 
          special =           { "rep_inf_ep2_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 30, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          pilot =           { "cis_inf_pilot", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          officer =           { "cis_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    AddUnitClass(REP,"rep_inf_commando",1,2)
    AddUnitClass(CIS,"cis_inf_commando",1,2)
    SetHeroClass(REP,"rep_hero_quigon")
    SetHeroClass(CIS,"cis_hero_Cad_Bane")
    SetNumBirdTypes(2)
    SetBirdType(0,1,"bird")
    SetBirdType(1,1.5,"bird2")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    AddWalkerType(0,4)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("AmmoCounter",1024)
    SetMemoryPoolSize("BaseHint",1024)
    SetMemoryPoolSize("EnergyBar",1024)
    SetMemoryPoolSize("EntityCloth",32)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityHover",32)
    SetMemoryPoolSize("EntityLight",200)
    SetMemoryPoolSize("EntitySoundStream",10)
    SetMemoryPoolSize("EntitySoundStatic",32)
    SetMemoryPoolSize("MountedTurret",32)
    SetMemoryPoolSize("Navigator",128)
    SetMemoryPoolSize("Obstacle",1024)
    SetMemoryPoolSize("PathNode",1024)
    SetMemoryPoolSize("SoldierAnimation",400)
    SetMemoryPoolSize("SoundSpaceRegion",64)
    SetMemoryPoolSize("TreeGridStack",1024)
    SetMemoryPoolSize("UnitAgent",128)
    SetMemoryPoolSize("UnitController",128)
    SetMemoryPoolSize("Weapon",1024)
    SetMemoryPoolSize("FlagItem",1)
    SetSpawnDelay(10,0.25)
    ReadDataFile("ED7\\ED7.lvl","ED7_1flag")
    SetDenseEnvironment("false")
    OpenAudioStream("sound\\global.lvl","spa1_objective_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","rep_unit_vo_slow",OpenAudioStream())
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",OpenAudioStream())
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",OpenAudioStream())
    OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",OpenAudioStream())
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\spa.lvl","spa")
    OpenAudioStream("sound\\spa.lvl","spa")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(REP,REP,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(REP,CIS,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,CIS,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,REP,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(REP,"Repleaving")
    SetOutOfBoundsVoiceOver(CIS,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_spa_amb_start",0,1)
    SetAmbientMusic(REP,0.99000000953674,"rep_spa_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_spa_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_spa_amb_start",0,1)
    SetAmbientMusic(CIS,0.99000000953674,"cis_spa_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_spa_amb_end",2,1)
    SetVictoryMusic(REP,"rep_spa_amb_victory")
    SetDefeatMusic(REP,"rep_spa_amb_defeat")
    SetVictoryMusic(CIS,"cis_spa_amb_victory")
    SetDefeatMusic(CIS,"cis_spa_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.87113898992538,0.047056999057531,-0.48806500434875,0.02636400051415,254.6488494873,46.490013122559,-112.64440155029)
    AddCameraShot(-0.42447900772095,-0.021712999790907,-0.90399599075317,0.046241998672485,-345.75158691406,29.577821731567,-185.22410583496)
    AddCameraShot(-0.28469800949097,-0.026691000908613,-0.95406198501587,0.089445002377033,29.068208694458,5.0240759849548,115.10986328125)
    AddCameraShot(0.77734798192978,0.059085998684168,-0.62448799610138,0.04746700078249,143.17353820801,13.492456436157,5.9867420196533)
    AddCameraShot(0.92422300577164,-0.013925000093877,0.38155600428581,0.0057489997707307,116.36988067627,37.454612731934,-170.91055297852)
    AddCameraShot(0.6676179766655,0.11011199653149,0.72650098800659,-0.11982399970293,31.222745895386,14.073572158813,-103.91887664795)
end

