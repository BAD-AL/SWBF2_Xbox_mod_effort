--hot1g_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ALL = 2
IMP = 1
ATT = 1
DEF = 2

function ScriptPostLoad()
    SoundEvent_SetupTeams(IMP,"imp",ALL,"all")
    AddDeathRegion("fall")
    EnableSPHeroRules()
    KillObject("CP7OBJ")
    KillObject("shieldgen")
    KillObject("CP7OBJ")
    KillObject("hangarcp")
    KillObject("enemyspawn")
    KillObject("enemyspawn2")
    KillObject("echoback2")
    KillObject("echoback1")
    KillObject("shield")
    DisableBarriers("conquestbar")
    DisableBarriers("bombbar")
    SetProperty("ship","MaxHealth",9.9999999338158e+036)
    SetProperty("ship","CurHealth",9.9999999338158e+036)
    SetProperty("ship2","MaxHealth",9.9999999338158e+036)
    SetProperty("ship2","CurHealth",9.9999999338158e+036)
    SetProperty("ship3","MaxHealth",9.9999999338158e+036)
    SetProperty("ship3","CurHealth",9.9999999338158e+036)
    ctf = ObjectiveOneFlagCTF:New({ teamATT = 1, teamDEF = 2, textATT = "game.modes.1flag", textDEF = "game.modes.1flag2", hideCPs = true, multiplayerRules = true, captureLimit = 5, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "HomeRegion", captureRegionATT = "Team2Capture", captureRegionDEF = "Team1Capture", capRegionMarkerATT = "hud_objective_icon_circle", capRegionMarkerDEF = "hud_objective_icon_circle", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3 })
    ctf:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4000000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(70)
    SetMaxPlayerFlyHeight(70)
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\hot.lvl;hot1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_snow","all_inf_rocketeer_snow","all_inf_engineer_snow","all_inf_sniper_snow","all_inf_officer_snow","all_hero_luke_pilot","all_inf_wookiee_snow")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman_snow","imp_inf_rocketeer_snow","imp_inf_sniper_snow","imp_inf_dark_trooper","imp_inf_engineer_snow","imp_inf_officer","imp_hero_darthvader")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_hoth_dishturret","tur_bldg_hoth_lasermortar","tur_bldg_chaingun_tripod","tur_bldg_chaingun_roof")
    ReadDataFile("SIDE\\infantry.lvl","all_inf_specialops","imp_inf_commando")
    SetupTeams({ 
        all =         { team = ALL, units = 32, reinforcements = -1, 
          soldier =           { "all_inf_rifleman_snow", 9, 25 }, 
          assault =           { "all_inf_rocketeer_snow", 1, 4 }, 
          engineer =           { "all_inf_engineer_snow", 1, 4 }, 
          sniper =           { "all_inf_sniper_snow", 1, 4 }, 
          officer =           { "all_inf_officer_snow", 1, 4 }, 
          special =           { "all_inf_wookiee_snow", 1, 4 }
         }, 
        imp =         { team = IMP, units = 32, reinforcements = -1, 
          soldier =           { "imp_inf_rifleman_snow", 9, 25 }, 
          assault =           { "imp_inf_rocketeer_snow", 1, 4 }, 
          engineer =           { "imp_inf_engineer_snow", 1, 4 }, 
          sniper =           { "imp_inf_sniper_snow", 1, 4 }, 
          officer =           { "imp_inf_officer", 1, 4 }, 
          special =           { "imp_inf_dark_trooper", 1, 4 }
         }
       })
    AddUnitClass(ALL,"all_inf_specialops",1,2)
    AddUnitClass(IMP,"imp_inf_commando",1,2)
    SetHeroClass(IMP,"imp_hero_darthvader")
    SetHeroClass(ALL,"all_hero_luke_pilot")
    ClearWalkers()
    SetMemoryPoolSize("EntityWalker",0)
    AddWalkerType(0,0)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    SetMemoryPoolSize("Aimer",50)
    SetMemoryPoolSize("AmmoCounter",260)
    SetMemoryPoolSize("BaseHint",300)
    SetMemoryPoolSize("EnergyBar",260)
    SetMemoryPoolSize("EntityCloth",44)
    SetMemoryPoolSize("EntityLight",240)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntitySoundStream",5)
    SetMemoryPoolSize("EntitySoundStatic",13)
    SetMemoryPoolSize("FlagItem",1)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",90)
    SetMemoryPoolSize("MountedTurret",50)
    SetMemoryPoolSize("Navigator",40)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("OrdnanceTowCable",40)
    SetMemoryPoolSize("PathNode",180)
    SetMemoryPoolSize("RedOmniLight",250)
    SetMemoryPoolSize("TreeGridStack",350)
    SetMemoryPoolSize("UnitAgent",46)
    SetMemoryPoolSize("UnitController",46)
    SetMemoryPoolSize("Weapon",260)
    ReadDataFile("HOT\\hot1.lvl","hoth_ctf")
    SetSpawnDelay(15,0.25)
    SetDenseEnvironment("false")
    SetDefenderSnipeRange(170)
    AddDeathRegion("Death")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(ALL,1,"all_hot_amb_start",0,1)
    SetAmbientMusic(ALL,0.5,"all_hot_amb_middle",1,1)
    SetAmbientMusic(ALL,0.25,"all_hot_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_hot_amb_start",0,1)
    SetAmbientMusic(IMP,0.5,"imp_hot_amb_middle",1,1)
    SetAmbientMusic(IMP,0.25,"imp_hot_amb_end",2,1)
    SetVictoryMusic(ALL,"all_hot_amb_victory")
    SetDefeatMusic(ALL,"all_hot_amb_defeat")
    SetVictoryMusic(IMP,"imp_hot_amb_victory")
    SetDefeatMusic(IMP,"imp_hot_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.94420999288559,0.065540999174118,0.3219830095768,-0.022350000217557,-500.48983764648,0.79747200012207,-68.773849487305)
    AddCameraShot(0.37119698524475,0.0081900004297495,-0.92829197645187,0.020481999963522,-473.38415527344,-17.880533218384,132.12680053711)
    AddCameraShot(0.92708301544189,0.020455999299884,-0.37420600652695,0.0082569997757673,-333.22155761719,0.67604297399521,-14.027347564697)
end

