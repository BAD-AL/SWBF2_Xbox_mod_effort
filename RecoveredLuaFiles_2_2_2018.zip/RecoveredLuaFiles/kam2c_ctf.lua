--kam2c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
ATT = 1
DEF = 2
CIS = DEF
REP = ATT

function ScriptPostLoad()
    SetProperty("ctf_flag1","GeometryName","com_icon_cis_flag")
    SetProperty("ctf_flag1","CarriedGeometryName","com_icon_cis_flag_carried")
    SetProperty("ctf_flag2","GeometryName","com_icon_republic_flag")
    SetProperty("ctf_flag2","CarriedGeometryName","com_icon_republic_flag_carried")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 5, textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", multiplayerRules = true, hideCPs = true })
    ctf:AddFlag({ name = "ctf_flag1", homeRegion = "flag1_home", captureRegion = "flag2_home" })
    ctf:AddFlag({ name = "ctf_flag2", homeRegion = "flag2_home", captureRegion = "flag1_home" })
    SoundEvent_SetupTeams(1,"rep",2,"cis")
    ctf:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\kam.lvl;kam1cw")
    SetMinFlyHeight(60)
    SetAllowBlindJetJumps(0)
    SetMaxFlyHeight(102)
    SetMaxPlayerFlyHeight(102)
    SetAllowBlindJetJumps(0)
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_jettrooper","rep_inf_ep3_officer")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_droideka","cis_inf_officer")
    ReadDataFile("SIDE\\all.lvl","all_hero_luke_jedi")
    ReadDataFile("SIDE\\heroes.lvl","rep_hero_quigon","cis_hero_durge")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_commando","cis_inf_commando")
    SetupTeams({ 
        REP =         { team = REP, units = 32, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep3_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 1, 4 }, 
          sniper =           { "rep_inf_ep3_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep3_officer", 1, 4 }, 
          special =           { "rep_inf_ep3_jettrooper", 1, 4 }
         }, 
        CIS =         { team = CIS, units = 32, reinforcements = -1, 
          soldier =           { "CIS_inf_rifleman", 9, 25 }, 
          assault =           { "CIS_inf_rocketeer", 1, 4 }, 
          engineer =           { "CIS_inf_engineer", 1, 4 }, 
          sniper =           { "CIS_inf_sniper", 1, 4 }, 
          officer =           { "CIS_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    AddUnitClass(REP,"rep_inf_commando",1,2)
    AddUnitClass(CIS,"cis_inf_commando",1,2)
    SetHeroClass(REP,"rep_hero_quigon")
    SetHeroClass(CIS,"cis_hero_durge")
    ClearWalkers()
    AddWalkerType(0,3)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",30)
    SetMemoryPoolSize("AmmoCounter",230)
    SetMemoryPoolSize("BaseHint",325)
    SetMemoryPoolSize("EnergyBar",230)
    SetMemoryPoolSize("EntityCloth",20)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntitySoundStream",2)
    SetMemoryPoolSize("EntitySoundStatic",43)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("MountedTurret",20)
    SetMemoryPoolSize("Navigator",50)
    SetMemoryPoolSize("Obstacle",664)
    SetMemoryPoolSize("PathFollower",50)
    SetMemoryPoolSize("PathNode",256)
    SetMemoryPoolSize("TentacleSimulator",0)
    SetMemoryPoolSize("TreeGridStack",325)
    SetMemoryPoolSize("Weapon",230)
    SetSpawnDelay(10,0.25)
    ReadDataFile("KAM\\kam2.lvl","kamino1_ctf")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\kam.lvl","kam1")
    OpenAudioStream("sound\\kam.lvl","kam1")
    SetAmbientMusic(REP,1,"rep_kam_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_kam_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_kam_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_kam_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_kam_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_kam_amb_end",2,1)
    SetVictoryMusic(REP,"rep_kam_amb_victory")
    SetDefeatMusic(REP,"rep_kam_amb_defeat")
    SetVictoryMusic(CIS,"cis_kam_amb_victory")
    SetDefeatMusic(CIS,"cis_kam_amb_defeat")
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddDeathRegion("deathregion")
    AddCameraShot(0.19047799706459,-0.010944999754429,-0.98001402616501,-0.056311998516321,-26.091287612915,55.96501159668,159.45809936523)
    AddCameraShot(-0.37657099962234,-0.019636999815702,-0.92492300271988,0.04823200032115,176.04246520996,53.957565307617,244.26113891602)
    AddCameraShot(0.63925397396088,-0.073532998561859,0.76045697927475,0.087475001811981,78.395347595215,72.538581848145,344.08660888672)
end

