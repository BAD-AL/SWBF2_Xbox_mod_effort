--pol1c_ctf.lua
-- Decompiled with SWBF2CodeHelper
CTF = ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")

function ScriptPostLoad()
    SoundEvent_SetupTeams(REP,"rep",CIS,"cis")
    SetProperty("com_item_vehicle_spawn","SpawnCount",1)
    SetProperty("com_item_vehicle_spawn1","SpawnCount",0)
    SetProperty("com_item_vehicle_spawn2","SpawnCount",0)
    SetProperty("flag1","GeometryName","com_icon_cis_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_cis_flag_carried")
    SetProperty("flag2","GeometryName","com_icon_republic_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_republic_flag_carried")
    SetClassProperty("com_item_flag_carried","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "Team1FlagCapture", captureRegion = "Team2FlagCapture" })
    ctf:AddFlag({ name = "flag2", homeRegion = "Team2FlagCapture", captureRegion = "Team1FlagCapture" })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    StealArtistHeap(550 * 1024)
    SetPS2ModelMemory(4130000)
    ReadDataFile("ingame.lvl")
    ATT = 1
    DEF = 2
    CIS = ATT
    REP = DEF
    SetMapNorthAngle(0)
    SetMaxFlyHeight(55)
    SetMaxPlayerFlyHeight(55)
    AISnipeSuitabilityDist(30)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\pol.lvl;pol1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_jettrooper","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_hero_yoda")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_hero_darthmaul","cis_inf_droideka","cis_hover_aat")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_laser")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_commando","cis_inf_commando")
    SetupTeams({ 
        rep =         { team = REP, units = 32, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep3_rocketeer", 1, 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 1, 4 }, 
          sniper =           { "rep_inf_ep3_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep3_officer", 1, 4 }, 
          special =           { "rep_inf_ep3_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 32, reinforcements = -1, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          engineer =           { "cis_inf_engineer", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          officer =           { "cis_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    AddUnitClass(REP,"rep_inf_commando",1,2)
    AddUnitClass(CIS,"cis_inf_commando",1,2)
    SetHeroClass(CIS,"cis_hero_darthmaul")
    SetHeroClass(REP,"rep_hero_yoda")
    ClearWalkers()
    AddWalkerType(0,3)
    SetMemoryPoolSize("Aimer",30)
    SetMemoryPoolSize("AmmoCounter",200)
    SetMemoryPoolSize("BaseHint",250)
    SetMemoryPoolSize("EnergyBar",200)
    SetMemoryPoolSize("EntityHover",1)
    SetMemoryPoolSize("EntityLight",63)
    SetMemoryPoolSize("EntitySoundStream",25)
    SetMemoryPoolSize("EntitySoundStatic",10)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("MountedTurret",3)
    SetMemoryPoolSize("Navigator",50)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("PathFollower",50)
    SetMemoryPoolSize("PathNode",200)
    SetMemoryPoolSize("SoundSpaceRegion",34)
    SetMemoryPoolSize("TentacleSimulator",0)
    SetMemoryPoolSize("TreeGridStack",180)
    SetMemoryPoolSize("UnitAgent",50)
    SetMemoryPoolSize("UnitController",50)
    SetMemoryPoolSize("Weapon",200)
    SetMemoryPoolSize("EntityFlyer",4)
    SetMemoryPoolSize("Asteroid",100)
    SetSpawnDelay(10,0.25)
    ReadDataFile("pol\\pol1.lvl","pol1_ctf")
    SetDenseEnvironment("True")
    AddDeathRegion("deathregion1")
    SetParticleLODBias(3000)
    SetMaxCollisionDistance(1500)
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\pol.lvl","pol1")
    OpenAudioStream("sound\\pol.lvl","pol1")
    SetOutOfBoundsVoiceOver(1,"cisleaving")
    SetOutOfBoundsVoiceOver(2,"repleaving")
    SetAmbientMusic(REP,1,"rep_pol_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_pol_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_pol_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_pol_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_pol_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_pol_amb_end",2,1)
    SetVictoryMusic(REP,"rep_pol_amb_victory")
    SetDefeatMusic(REP,"rep_pol_amb_defeat")
    SetVictoryMusic(CIS,"cis_pol_amb_victory")
    SetDefeatMusic(CIS,"cis_pol_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.46118900179863,-0.077838003635406,-0.87155497074127,-0.14709800481796,85.974006652832,30.694353103638,-66.90079498291)
    AddCameraShot(0.99494600296021,-0.1003800034523,-0.0022980000358075,-0.00023200000578072,109.07640075684,27.636383056641,-10.23578453064)
    AddCameraShot(0.76038300991058,0.046401999890804,0.64661198854446,-0.039459001272917,111.26169586182,27.636383056641,46.468048095703)
    AddCameraShot(-0.25494900345802,0.066384002566338,-0.93354600667953,-0.24307799339294,73.647552490234,32.764030456543,50.283027648926)
    AddCameraShot(-0.33190101385117,0.016248000785708,-0.94204598665237,-0.04611599817872,111.00356292725,28.975282669067,7.0514578819275)
    AddCameraShot(0.29545199871063,-0.038139998912811,-0.94673997163773,-0.12221699953079,19.85668182373,36.399085998535,-9.8903608322144)
    AddCameraShot(0.9580500125885,-0.11583700031042,-0.26025399565697,-0.031466998159885,-35.103736877441,37.551651000977,109.46657562256)
    AddCameraShot(-0.37248799204826,0.036892000585794,-0.92278897762299,-0.091393999755383,-77.487892150879,37.551651000977,40.861831665039)
    AddCameraShot(0.71714401245117,-0.084844999015331,-0.68695002794266,-0.08127299696207,-106.04769134521,36.238494873047,60.770439147949)
    AddCameraShot(0.45295798778534,-0.1047480031848,-0.86259198188782,-0.19947800040245,-110.55347442627,40.972583770752,37.320777893066)
    AddCameraShot(-0.009243999607861,0.0016189999878407,-0.98495602607727,-0.17254999279976,-57.010257720947,30.395561218262,5.6382508277893)
    AddCameraShot(0.42695799469948,-0.040550000965595,-0.89931499958038,-0.085412003099918,-87.005966186523,30.395561218262,19.625087738037)
    AddCameraShot(0.15363200008869,-0.041448000818491,-0.95317900180817,-0.25715601444244,-111.95505523682,36.058708190918,-23.915500640869)
    AddCameraShot(0.2727510035038,-0.0020550000481308,-0.96205502748489,-0.0072470000013709,-117.45273590088,17.298250198364,-58.572723388672)
    AddCameraShot(0.53709697723389,-0.057966001331806,-0.83666801452637,-0.090296998620033,-126.74666595459,30.472835540771,-148.35333251953)
    AddCameraShot(-0.44218799471855,0.081142000854015,-0.87857502698898,-0.16121999919415,-85.660972595215,29.013374328613,-144.10221862793)
    AddCameraShot(-0.065408997237682,0.011040000244975,-0.98388302326202,-0.16605600714684,-84.789031982422,29.013374328613,-139.56878662109)
    AddCameraShot(0.43090599775314,-0.034722998738289,-0.89881497621536,-0.072428002953529,-98.03800201416,47.662624359131,-128.64326477051)
    AddCameraShot(-0.40146198868752,0.047049999237061,-0.9084489941597,-0.10646600276232,77.586563110352,47.662624359131,-147.51736450195)
    AddCameraShot(-0.26950299739838,0.031284000724554,-0.95607101917267,-0.11098299920559,111.2603302002,16.927541732788,-114.04571533203)
    AddCameraShot(-0.33811900019646,0.041636001318693,-0.93313401937485,-0.11490599811077,134.97016906738,26.441255569458,-82.282081604004)
end

