--rhn1g_hunt.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("setup_teams")
ALL = 1
IMP = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    hunt = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, pointsPerKillATT = 3, pointsPerKillDEF = 1, textATT = "game.modes.hunt", textDEF = "game.modes.hunt2", multiplayerRules = true })
    hunt:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(30)
    SetMaxPlayerFlyHeight(30)
    ReadDataFile("sound\\hot.lvl;hot1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_snow","all_inf_rocketeer_snow","all_inf_engineer_snow","all_inf_sniper_snow","all_inf_officer_snow","all_inf_wookiee_snow")
    ReadDataFile("SIDE\\snw.lvl","snw_inf_wampa")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_laser")
    SetupTeams({ 
        all =         { team = ALL, units = 20, reinforcements = -1, 
          soldier =           { "all_inf_rifleman_snow" }, 
          assault =           { "all_inf_rocketeer_snow" }, 
          engineer =           { "all_inf_engineer_snow" }, 
          sniper =           { "all_inf_sniper_snow" }, 
          officer =           { "all_inf_officer_snow" }, 
          special =           { "all_inf_wookiee_snow" }
         }, 
        wampa =         { team = IMP, units = 8, reinforcements = -1, 
          soldier =           { "snw_inf_wampa", 8 }
         }
       })
    ClearWalkers()
    SetMemoryPoolSize("Aimer",90)
    SetMemoryPoolSize("AmmoCounter",269)
    SetMemoryPoolSize("BaseHint",250)
    SetMemoryPoolSize("CommandWalker",2)
    SetMemoryPoolSize("ConnectivityGraphFollower",56)
    SetMemoryPoolSize("EnergyBar",269)
    SetMemoryPoolSize("EntityCloth",28)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntityLight",225)
    SetMemoryPoolSize("EntitySoundStatic",16)
    SetMemoryPoolSize("EntitySoundStream",5)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",54)
    SetMemoryPoolSize("MountedTurret",46)
    SetMemoryPoolSize("Navigator",63)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("PathFollower",63)
    SetMemoryPoolSize("PathNode",268)
    SetMemoryPoolSize("RedOmniLight",240)
    SetMemoryPoolSize("TreeGridStack",329)
    SetMemoryPoolSize("UnitController",63)
    SetMemoryPoolSize("UnitAgent",63)
    SetMemoryPoolSize("Weapon",269)
    ReadDataFile("RHN\\RHN1.lvl","RhenVar1_Hunt")
    SetSpawnDelay(10,0.25)
    SetDenseEnvironment("true")
    SetDefenderSnipeRange(170)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetAmbientMusic(ALL,1,"all_hot_amb_hunt",0,1)
    SetAmbientMusic(IMP,1,"imp_hot_amb_hunt",0,1)
    SetVictoryMusic(ALL,"all_hot_amb_victory")
    SetDefeatMusic(ALL,"all_hot_amb_defeat")
    SetVictoryMusic(IMP,"imp_hot_amb_victory")
    SetDefeatMusic(IMP,"imp_hot_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.87690001726151,-0.44279399514198,0.16696099936962,0.084307998418808,-92.842826843262,91.021690368652,161.35585021973)
    AddCameraShot(0.93181598186493,-0.18120600283146,-0.30867800116539,-0.060026999562979,-147.39654541016,25.021837234497,128.23318481445)
    AddCameraShot(0.90984201431274,-0.26207301020622,0.30915600061417,0.089050002396107,-91.736038208008,34.621788024902,163.73963928223)
    AddCameraShot(0.81341201066971,-0.19374799728394,-0.53354901075363,-0.12708699703217,-70.256042480469,25.6217918396,115.02828979492)
    AddCameraShot(0.96838802099228,-0.1817380040884,-0.16796100139618,-0.031520999968052,-27.984699249268,17.221786499023,142.23393249512)
    AddCameraShot(0.98570501804352,-0.078089997172356,-0.14882600307465,-0.011789999902248,-35.218330383301,15.421706199646,16.46501159668)
    AddCameraShot(0.55917698144913,-0.053045999258757,-0.82365202903748,-0.078134998679161,-71.415992736816,16.921689987183,-12.113597869873)
    AddCameraShot(0.14699600636959,-0.058008998632431,-0.91850000619888,-0.36246898770332,-220.06706237793,26.905960083008,28.651220321655)
    AddCameraShot(0.98270100355148,-0.13593299686909,-0.12459799647331,-0.01723499968648,-222.85929870605,18.505958557129,68.993171691895)
    AddCameraShot(0.80050301551819,-0.2051550000906,-0.5454940199852,-0.1397999972105,-352.6296081543,23.605941772461,117.73554992676)
    AddCameraShot(0.88270097970963,-0.040038999170065,-0.46774700284004,-0.021216999739408,-318.31625366211,3.5059549808502,125.7529296875)
    AddCameraShot(0.56367599964142,-0.10991100221872,0.80351799726486,0.15667800605297,-231.59262084961,22.405914306641,223.86767578125)
    AddCameraShot(0.93839198350906,0.11275800317526,0.32432499527931,-0.038970999419689,-251.60891723633,1.1059249639511,266.06631469727)
    AddCameraShot(0.7230190038681,0.10055500268936,0.67695397138596,-0.094148002564907,-39.843826293945,0.80589401721954,111.41689300537)
    AddCameraShot(0.96820902824402,0.021490000188351,-0.24915599822998,0.0055300001986325,-75.747406005859,12.505873680115,75.078300476074)
    AddCameraShot(0.26442900300026,-0.053654998540878,-0.94368398189545,-0.19148199260235,-125.55699920654,26.6058177948,48.87459564209)
end

function OnStart(OnStartParam0)
    AddAIGoal(ATT,"Deathmatch",1000)
    AddAIGoal(DEF,"Deathmatch",1000)
end

