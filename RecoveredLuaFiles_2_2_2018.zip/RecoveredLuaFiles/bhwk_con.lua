--bhwk_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
local local_2 = 1
local local_3 = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "cp1" })
    cp2 = CommandPost:New({ name = "cp2" })
    cp3 = CommandPost:New({ name = "cp3" })
    cp4 = CommandPost:New({ name = "cp4" })
    cp5 = CommandPost:New({ name = "cp5" })
    conquest = ObjectiveConquest:New({ teamATT = local_2, teamDEF = local_3, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:Start()
    EnableSPHeroRules()
end
local local_0 = 1
local local_1 = 2

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(20)
    SetMaxPlayerFlyHeight(20)
    ReadDataFile("sound\\dag.lvl;dag1gcw")
    ReadDataFile("SIDE\\rep.lvl","rep_hero_obiwan","rep_hero_kiyadimundi")
    ReadDataFile("SIDE\\kotor.lvl","kor_hero_mandalore","kor_hero_nihilus","rvs_inf_rbasic","rvs_inf_sbasic","rvs_inf_rheavy","rvs_inf_sheavy","rvs_inf_rsupport","rvs_inf_ssupport","rvs_inf_rstealth","rvs_inf_sstealth","rvs_inf_sadept","rvs_inf_radept","rvs_inf_rofficer","rvs_inf_sofficer","rvs_inf_rdroid","rvs_inf_sdroid")
    SetupTeams({ 
        rep =         { team = local_0, units = 20, reinforcements = 150, 
          soldier =           { "rvs_inf_rbasic", 7, 24 }, 
          assault =           { "rvs_inf_rheavy", 2, 8 }, 
          engineer =           { "rvs_inf_rdroid", 2, 8 }, 
          sniper =           { "rvs_inf_rsupport", 2, 8 }, 
          officer =           { "rvs_inf_rofficer", 2, 8 }, 
          special =           { "rvs_inf_rstealth", 1, 4 }
         }, 
        imp =         { team = local_1, units = 20, reinforcements = 150, 
          soldier =           { "rvs_inf_sbasic", 7, 24 }, 
          assault =           { "rvs_inf_sheavy", 2, 8 }, 
          engineer =           { "rvs_inf_sdroid", 2, 8 }, 
          sniper =           { "rvs_inf_ssupport", 2, 8 }, 
          officer =           { "rvs_inf_sofficer", 2, 8 }, 
          special =           { "rvs_inf_sstealth", 1, 4 }
         }
       })
    AddUnitClass(local_0,"rvs_inf_radept",1,2)
    AddUnitClass(local_1,"rvs_inf_sadept",1,2)
    SetHeroClass(local_0,"kor_hero_mandalore")
    SetHeroClass(local_1,"kor_hero_nihilus")
    ClearWalkers()
    SetMemoryPoolSize("Aimer",5)
    SetMemoryPoolSize("AmmoCounter",220)
    SetMemoryPoolSize("BaseHint",100)
    SetMemoryPoolSize("ClothData",80)
    SetMemoryPoolSize("Combo",30)
    SetMemoryPoolSize("Combo::State",500)
    SetMemoryPoolSize("Combo::Transition",500)
    SetMemoryPoolSize("Combo::Condition",500)
    SetMemoryPoolSize("Combo::Attack",400)
    SetMemoryPoolSize("Combo::DamageSample",4000)
    SetMemoryPoolSize("Combo::Deflect",88)
    SetMemoryPoolSize("EnergyBar",220)
    SetMemoryPoolSize("EntityCloth",20)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("EntitySoundStream",2)
    SetMemoryPoolSize("EntitySoundStatic",1)
    SetMemoryPoolSize("LightFlash",25)
    SetMemoryPoolSize("MountedTurret",0)
    SetMemoryPoolSize("Navigator",50)
    SetMemoryPoolSize("Obstacle",157)
    SetMemoryPoolSize("PathFollower",50)
    SetMemoryPoolSize("PathNode",128)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("UnitAgent",50)
    SetMemoryPoolSize("UnitController",50)
    SetMemoryPoolSize("Weapon",220)
    SetSpawnDelay(10,0.25)
    ReadDataFile("BHW\\bhw.lvl","bhw_conquest")
    SetDenseEnvironment("false")
    SetAIViewMultiplier(0.34999999403954)
    SetNumBirdTypes(2)
    SetBirdType(0,1,"bird")
    SetBirdType(1,1.5,"bird2")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\dag.lvl","dag1")
    SetBleedingVoiceOver(local_0,local_0,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(local_0,local_1,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_0,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_1,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(local_0,local_0,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_0,local_1,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_1,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_0,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(local_0,1,"all_dag_amb_start",0,1)
    SetAmbientMusic(local_0,0.80000001192093,"all_dag_amb_middle",1,1)
    SetAmbientMusic(local_0,0.20000000298023,"all_dag_amb_end",2,1)
    SetAmbientMusic(local_1,1,"imp_dag_amb_start",0,1)
    SetAmbientMusic(local_1,0.80000001192093,"imp_dag_amb_middle",1,1)
    SetAmbientMusic(local_1,0.20000000298023,"imp_dag_amb_end",2,1)
    SetVictoryMusic(local_0,"all_dag_amb_victory")
    SetDefeatMusic(local_0,"all_dag_amb_defeat")
    SetVictoryMusic(local_1,"imp_dag_amb_victory")
    SetDefeatMusic(local_1,"imp_dag_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(local_2)
    AddCameraShot(0.95341497659683,-0.062786996364594,0.29441800713539,0.019388999789953,20.468770980835,3.7800400257111,-110.41245269775)
    AddCameraShot(0.64612501859665,-0.080365002155304,0.75318497419357,0.093681998550892,41.348438262939,5.6880612373352,-52.695041656494)
    AddCameraShot(-0.44291099905968,0.055229000747204,-0.88798600435257,-0.11072800308466,39.894439697266,9.2341270446777,-59.177146911621)
    AddCameraShot(-0.038617998361588,0.0060410001315176,-0.98722797632217,-0.15444399416447,28.671710968018,10.001162528992,128.89218139648)
end

