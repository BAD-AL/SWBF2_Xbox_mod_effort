--at6c_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = REP
DEF = CIS

function ScriptPostLoad()
    SoundEvent_SetupTeams(REP,"rep",CIS,"cis")
    ctf = ObjectiveOneFlagCTF:New({ teamATT = REP, teamDEF = CIS, textATT = "game.modes.1flag", textDEF = "game.modes.1flag2", captureLimit = 5, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "homeregion", captureRegionATT = "team1_capture", captureRegionDEF = "team2_capture", capRegionMarkerATT = "hud_objective_icon_circle", capRegionMarkerDEF = "hud_objective_icon_circle", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3, multiplayerRules = true })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    ReadDataFile("ingame.lvl")
    SetPS2ModelMemory(4056000)
    SetMaxFlyHeight(30)
    SetMaxPlayerFlyHeight(30)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\BS1.lvl;BS1cw")
    ReadDataFile("sound\\dag.lvl;dag1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep2_rocketeer","rep_inf_ep2_rifleman","rep_inf_ep2_jettrooper","rep_inf_ep2_sniper","rep_inf_ep2_pilot")
    ReadDataFile("SIDE\\cis.lvl","cis_hero_jangofett","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka")
    ReadDataFile("SIDE\\dlc.lvl","dlc_hero_fisto")
    ReadDataFile("SIDE\\heroes.lvl","rep_hero_luminara")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_commando","cis_inf_commando","rep_inf_ep2_officer")
    SetupTeams({ 
        rep =         { team = REP, units = 30, reinforcements = 150, 
          soldier =           { "rep_inf_ep2_rifleman", 9, 25 }, 
          assault =           { "rep_inf_ep2_rocketeer", 1, 4 }, 
          pilot =           { "rep_inf_ep2_pilot", 1, 4 }, 
          sniper =           { "rep_inf_ep2_sniper", 1, 4 }, 
          officer =           { "rep_inf_ep2_officer", 1, 4 }, 
          special =           { "rep_inf_ep2_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 30, reinforcements = 150, 
          soldier =           { "cis_inf_rifleman", 9, 25 }, 
          assault =           { "cis_inf_rocketeer", 1, 4 }, 
          pilot =           { "cis_inf_pilot", 1, 4 }, 
          sniper =           { "cis_inf_sniper", 1, 4 }, 
          officer =           { "cis_inf_officer", 1, 4 }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    AddUnitClass(REP,"rep_inf_commando",1,2)
    AddUnitClass(CIS,"cis_inf_commando",1,2)
    SetHeroClass(REP,"rep_hero_luminara")
    SetHeroClass(CIS,"cis_hero_jangofett")
    AddWalkerType(0,4)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("AmmoCounter",1024)
    SetMemoryPoolSize("BaseHint",1024)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    SetMemoryPoolSize("EnergyBar",1024)
    SetMemoryPoolSize("EntityCloth",32)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityHover",32)
    SetMemoryPoolSize("EntityLight",200)
    SetMemoryPoolSize("EntitySoundStream",15)
    SetMemoryPoolSize("EntitySoundStatic",70)
    SetMemoryPoolSize("SoldierAnimation",700)
    SetMemoryPoolSize("MountedTurret",32)
    SetMemoryPoolSize("Navigator",128)
    SetMemoryPoolSize("Obstacle",1024)
    SetMemoryPoolSize("PathNode",1024)
    SetMemoryPoolSize("SoundSpaceRegion",64)
    SetMemoryPoolSize("TreeGridStack",1024)
    SetMemoryPoolSize("UnitAgent",128)
    SetMemoryPoolSize("UnitController",128)
    SetMemoryPoolSize("Weapon",1024)
    SetMemoryPoolSize("FlagItem",1)
    SetSpawnDelay(10,0.25)
    ReadDataFile("AT6\\kas1.lvl","kashyyyk1_1flag")
    SetDenseEnvironment("false")
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\dag.lvl","dag1")
    OpenAudioStream("sound\\dag.lvl","dag1")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(REP,REP,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(REP,CIS,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,CIS,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,REP,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_dag_amb_start",0,1)
    SetAmbientMusic(REP,0.80000001192093,"rep_dag_amb_middle",1,1)
    SetAmbientMusic(REP,0.20000000298023,"rep_dag_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_dag_amb_start",0,1)
    SetAmbientMusic(CIS,0.80000001192093,"cis_dag_amb_middle",1,1)
    SetAmbientMusic(CIS,0.20000000298023,"cis_dag_amb_end",2,1)
    SetVictoryMusic(REP,"rep_dag_amb_victory")
    SetDefeatMusic(REP,"rep_dag_amb_defeat")
    SetVictoryMusic(CIS,"cis_dag_amb_victory")
    SetDefeatMusic(CIS,"cis_dag_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.42113700509071,0.025737000629306,-0.90494298934937,-0.055303998291492,216.39184570313,-19.422512054443,-249.23191833496)
    AddCameraShot(0.70141100883484,0.0376220010221,-0.71074199676514,0.038123000413179,49.056308746338,-29.080774307251,-87.605171203613)
    AddCameraShot(0.91685402393341,-0.0052620000205934,0.39918100833893,0.002290999982506,222.26936340332,-30.438093185425,-130.60954284668)
end

