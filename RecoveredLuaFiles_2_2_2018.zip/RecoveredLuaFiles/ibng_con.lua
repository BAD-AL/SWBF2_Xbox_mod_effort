--ibng_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
local local_2 = 1
local local_3 = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "CP1" })
    cp2 = CommandPost:New({ name = "CP2" })
    cp3 = CommandPost:New({ name = "CP3" })
    cp4 = CommandPost:New({ name = "CP4" })
    cp5 = CommandPost:New({ name = "CP5" })
    conquest = ObjectiveConquest:New({ teamATT = local_2, teamDEF = local_3, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:Start()
    EnableSPHeroRules()
end
local local_0 = 2
local local_1 = 1

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(150)
    SetMaxPlayerFlyHeight(150)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",50)
    SetMemoryPoolSize("Combo::State",650)
    SetMemoryPoolSize("Combo::Transition",650)
    SetMemoryPoolSize("Combo::Condition",650)
    SetMemoryPoolSize("Combo::Attack",550)
    SetMemoryPoolSize("Combo::DamageSample",6000)
    SetMemoryPoolSize("Combo::Deflect",100)
    ReadDataFile("sound\\chr.lvl;commando_gcw")
    ReadDataFile("sound\\BS1.lvl;BS1gcw")
    ReadDataFile("sound\\cor.lvl;cor1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_inf_officer","all_inf_wookiee")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_bobafett")
    ReadDataFile("SIDE\\swbf1.lvl","all_fly_xwing","imp_fly_tiefighter")
    ReadDataFile("SIDE\\infantry.lvl","all_inf_specialops","imp_inf_commando")
    ReadDataFile("SIDE\\heroes.lvl","all_hero_jodokast","imp_hero_thrawn")
    SetupTeams({ 
        all =         { team = local_0, units = 20, reinforcements = 150, 
          soldier =           { "all_inf_rifleman", 9, 25 }, 
          assault =           { "all_inf_rocketeer", 1, 4 }, 
          engineer =           { "all_inf_engineer", 1, 4 }, 
          sniper =           { "all_inf_sniper", 1, 4 }, 
          officer =           { "all_inf_officer", 1, 4 }, 
          special =           { "all_inf_wookiee", 1, 4 }
         }, 
        imp =         { team = local_1, units = 20, reinforcements = 150, 
          soldier =           { "imp_inf_rifleman", 9, 25 }, 
          assault =           { "imp_inf_rocketeer", 1, 4 }, 
          engineer =           { "imp_inf_engineer", 1, 4 }, 
          sniper =           { "imp_inf_sniper", 1, 4 }, 
          officer =           { "imp_inf_officer", 1, 4 }, 
          special =           { "imp_inf_dark_trooper", 1, 4 }
         }
       })
    AddUnitClass(local_0,"all_inf_specialops",1,2)
    AddUnitClass(local_1,"imp_inf_commando",1,2)
    SetHeroClass(local_0,"all_hero_jodokast")
    SetHeroClass(local_1,"imp_hero_thrawn")
    ClearWalkers()
    AddWalkerType(0,0)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("AmmoCounter",512)
    SetMemoryPoolSize("BaseHint",1000)
    SetMemoryPoolSize("EnergyBar",512)
    SetMemoryPoolSize("EntityFlyer",50)
    SetMemoryPoolSize("EntityLight",50)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",20)
    SetMemoryPoolSize("MountedTurret",40)
    SetMemoryPoolSize("Obstacle",760)
    SetMemoryPoolSize("PathNode",512)
    SetMemoryPoolSize("SoundSpaceRegion",46)
    SetMemoryPoolSize("Weapon",512)
    SetMemoryPoolSize("SoldierAnimation",550)
    SetMemoryPoolSize("Aimer",250)
    SetMemoryPoolSize("ConnectivityGraphFollower",55)
    SetMemoryPoolSize("EntityCloth",41)
    SetMemoryPoolSize("EntityDefenseGridTurret",0)
    SetMemoryPoolSize("EntityPortableTurret",20)
    SetMemoryPoolSize("FLEffectObject::OffsetMatrix",120)
    SetMemoryPoolSize("Navigator",80)
    SetMemoryPoolSize("Ordnance",80)
    SetMemoryPoolSize("ParticleEmitter",512)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("PathFollower",80)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("TreeGridStack",340)
    SetMemoryPoolSize("UnitAgent",100)
    SetMemoryPoolSize("UnitController",110)
    SetMemoryPoolSize("Music",60)
    SetSpawnDelay(10,0.25)
    ReadDataFile("IBN\\IBN.lvl","Bounty1_conquest")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\cor.lvl","cor1")
    OpenAudioStream("sound\\cor.lvl","cor1")
    OpenAudioStream("sound\\BS1.lvl")
    OpenAudioStream("sound\\BS1.lvl")
    SetBleedingVoiceOver(local_0,local_0,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(local_0,local_1,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_0,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_1,"imp_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(local_0,1,"all_cor_amb_start",0,1)
    SetAmbientMusic(local_0,0.80000001192093,"all_cor_amb_middle",1,1)
    SetAmbientMusic(local_0,0.20000000298023,"all_cor_amb_end",2,1)
    SetAmbientMusic(local_1,1,"imp_cor_amb_start",0,1)
    SetAmbientMusic(local_1,0.80000001192093,"imp_cor_amb_middle",1,1)
    SetAmbientMusic(local_1,0.20000000298023,"imp_cor_amb_end",2,1)
    SetVictoryMusic(local_0,"all_cor_amb_victory")
    SetDefeatMusic(local_0,"all_cor_amb_defeat")
    SetVictoryMusic(local_1,"imp_cor_amb_victory")
    SetDefeatMusic(local_1,"imp_cor_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.73300802707672,-0.042259998619556,0.67777997255325,0.039076000452042,-0.302630007267,28.794353485107,75.827964782715)
    AddCameraShot(0.75283199548721,0.032205998897552,0.65682297945023,-0.028098000213504,80.700004577637,52.86413192749,7.2932300567627)
    AddCameraShot(0.73817300796509,-0.18660500645638,0.62851798534393,0.15888500213623,80.287796020508,56.51651763916,7.3138041496277)
    AddCameraShot(0.97721201181412,-0.18520499765873,0.10189999639988,0.019311999902129,68.38257598877,45.097171783447,-38.306804656982)
end

