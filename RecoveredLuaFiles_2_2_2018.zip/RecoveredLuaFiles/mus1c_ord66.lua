--mus1c_ord66.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("setup_teams")
REP = 1
JED = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    UnblockPlanningGraphArcs("Connection74")
    DisableBarriers("1")
    SetProperty("cp1","CaptureRegion","")
    SetProperty("cp2","CaptureRegion","")
    SetProperty("cp3","CaptureRegion","")
    SetProperty("cp4","CaptureRegion","")
    SetProperty("cp5","CaptureRegion","")
    SetProperty("cp6","CaptureRegion","")
    SetProperty("cp1","Team","1")
    SetProperty("cp2","Team","2")
    SetProperty("cp3","Team","2")
    SetProperty("cp4","Team","1")
    SetProperty("cp5","Team","2")
    SetProperty("cp6","Team","1")
    TDM = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, multiplayerScoreLimit = 75, textATT = "game.modes.tdm", textDEF = "game.modes.tdm2", multiplayerRules = true, isCelebrityDeathmatch = true })
    TDM:Start()
    PlayAnimRise()
    DisableBarriers("BALCONEY")
    DisableBarriers("bALCONEY2")
    DisableBarriers("hallway_f")
    DisableBarriers("hackdoor")
    DisableBarriers("outside")
    OnObjectRespawnName(PlayAnimRise,"DingDong")
    OnObjectKillName(PlayAnimDrop,"DingDong")
end

function PlayAnimDrop()
    PauseAnimation("lava_bridge_raise")
    RewindAnimation("lava_bridge_drop")
    PlayAnimation("lava_bridge_drop")
    BlockPlanningGraphArcs("Connection82")
    BlockPlanningGraphArcs("Connection83")
    EnableBarriers("Bridge")
end

function PlayAnimRise()
    PauseAnimation("lava_bridge_drop")
    RewindAnimation("lava_bridge_raise")
    PlayAnimation("lava_bridge_raise")
    UnblockPlanningGraphArcs("Connection82")
    UnblockPlanningGraphArcs("Connection83")
    DisableBarriers("Bridge")
end

function ScriptInit()
    SetPS2ModelMemory(4056000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(84.160003662109)
    SetMaxPlayerFlyHeight(84.160003662109)
    SetMemoryPoolSize("ClothData",20)
    SetMemoryPoolSize("Combo",15)
    SetMemoryPoolSize("Combo::State",250)
    SetMemoryPoolSize("Combo::Transition",300)
    SetMemoryPoolSize("Combo::Condition",300)
    SetMemoryPoolSize("Combo::Attack",250)
    SetMemoryPoolSize("Combo::DamageSample",10000)
    SetMemoryPoolSize("Combo::Deflect",150)
    ReadDataFile("sound\\chr.lvl;commando")
    ReadDataFile("sound\\mus.lvl;mus1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper")
    ReadDataFile("SIDE\\jed.lvl","jed_knight_01","jed_knight_02","jed_knight_03","jed_knight_04")
    ReadDataFile("SIDE\\infantry.lvl","rep_inf_commando","jed_knight_10","jed_knight_13","jed_knight_14")
    SetupTeams({ 
        rep =         { team = REP, units = 32, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman", 13, 16 }, 
          assault =           { "rep_inf_ep3_rocketeer", 5, 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 3, 4 }, 
          sniper =           { "rep_inf_ep3_sniper", 2, 4 }, 
          officer =           { "rep_inf_ep3_officer", 2, 4 }, 
          special =           { "rep_inf_ep3_jettrooper", 2, 4 }
         }, 
        jedi =         { team = JED, units = 15, reinforcements = -1, 
          soldier =           { "jed_knight_01", 4, 6 }, 
          assault =           { "jed_knight_02", 4, 6 }, 
          engineer =           { "jed_knight_03", 3, 6 }, 
          sniper =           { "jed_knight_04", 2, 6 }, 
          officer =           { "jed_knight_10", 1, 1 }, 
          special =           { "jed_knight_13", 1, 1 }
         }
       })
    AddUnitClass(REP,"rep_inf_commando",1,2)
    AddUnitClass(JED,"jed_knight_14",1,2)
    ClearWalkers()
    AddWalkerType(0,2)
    AddWalkerType(1,0)
    SetMemoryPoolSize("Aimer",5)
    SetMemoryPoolSize("AmmoCounter",150)
    SetMemoryPoolSize("BaseHint",200)
    SetMemoryPoolSize("EnergyBar",150)
    SetMemoryPoolSize("EntityLight",80)
    SetMemoryPoolSize("EntityFlyer",8)
    SetMemoryPoolSize("EntitySoundStream",8)
    SetMemoryPoolSize("EntitySoundStatic",27)
    SetMemoryPoolSize("FlagItem",1)
    SetMemoryPoolSize("MountedTurret",0)
    SetMemoryPoolSize("Navigator",40)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("PathFollower",40)
    SetMemoryPoolSize("PathNode",100)
    SetMemoryPoolSize("TreeGridStack",256)
    SetMemoryPoolSize("UnitAgent",40)
    SetMemoryPoolSize("UnitController",40)
    SetMemoryPoolSize("Weapon",150)
    SetMemoryPoolSize("SoldierAnimation",500)
    SetSpawnDelay(10,0.25)
    ReadDataFile("mus\\mus1.lvl","MUS1_CONQUEST")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","cor_objective_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","rep_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","all_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","rep_unit_vo_quick",voiceQuick)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\mus.lvl","mus1")
    OpenAudioStream("sound\\mus.lvl","mus1")
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetOutOfBoundsVoiceOver(2,"allleaving")
    SetVictoryMusic(REP,"rep_cor_amb_victory")
    SetDefeatMusic(REP,"rep_cor_amb_defeat")
    SetVictoryMusic(JED,"all_cor_amb_victory")
    SetDefeatMusic(JED,"all_cor_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.44639301300049,-0.064401999115944,-0.88337099552155,-0.12744499742985,-93.406929016113,72.95386505127,-35.479400634766)
    AddCameraShot(-0.29765498638153,0.057971999049187,-0.93533700704575,-0.18216900527477,-2.3840670585632,71.165306091309,18.453350067139)
    AddCameraShot(0.9724879860878,-0.098361998796463,0.21009700000286,0.021250000223517,-42.577880859375,69.453071594238,4.4546909332275)
    AddCameraShot(0.95159202814102,-0.19076600670815,-0.23630000650883,-0.047371000051498,-44.60701751709,77.906272888184,113.2286605835)
    AddCameraShot(0.84115099906921,-0.10598400235176,0.52615398168564,0.066294997930527,109.56776428223,77.906272888184,7.873034954071)
    AddCameraShot(0.81847202777863,-0.025862999260426,0.5736780166626,0.01812699995935,125.78159332275,61.423030853271,9.8091840744019)
    AddCameraShot(-0.10476399958134,0.00016300000424962,-0.99449598789215,-0.0015500000445172,-13.319854736328,70.673263549805,63.43660736084)
    AddCameraShot(0.97173899412155,0.1020580008626,0.21169200539589,-0.022233000025153,-5.6800689697266,68.5439453125,57.904159545898)
    AddCameraShot(0.17843699455261,0.0046239998191595,-0.98360997438431,0.025488000363111,-66.94743347168,68.5439453125,6.7458748817444)
    AddCameraShot(-0.4006649851799,0.076364003121853,-896894,-0.17094099521637,96.201210021973,79.913032531738,-58.604381561279)
end

