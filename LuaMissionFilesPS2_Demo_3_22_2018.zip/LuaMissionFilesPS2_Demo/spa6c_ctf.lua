--spa6c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("spa6c_cmn")
myGameMode = "spa6_ctf"

function myScriptInit()
    SetMemoryPoolSize("FlagItem",2)
end

function ScriptPostLoad()
    SetProperty("rep_flag","GeometryName","com_icon_republic")
    SetProperty("rep_flag","CarriedGeometryName","com_icon_republic_flag")
    SetProperty("cis_flag","GeometryName","com_icon_cis")
    SetProperty("cis_flag","CarriedGeometryName","com_icon_cis_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 10, text = "game.modes.ctf", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "cis_flag", homeRegion = "cis_ctf_home", captureRegion = "rep_ctf_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3, AIGoalWeight = 0 })
    ctf:AddFlag({ name = "rep_flag", homeRegion = "rep_ctf_home", captureRegion = "cis_ctf_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3, AIGoalWeight = 0 })
    ctf:Start()
    AddAIGoal(ATT,"Attack",5000,"cis_flag")
    AddAIGoal(ATT,"Defend",3000,"rep_flag")
    AddAIGoal(DEF,"Attack",5000,"rep_flag")
    AddAIGoal(DEF,"Defend",3000,"cis_flag")
    LockHangarWarsDoors()
    OnObjectKillName(PlayFrigateDeathAnim,"cis_frig1")
    OnObjectKillName(PlayFrigateDeathAnim,"cis_frig2")
end

