--uta1g_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("setup_teams")

function ScriptPostLoad()
    ctf = ObjectiveOneFlagCTF:New({ teamATT = 1, teamDEF = 2, textATT = "game.modes.1flag.att", textDEF = "game.modes.1flag.def", captureLimit = 8, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "flag_home", captureRegionATT = "Flag_capture2", captureRegionDEF = "Flag_capture1", capRegionMarkerATT = "hud_objective_icon", capRegionMarkerDEF = "hud_objective_icon", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4880000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\uta.lvl;uta1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_inf_officer","all_inf_wookiee","all_hero_hansolo_tat")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_bobafett","imp_fly_destroyer_dome","imp_walk_atst")
    SetupTeams({ 
        all =         { team = 2, units = 20, reinforcements = 100, 
          soldier =           { "all_inf_rifleman", 8 }, 
          assault =           { "all_inf_rocketeer", 3 }, 
          engineer =           { "all_inf_engineer", 4 }, 
          sniper =           { "all_inf_sniper", 2 }, 
          officer =           { "all_inf_officer", 1 }, 
          special =           { "all_inf_wookiee", 2 }
         }
       })
    SetupTeams({ 
        imp =         { team = 1, units = 20, reinforcements = 100, 
          soldier =           { "imp_inf_rifleman", 8 }, 
          assault =           { "imp_inf_rocketeer", 3 }, 
          engineer =           { "imp_inf_engineer", 4 }, 
          sniper =           { "imp_inf_sniper", 2 }, 
          officer =           { "imp_inf_officer", 1 }, 
          special =           { "imp_inf_dark_trooper", 2 }
         }
       })
    SetHeroClass(1,"imp_hero_bobafett")
    SetHeroClass(2,"all_hero_hansolo_tat")
    ClearWalkers()
    SetMemoryPoolSize("FlagItem",1)
    SetMemoryPoolSize("EntityHover",4)
    SetMemoryPoolSize("EntityLight",80)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("Weapon",260)
    SetSpawnDelay(10,0.25)
    ReadDataFile("uta\\uta1.lvl","uta1_1flag")
    SetDenseEnvironment("false")
    AddDeathRegion("deathregion")
    SetMaxFlyHeight(29.5)
    SetMaxPlayerFlyHeight(29.5)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\uta.lvl","uta1")
    OpenAudioStream("sound\\uta.lvl","uta1")
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(2,1,"all_uta_amb_start",0,1)
    SetAmbientMusic(2,0.89999997615814,"all_uta_amb_middle",1,1)
    SetAmbientMusic(2,0.10000000149012,"all_uta_amb_end",2,1)
    SetAmbientMusic(1,1,"imp_uta_amb_start",0,1)
    SetAmbientMusic(1,0.89999997615814,"imp_uta_amb_middle",1,1)
    SetAmbientMusic(1,0.10000000149012,"imp_uta_amb_end",2,1)
    SetVictoryMusic(2,"all_uta_amb_victory")
    SetDefeatMusic(2,"all_uta_amb_defeat")
    SetVictoryMusic(1,"imp_uta_amb_victory")
    SetDefeatMusic(1,"imp_uta_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.42809098958969,0.045648999512196,-0.89749401807785,-0.09570299834013,162.71495056152,45.857063293457,40.647117614746)
end

