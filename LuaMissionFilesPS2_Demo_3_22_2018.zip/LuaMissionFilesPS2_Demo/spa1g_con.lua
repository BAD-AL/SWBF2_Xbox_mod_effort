-- spa1g_con.lua
-- Decompiled by cbadal & SWBF2CodeHelper
ScriptCB_DoFile("gametype_conquest")
ScriptCB_DoFile("setup_teams")
ALL = 2
IMP = 1
ATT = 1
DEF = 2

function ScriptPostLoad()
    AddAIGoal(ATT, "conquest", 900)
    AddAIGoal(DEF, "conquest", 900)
    OnCharacterDeathTeam(
        function(ATTParam0, ATTParam1)
            AddReinforcements(ATT, -1)
        end,
        ATT
    )
    OnCharacterDeathTeam(
        function(DEFParam0, DEFParam1)
            AddReinforcements(DEF, -1)
        end,
        DEF
    )
    OnTicketCountChange(
        function(Param0, Param1)
            if Param1 <= 0 then
            end
            MissionDefeat(Param0)
        end
    )
end

function ScriptInit()
    SetPS2ModelMemory(4500000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\spa.lvl;spa1gcw")
    ScriptCB_SetDopplerFactor(0.40000000596046)
    ScaleSoundParameter("weapons", "MaxDistance", 5)
    ScaleSoundParameter("weapons", "MuteDistance", 5)
    ScaleSoundParameter("ordnance", "MinDistance", 5)
    ScaleSoundParameter("ordnance", "MaxDistance", 5)
    ScaleSoundParameter("ordnance", "MuteDistance", 5)
    ScaleSoundParameter("veh_weapon", "MaxDistance", 10)
    ScaleSoundParameter("veh_weapon", "MuteDistance", 10)
    ScaleSoundParameter("explosion", "MaxDistance", 15)
    ScaleSoundParameter("explosion", "MuteDistance", 15)
    SetMinFlyHeight(-1900)
    SetMaxFlyHeight(2000)
    SetMinPlayerFlyHeight(-1900)
    SetMaxPlayerFlyHeight(2000)
    SetAIVehicleNotifyRadius(100)
    ReadDataFile(
        "SIDE\\all.lvl",
        "all_inf_pilot",
        "all_inf_marine",
        "all_fly_xwing_sc",
        "all_fly_ywing_sc",
        "all_fly_awing",
        "all_veh_remote_terminal"
    )
    ReadDataFile(
        "SIDE\\imp.lvl",
        "imp_inf_pilot",
        "imp_inf_marine",
        "imp_fly_tiefighter_sc",
        "imp_fly_tiebomber_sc",
        "imp_fly_tieinterceptor",
        "imp_fly_trooptrans",
        "imp_veh_remote_terminal"
    )
    ClearWalkers()
    SetMemoryPoolSize("CommandFlyer", 2)
    SetMemoryPoolSize("Aimer", 150)
    SetMemoryPoolSize("BaseHint", 50)
    SetMemoryPoolSize("EntityHover", 0)
    SetMemoryPoolSize("EntityFlyer", 34)
    SetMemoryPoolSize("EntityDroid", 0)
    SetMemoryPoolSize("EntityLight", 90)
    SetMemoryPoolSize("EntityCarrier", 0)
    SetMemoryPoolSize("EntitySoldier", 35)
    SetMemoryPoolSize("EntityRemoteTerminal", 16)
    SetMemoryPoolSize("EntityMine", 32)
    SetMemoryPoolSize("MountedTurret", 60)
    SetMemoryPoolSize("Obstacle", 60)
    SetMemoryPoolSize("PassengerSlot", 0)
    SetMemoryPoolSize("PathNode", 256)
    SetMemoryPoolSize("PowerupItem", 16)
    SetMemoryPoolSize("StickInfo", 12)
    SetMemoryPoolSize("TreeGridStack", 150)
    SetMemoryPoolSize("UnitAgent", 74)
    SetMemoryPoolSize("UnitController", 74)
    SetMemoryPoolSize("Weapon", 225)
    SetMemoryPoolSize("Asteroid", 109)
    SetupTeams(
        {
            all = {
                team = ALL,
                units = 16,
                reinforcements = 25,
                pilot = {"all_inf_pilot", 12},
                marine = {"all_inf_marine", 4}
            },
            imp = {
                team = IMP,
                units = 16,
                reinforcements = 25,
                pilot = {"imp_inf_pilot", 12},
                marine = {"imp_inf_marine", 4}
            }
        }
    )
    SetSpawnDelay(10, 0.25)
    ReadDataFile("spa\\spa1.lvl")
    SetDenseEnvironment("false")
    SetParticleLODBias(3000)
    SetMaxCollisionDistance(1000)
    FillAsteroidRegion("asteroid_region1", "spa1_prop_asteroid_02", 30, 1, 0, 0, -1, 0, 0)
    FillAsteroidPath("asteroid_path1", 10, "spa1_prop_asteroid_01", 75, 1, 0, 0, -1, 0, 0)
    musicStream = OpenAudioStream("sound\\global.lvl", "all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_slow", musicStream)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", musicStream)
    OpenAudioStream("sound\\global.lvl", "gcw_music")
    OpenAudioStream("sound\\spa.lvl", "spa")
    OpenAudioStream("sound\\spa.lvl", "spa")
    SetBleedingVoiceOver(ALL, ALL, "all_off_com_report_us_overwhelmed", 1)
    SetBleedingVoiceOver(ALL, IMP, "all_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(IMP, ALL, "imp_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(IMP, IMP, "imp_off_com_report_us_overwhelmed", 1)
    SetLowReinforcementsVoiceOver(ALL, ALL, "all_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(ALL, IMP, "all_off_victory_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(IMP, IMP, "imp_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(IMP, ALL, "imp_off_victory_im", 0.10000000149012, 1)
    SetOutOfBoundsVoiceOver(1, "allleaving")
    SetOutOfBoundsVoiceOver(2, "impleaving")
    SetAmbientMusic(ALL, 1, "all_spa_amb_start", 0, 1)
    SetAmbientMusic(ALL, 0.89999997615814, "all_spa_amb_middle", 1, 1)
    SetAmbientMusic(ALL, 0.10000000149012, "all_spa_amb_end", 2, 1)
    SetAmbientMusic(IMP, 1, "imp_spa_amb_start", 0, 1)
    SetAmbientMusic(IMP, 0.89999997615814, "imp_spa_amb_middle", 1, 1)
    SetAmbientMusic(IMP, 0.10000000149012, "imp_spa_amb_end", 2, 1)
    SetVictoryMusic(ALL, "all_spa_amb_victory")
    SetDefeatMusic(ALL, "all_spa_amb_defeat")
    SetVictoryMusic(IMP, "imp_spa_amb_victory")
    SetDefeatMusic(IMP, "imp_spa_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(
        0.99765402078629,
        0.066982001066208,
        0.014139000326395,
        -0.00094900000840425,
        155.1371307373,
        0.91150498390198,
        -138.07707214355
    )
    AddCameraShot(
        0.72976100444794,
        0.019262000918388,
        0.68319398164749,
        -0.018032999709249,
        -98.584869384766,
        0.29528400301933,
        263.23928833008
    )
    AddCameraShot(
        0.69427698850632,
        0.0051000001840293,
        0.71967101097107,
        -0.0052869999781251,
        -11.105946540833,
        -2.7532069683075,
        67.982200622559
    )
    AddLandingRegion("CP1Control")
    AddLandingRegion("CP2Control")
    if gPlatformStr == "PS2" then
        ScriptCB_DisableFlyerShadows()
    end
end
