--cor1c_con.lua
-- Decompiled with SWBF2CodeHelper
Conquest = ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
CIS = 1
REP = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    EnableSPHeroRules()
    DisableBarriers("SideDoor1")
    DisableBarriers("MainLibraryDoors")
    DisableBarriers("SideDoor2")
    DisableBarriers("SIdeDoor3")
    DisableBarriers("ComputerRoomDoor1")
    DisableBarriers("StarChamberDoor1")
    DisableBarriers("StarChamberDoor2")
    DisableBarriers("WarRoomDoor1")
    DisableBarriers("WarRoomDoor2")
    DisableBarriers("WarRoomDoor3")
    PlayAnimation("DoorOpen01")
    PlayAnimation("DoorOpen02")
    cp1 = CommandPost:New({ name = "cp1" })
    cp2 = CommandPost:New({ name = "cp2" })
    cp3 = CommandPost:New({ name = "cp3" })
    cp4 = CommandPost:New({ name = "cp4" })
    cp5 = CommandPost:New({ name = "cp5" })
    cp6 = CommandPost:New({ name = "cp6" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "level.yavin1.con.att", textDEF = "level.yavin1.con.def", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)
    conquest:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4200000)
    SetMapNorthAngle(0)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\cor.lvl;cor1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_fly_assault_DOME","rep_fly_gunship_DOME","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper","rep_hero_macewindu")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_fly_droidfighter_DOME","cis_inf_rocketeer","cis_inf_engineer","cis_inf_officer","cis_inf_sniper","cis_inf_droideka","cis_hero_darthmaul")
    SetupTeams({ 
        rep =         { team = REP, units = 25, reinforcements = 200, 
          soldier =           { "rep_inf_ep3_rifleman", 11 }, 
          assault =           { "rep_inf_ep3_rocketeer", 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 3 }, 
          sniper =           { "rep_inf_ep3_sniper", 2 }, 
          officer =           { "rep_inf_ep3_officer", 2 }, 
          special =           { "rep_inf_ep3_jettrooper", 3 }
         }, 
        cis =         { team = CIS, units = 25, reinforcements = 200, 
          soldier =           { "cis_inf_rifleman", 11 }, 
          assault =           { "cis_inf_rocketeer", 4 }, 
          engineer =           { "cis_inf_engineer", 3 }, 
          sniper =           { "cis_inf_sniper", 2 }, 
          officer =           { "cis_inf_officer", 2 }, 
          special =           { "cis_inf_droideka", 3 }
         }
       })
    SetHeroClass(CIS,"cis_hero_darthmaul")
    SetHeroClass(REP,"rep_hero_macewindu")
    ClearWalkers()
    AddWalkerType(0,3)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",22)
    SetMemoryPoolSize("AmmoCounter",150)
    SetMemoryPoolSize("BaseHint",300)
    SetMemoryPoolSize("EnergyBar",150)
    SetMemoryPoolSize("EntityHover",0)
    SetMemoryPoolSize("EntityLight",100)
    SetMemoryPoolSize("MountedTurret",13)
    SetMemoryPoolSize("SoundSpaceRegion",38)
    SetMemoryPoolSize("Weapon",150)
    SetSpawnDelay(10,0.25)
    ReadDataFile("cor\\cor1.lvl","cor1_Conquest")
    SetDenseEnvironment("True")
    AddDeathRegion("DeathRegion1")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\cor.lvl","cor1")
    OpenAudioStream("sound\\cor.lvl","cor1")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(REP,REP,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(REP,CIS,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,CIS,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,REP,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_cor_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_cor_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_cor_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_cor_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_cor_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_cor_amb_end",2,1)
    SetVictoryMusic(REP,"rep_cor_amb_victory")
    SetDefeatMusic(REP,"rep_cor_amb_defeat")
    SetVictoryMusic(CIS,"cis_cor_amb_victory")
    SetDefeatMusic(CIS,"cis_cor_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.40489500761032,0.0009919999865815,-0.91435998678207,-0.0022400000598282,-85.539894104004,20.536296844482,141.6994934082)
    AddCameraShot(0.040922001004219,0.004048999864608,-0.99429899454117,0.098380997776985,-139.72952270508,17.546598434448,-34.360893249512)
    AddCameraShot(-0.31235998868942,0.016223000362515,-0.94854700565338,-0.049263000488281,-217.38148498535,20.150953292847,54.514324188232)
end

