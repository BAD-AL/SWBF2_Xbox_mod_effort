--hot1g_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
ALL = 2
IMP = 1
ATT = 1
DEF = 2

function ScriptPostLoad()
    SetObjectTeam("CP3",1)
    SetObjectTeam("CP6",1)
    KillObject("CP7")
    EnableSPHeroRules()
    cp1 = CommandPost:New({ name = "CP3" })
    cp2 = CommandPost:New({ name = "CP4" })
    cp3 = CommandPost:New({ name = "CP5" })
    cp4 = CommandPost:New({ name = "CP6" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:Start()
    KillObject("shield")
end

function ScriptInit()
if ScriptCB_GetPlatform() == "PS2" then
end
    StealArtistHeap(1024 * 1024)
    SetPS2ModelMemory(3300000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(70)
    SetMaxPlayerFlyHeight(70)
    ReadDataFile("sound\\hot.lvl;hot1gcw")
    ReadDataFile("SIDE\\all.lvl","all_fly_snowspeeder","all_inf_rifleman_snow","all_inf_rocketeer_snow","all_inf_engineer_snow","all_inf_sniper_snow","all_inf_officer_snow","all_hero_luke_jedi","all_inf_wookiee_snow","all_walk_tauntaun")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman_snow","imp_inf_rocketeer_snow","imp_inf_sniper_snow","imp_inf_dark_trooper","imp_inf_engineer","imp_inf_officer","imp_hero_darthvader","imp_walk_atat","imp_walk_atst_snow")
    SetupTeams({ 
        all =         { team = ALL, units = 20, reinforcements = 160, 
          soldier =           { "all_inf_rifleman_snow" }, 
          assault =           { "all_inf_rocketeer_snow" }, 
          engineer =           { "all_inf_engineer_snow" }, 
          sniper =           { "all_inf_sniper_snow" }, 
          officer =           { "all_inf_officer_snow" }, 
          special =           { "all_inf_wookiee_snow" }
         }, 
        imp =         { team = IMP, units = 20, reinforcements = 160, 
          soldier =           { "imp_inf_rifleman_snow" }, 
          assault =           { "imp_inf_rocketeer_snow" }, 
          engineer =           { "imp_inf_engineer" }, 
          sniper =           { "imp_inf_sniper_snow" }, 
          officer =           { "imp_inf_officer" }, 
          special =           { "imp_inf_dark_trooper" }
         }
       })
    SetHeroClass(IMP,"imp_hero_darthvader")
    SetHeroClass(ALL,"all_hero_luke_jedi")
    ClearWalkers()
    SetMemoryPoolSize("EntityWalker",-2)
    AddWalkerType(0,0)
    AddWalkerType(1,5)
    AddWalkerType(2,2)
    SetMemoryPoolSize("CommandWalker",2)
    SetMemoryPoolSize("EntityFlyer",6)
    SetMemoryPoolSize("MountedTurret",46)
    SetMemoryPoolSize("Weapon",269)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("Ordnance",28)
    SetMemoryPoolSize("BaseHint",210)
    SetMemoryPoolSize("Obstacle",344)
    SetMemoryPoolSize("Aimer",90)
    SetMemoryPoolSize("EnergyBar",269)
    SetMemoryPoolSize("AmmoCounter",269)
if ScriptCB_GetPlatform() == "PS2" then
        SetMemoryPoolSize("Combo::DamageSample",64)
        SetMemoryPoolSize("ConnectivityGraphFollower",56)
        SetMemoryPoolSize("EntityDefenseGridTurret",4)
        SetMemoryPoolSize("EntityDroid",3)
        SetMemoryPoolSize("EntityLight",130)
        SetMemoryPoolSize("EntityMine",12)
        SetMemoryPoolSize("EntityPortableTurret",4)
        SetMemoryPoolSize("EntitySoundStatic",16)
        SetMemoryPoolSize("EntitySoundStream",4)
        SetMemoryPoolSize("FLEffectObject::OffsetMatrix",54)
        SetMemoryPoolSize("LightFlash",3)
        SetMemoryPoolSize("LightningBoltEffectObject",3)
        SetMemoryPoolSize("Navigator",63)
        SetMemoryPoolSize("OrdnanceTowCable",4)
        SetMemoryPoolSize("ParticleEmitter",175)
        SetMemoryPoolSize("ParticleEmitterInfoData",225)
        SetMemoryPoolSize("ParticleEmitterObject",112)
        SetMemoryPoolSize("PathFollower",63)
        SetMemoryPoolSize("PathNode",268)
        SetMemoryPoolSize("PowerupItem",14)
        SetMemoryPoolSize("RayRequest",64)
        SetMemoryPoolSize("StickInfo",20)
        SetMemoryPoolSize("TreeGridStack",329)
        SetMemoryPoolSize("UnitController",63)
        SetMemoryPoolSize("UnitAgent",63)
else
        SetMemoryPoolSize("EntityDroid",5)
        SetMemoryPoolSize("EntityLight",100)
        SetMemoryPoolSize("EntityMine",16)
        SetMemoryPoolSize("LightFlash",12)
        SetMemoryPoolSize("OrdnanceTowCable",8)
        SetMemoryPoolSize("ParticleEmitter",200)
        SetMemoryPoolSize("ParticleEmitterInfoData",300)
        SetMemoryPoolSize("ParticleEmitterObject",150)
        SetMemoryPoolSize("PathNode",150)
        SetMemoryPoolSize("PowerupItem",20)
        SetMemoryPoolSize("TreeGridStack",275)
end
    ReadDataFile("HOT\\hot1.lvl","hoth_conquest")
    SetSpawnDelay(10,0.25)
    SetDenseEnvironment("false")
    SetDefenderSnipeRange(170)
    AddDeathRegion("Death")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(ALL,1,"all_hot_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_hot_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_hot_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_hot_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_hot_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_hot_amb_end",2,1)
    SetVictoryMusic(ALL,"all_hot_amb_victory")
    SetDefeatMusic(ALL,"all_hot_amb_defeat")
    SetVictoryMusic(IMP,"imp_hot_amb_victory")
    SetDefeatMusic(IMP,"imp_hot_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.94420999288559,0.065540999174118,0.3219830095768,-0.022350000217557,-500.48983764648,0.79747200012207,-68.773849487305)
    AddCameraShot(0.37119698524475,0.0081900004297495,-0.92829197645187,0.020481999963522,-473.38415527344,-17.880533218384,132.12680053711)
    AddCameraShot(0.92708301544189,0.020455999299884,-0.37420600652695,0.0082569997757673,-333.22155761719,0.67604297399521,-14.027347564697)
end

