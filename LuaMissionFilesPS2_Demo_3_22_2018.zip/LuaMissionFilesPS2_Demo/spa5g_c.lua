-- spa5g_c.lua
-- Decompiled by cbadal & SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveAssault")
ScriptCB_DoFile("MultiObjectiveContainer")

local ALL = 1
local EMP = 2
local ATT = 1
local DEF = 2

function ScriptPostLoad()
    ScriptCB_PlayInGameMovie("ingame.mvs", "sb5mon01")
    timeoutTimer = CreateTimer("timeout")
    SetTimerValue(timeoutTimer, 210)
    StartTimer(timeoutTimer)
    ShowTimer(timeoutTimer)
    timerdefeat =
        OnTimerElapse(
        function(timer)
            MissionVictory(DEF)
            ShowTimer(nil)
            DestroyTimer(timeoutTimer)
        end,
        timeoutTimer
    )
    PlayAnimationFromTo("friga", 0, 399)
    PlayAnimationFromTo("frigb", 0, 359)

    onfirstspawn =
        OnCharacterSpawn(
        function(Param0)
            if Param0 == 0 then
                ReleaseCharacterSpawn(onfirstspawn)
                onfirstspawn = nil
                BeginObjectives()
            end
        end
    )

    trans01 = Target:New({name = "mini01"})
    trans02 = Target:New({name = "mini02"})
    trans03 = Target:New({name = "mini03"})
    trans04 = Target:New({name = "mini04"})
    trans05 = Target:New({name = "mini05"})

    Objective1 = ObjectiveAssault:New({teamATT = ATT, teamDEF = DEF, text = "level.spa5.objectives.campaign.1"})
    Objective1:AddTarget(trans01)
    Objective1:AddTarget(trans02)
    Objective1:AddTarget(trans03)
    Objective1:AddTarget(trans04)
    Objective1:AddTarget(trans05)

    Objective1.OnStart = function(OnStartParam0)
        ScriptCB_EnableCommandPostVO(0)
        ScriptCB_SndPlaySound("SPA5_obj_01")
        mini01Death = OnObjectKillName(Translist01, "mini01")
        mini02Death = OnObjectKillName(Translist02, "mini02")
        mini03Death = OnObjectKillName(Translist03, "mini03")
        mini04Death = OnObjectKillName(Translist04, "mini04")
        mini05Death = OnObjectKillName(Translist05, "mini05")
    end
    Objective1.OnComplete = function(OnCompleteParam0)
        ScriptCB_SndPlaySound("SPA5_obj_03")
        ReleaseObjectKill(mini01Death)
        ReleaseObjectKill(mini02Death)
        ReleaseObjectKill(mini03Death)
        ReleaseObjectKill(mini04Death)
        ReleaseObjectKill(mini05Death)
        DestroyTimer(timeoutTimer)
        ShowTimer(nil)
        ReleaseTimerElapse(timerdefeat)
    end
    Objective1.OnSingleTargetDestroyed = function(this, OnSingleTargetDestroyedParam1)
        local targets = this:GetNumSingleTargets()
        if targets > 0 then
            ShowMessageText("level.spa5.objectives.campaign.1-" .. targets, 1)
        end
    end

    Frig01 = Target:New({name = "rep_m01"})
    Frig02 = Target:New({name = "rep_m02"})

    Objective2 = ObjectiveAssault:New({teamATT = ATT, teamDEF = DEF, text = "level.spa5.objectives.campaign.2"})
    Objective2:AddTarget(Frig01)
    Objective2:AddTarget(Frig02)

    Objective2.OnStart = function(OnStartParam0)
        ScriptCB_SndPlaySound("SPA5_obj_02")
        FrigDeath01 = OnObjectKillName(Friglist01, "rep_m01")
        FrigDeath02 = OnObjectKillName(Friglist02, "rep_m02")
    end
    Objective2.OnComplete = function(OnCompleteParam0)
        ScriptCB_SndPlaySound("SPA5_obj_04")
        ReleaseObjectKill(FrigDeath01)
        ReleaseObjectKill(FrigDeath02)
    end
    Objective2.OnSingleTargetDestroyed = function(this, OnSingleTargetDestroyedParam1)
        local targets = this:GetNumSingleTargets()
        if targets > 0 then
            ShowMessageText("level.spa5.objectives.campaign.2-" .. targets, 1)
        end
    end

    Rep_crit = Target:New({name = "critsys"})
    Rep_crit.OnDestroy = function(param0)
    end

    Objective3 = ObjectiveAssault:New({teamATT = ATT, teamDEF = DEF, text = "level.spa5.objectives.campaign.3"})
    Objective3:AddTarget(Rep_crit)
    Objective3.OnStart = function(OnStartParam0)
        ScriptCB_SndPlaySound("SPA5_obj_05")
    end

    Objective3.OnComplete = function(OnCompleteParam0)
        ScriptCB_SndPlaySound("SPA5_obj_08")
        ShowMessageText("level.spa5.objectives.campaign.3c", ATT)
    end

    function BeginObjectives()
        objectiveSequence = MultiObjectiveContainer:New({delayVictoryTime = 6})
        objectiveSequence:AddObjectiveSet(Objective1)
        objectiveSequence:AddObjectiveSet(Objective2)
        objectiveSequence:AddObjectiveSet(Objective3)
        objectiveSequence:Start()
    end

    function Translist01()
        PauseAnimation("trans01")
        RewindAnimation("list1")
        SetAnimationStartPoint("list1")
        PlayAnimation("list1")
    end

    function Translist02()
        PauseAnimation("trans02")
        RewindAnimation("list2")
        SetAnimationStartPoint("list2")
        PlayAnimation("list2")
    end

    function Translist03()
        PauseAnimation("trans03")
        RewindAnimation("list3")
        SetAnimationStartPoint("list3")
        PlayAnimation("list3")
    end

    function Translist04()
        PauseAnimation("trans04")
        RewindAnimation("list4")
        SetAnimationStartPoint("list4")
        PlayAnimation("list4")
    end

    function Translist05()
        PauseAnimation("trans05")
        RewindAnimation("list5")
        SetAnimationStartPoint("list5")
        PlayAnimation("list5")
    end

    function Friglist01()
        PauseAnimation("friga")
        RewindAnimation("frilist01")
        SetAnimationStartPoint("frilist01")
        PlayAnimation("frilist01")
    end

    function Friglist02()
        PauseAnimation("frigb")
        RewindAnimation("frilist02")
        SetAnimationStartPoint("frilist02")
        PlayAnimation("frilist02")
    end
end

function ScriptInit()
    SetPS2ModelMemory(3800000)
    ReadDataFile("ingame.lvl")

    SetMinFlyHeight(-1900)
    SetMaxFlyHeight(2000)
    SetMinPlayerFlyHeight(-1900)
    SetMaxPlayerFlyHeight(2000)
    SetAIVehicleNotifyRadius(100)

    ReadDataFile("sound\\spa.lvl;spa4cross")

    ScriptCB_SetDopplerFactor(0.40000000596046)

    ScaleSoundParameter("weapons", "MaxDistance", 5)
    ScaleSoundParameter("weapons", "MuteDistance", 5)
    ScaleSoundParameter("ordnance", "MinDistance", 5)
    ScaleSoundParameter("ordnance", "MaxDistance", 5)
    ScaleSoundParameter("ordnance", "MuteDistance", 5)
    ScaleSoundParameter("veh_weapon", "MaxDistance", 10)
    ScaleSoundParameter("veh_weapon", "MuteDistance", 10)
    ScaleSoundParameter("explosion", "MaxDistance", 15)
    ScaleSoundParameter("explosion", "MuteDistance", 15)

    ReadDataFile(
        "SIDE\\imp.lvl",
        "imp_inf_pilot",
        "imp_inf_marine",
        "imp_fly_tiefighter_sc",
        "imp_fly_tiebomber_sc",
        "imp_fly_tieinterceptor",
        "imp_fly_trooptrans",
        "imp_veh_remote_terminal"
    )
    ReadDataFile(
        "SIDE\\rep.lvl",
        "rep_inf_ep3_pilot",
        "rep_inf_ep3_marine",
        "rep_fly_assault_dome",
        "rep_fly_anakinstarfighter_sc",
        "rep_fly_arc170fighter_sc",
        "rep_veh_remote_terminal",
        "rep_fly_arc170fighter_dome",
        "rep_fly_gunship",
        "rep_fly_vwing"
    )
    SetupTeams(
        {
            imp = {
                team = ALL,
                units = 10,
                reinforcements = 25,
                pilot = {"imp_inf_pilot", 8},
                marine = {"imp_inf_marine", 2}
            },
            rep = {
                team = EMP,
                units = 22,
                reinforcements = -1,
                pilot = {"rep_inf_ep3_pilot", 12},
                marine = {"rep_inf_ep3_marine", 10}
            }
        }
    )

    ClearWalkers()

    SetMemoryPoolSize("CommandFlyer", 2)
    SetMemoryPoolSize("PowerupItem", 60)
    SetMemoryPoolSize("EntityMine", 40)
    SetMemoryPoolSize("EntityFlyer", 34)
    SetMemoryPoolSize("EntityLight", 90)
    SetMemoryPoolSize("Aimer", 200)
    SetMemoryPoolSize("Obstacle", 80)

    SetSpawnDelay(10, 0.25)
    ReadDataFile("spa\\spa5.lvl")
    SetDenseEnvironment("false")

    musicStream = OpenAudioStream("sound\\global.lvl", "spa1_objective_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "all_unit_vo_slow", musicStream)
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_slow", musicStream)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", musicStream)
    OpenAudioStream("sound\\global.lvl", "cw_music")
    OpenAudioStream("sound\\spa.lvl", "spa")
    OpenAudioStream("sound\\spa.lvl", "spa")
    SetOutOfBoundsVoiceOver(1, "allleaving")
    SetOutOfBoundsVoiceOver(2, "impleaving")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    AddCameraShot(
        -0.40489500761032,
        0.0009919999865815,
        -0.91435998678207,
        -0.0022400000598282,
        -85.539894104004,
        20.536296844482,
        141.6994934082
    )
    if gPlatformStr == "PS2" then
        ScriptCB_DisableFlyerShadows()
    end
end
