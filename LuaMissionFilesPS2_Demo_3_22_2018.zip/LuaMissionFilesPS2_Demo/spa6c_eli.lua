--spa6c_eli.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("spa6c_cmn")
myGameMode = "spa6_tdm"
myTeamConfig = { 
  rep =   { team = REP, units = 16, reinforcements = 100, 
    pilot =     { "rep_inf_ep3_pilot", 6 }, 
    marine =     { "rep_inf_ep3_marine", 10 }
   }, 
  cis =   { team = CIS, units = 16, reinforcements = 100, 
    pilot =     { "cis_inf_pilot", 6 }, 
    marine =     { "cis_inf_marine", 10 }
   }
 }

function ScriptPostLoad()
    EnableSPHeroRules()
    tdm = ObjectiveTDM:New({ teamATT = REP, teamDEF = CIS, textATT = "level.kamino1.objectives.tdm.1", textDEF = "level.kamino1.objectives.tdm.2", multiplayerRules = true, HideCps = true })
    tdm:Start()
    LockHangarWarsDoors()
    OnObjectKillName(PlayFrigateDeathAnim,"cis_frig1")
    OnObjectKillName(PlayFrigateDeathAnim,"cis_frig2")
end

