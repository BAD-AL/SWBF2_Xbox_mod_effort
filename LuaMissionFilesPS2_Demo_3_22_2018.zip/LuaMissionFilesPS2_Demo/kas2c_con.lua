--kas2c_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    EnableSPHeroRules()
    cp1 = CommandPost:New({ name = "CP1CON" })
    cp3 = CommandPost:New({ name = "CP3CON" })
    cp4 = CommandPost:New({ name = "CP4CON" })
    cp5 = CommandPost:New({ name = "CP5CON" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:Start()
    BlockPlanningGraphArcs("seawall1")
    BlockPlanningGraphArcs("woodl")
    BlockPlanningGraphArcs("woodc")
    BlockPlanningGraphArcs("woodr")
    OnObjectKillName(PlayAnimDown,"gatepanel")
    OnObjectRespawnName(PlayAnimUp,"gatepanel")
    OnObjectKillName(woodl,"woodl")
    OnObjectKillName(woodc,"woodc")
    OnObjectKillName(woodr,"woodr")
end

function PlayAnimDown()
    PauseAnimation("thegateup")
    RewindAnimation("thegatedown")
    PlayAnimation("thegatedown")
    ShowMessageText("level.kas2.objectives.gateopen",1)
    ScriptCB_SndPlaySound("KAS_obj_13")
    PlayAnimation("gatepanel")
    UnblockPlanningGraphArcs("seawall1")
    DisableBarriers("seawalldoor1")
    DisableBarriers("vehicleblocker")
end

function PlayAnimUp()
    PauseAnimation("thegatedown")
    RewindAnimation("thegateup")
    PlayAnimation("thegateup")
    BlockPlanningGraphArcs("seawall1")
    EnableBarriers("seawalldoor1")
    EnableBarriers("vehicleblocker")
end

function woodl()
    UnblockPlanningGraphArcs("woodl")
    DisableBarriers("woodl")
end

function woodc()
    UnblockPlanningGraphArcs("woodc")
    DisableBarriers("woodc")
end

function woodr()
    UnblockPlanningGraphArcs("woodr")
    DisableBarriers("woodr")
end

function ScriptInit()
    SetPS2ModelMemory(3700000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(70)
    ReadDataFile("sound\\kas.lvl;kas2cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_sniper_felucia","rep_inf_ep3_engineer","rep_inf_ep3_jettrooper","rep_inf_ep3_officer","rep_hero_yoda","rep_hover_fightertank","rep_fly_cat_dome","rep_hover_barcspeeder")
    ReadDataFile("SIDE\\cis.lvl","cis_tread_snailtank","cis_inf_rifleman","cis_fly_gunship_dome","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_hover_stap","cis_inf_officer","cis_walk_spider","cis_hero_jangofett","cis_inf_droideka")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_recoilless_lg")
    SetupTeams({ 
        rep =         { team = REP, units = 25, reinforcements = 160, 
          soldier =           { "rep_inf_ep3_rifleman" }, 
          assault =           { "rep_inf_ep3_rocketeer" }, 
          engineer =           { "rep_inf_ep3_engineer" }, 
          sniper =           { "rep_inf_ep3_sniper_felucia" }, 
          officer =           { "rep_inf_ep3_officer" }, 
          special =           { "rep_inf_ep3_jettrooper", 1, 4 }
         }, 
        cis =         { team = CIS, units = 25, reinforcements = 160, 
          soldier =           { "cis_inf_rifleman" }, 
          assault =           { "cis_inf_rocketeer" }, 
          engineer =           { "cis_inf_engineer" }, 
          sniper =           { "cis_inf_sniper" }, 
          officer =           { "cis_inf_officer" }, 
          special =           { "cis_inf_droideka", 0 }
         }
       })
    SetHeroClass(REP,"rep_hero_yoda")
    SetHeroClass(CIS,"cis_hero_jangofett")
    ClearWalkers()
    AddWalkerType(0,8)
    AddWalkerType(1,0)
    AddWalkerType(2,2)
    AddWalkerType(3,0)
    SetMemoryPoolSize("CommandHover",0)
    SetMemoryPoolSize("MountedTurret",20)
    SetMemoryPoolSize("EntityHover",9)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("EntityBuildingArmedDynamic",0)
    SetMemoryPoolSize("EntityDroid",8)
    SetMemoryPoolSize("EntityLight",60)
    SetMemoryPoolSize("PowerupItem",30)
    SetMemoryPoolSize("EntityMine",30)
    SetMemoryPoolSize("Aimer",100)
    SetMemoryPoolSize("Obstacle",590)
    SetMemoryPoolSize("BaseHint",50)
    SetMemoryPoolSize("TreeGridStack",300)
    SetMemoryPoolSize("Weapon",265)
    SetMemoryPoolSize("Ordnance",100)
    SetMemoryPoolSize("PathNode",512)
    SetMemoryPoolSize("ParticleEmitter",512)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("PassengerSlot",0)
    SetSpawnDelay(10,0.25)
    ReadDataFile("KAS\\kas2.lvl","kas2_con")
    SetDenseEnvironment("false")
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\kas.lvl","kas")
    OpenAudioStream("sound\\kas.lvl","kas")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetAmbientMusic(REP,1,"rep_kas_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_kas_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_kas_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_kas_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_kas_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_kas_amb_end",2,1)
    SetVictoryMusic(REP,"rep_kas_amb_victory")
    SetDefeatMusic(REP,"rep_kas_amb_defeat")
    SetVictoryMusic(CIS,"cis_kas_amb_victory")
    SetDefeatMusic(CIS,"cis_kas_amb_defeat")
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.99366897344589,-0.09961000084877,-0.051708001643419,-0.0051830001175404,109.47354888916,34.506076812744,272.88922119141)
    AddCameraShot(-0.13082699477673,0.02471400052309,-0.97387301921844,-0.18396799266338,146.41287231445,60.191699981689,-191.87882995605)
    AddCameraShot(0.94083100557327,-0.10825499892235,-0.31901299953461,-0.036706998944283,-65.793930053711,66.455177307129,289.43267822266)
    AddCameraShot(0.52312701940536,-0.055344998836517,-0.84573602676392,-0.089475996792316,-170.51907348633,66.455177307129,-248.87753295898)
end

