--pol1g_con.lua
-- Decompiled with SWBF2CodeHelper
Conquest = ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
ALL = 1
IMP = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "CP1Con" })
    cp2 = CommandPost:New({ name = "CP2Con" })
    cp3 = CommandPost:New({ name = "CP3Con" })
    cp4 = CommandPost:New({ name = "CP4Con" })
    cp5 = CommandPost:New({ name = "CP5Con" })
    cp6 = CommandPost:New({ name = "CP6Con" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "level.yavin1.con.att", textDEF = "level.yavin1.con.def", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)
    conquest:Start()
    OnObjectRespawnName(PlayAnimLock01Open,"LockCon01")
    OnObjectKillName(PlayAnimLock01Close,"LockCon01")
    EnableSPHeroRules()
end

function PlayAnimLock01Open()
    PauseAnimation("Airlockclose")
    RewindAnimation("Airlockopen")
    PlayAnimation("Airlockopen")
end

function PlayAnimLock01Close()
    PauseAnimation("Airlockopen")
    RewindAnimation("Airlockclose")
    PlayAnimation("Airlockclose")
end

function ScriptInit()
    SetPS2ModelMemory(4000000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\pol.lvl;pol1gcw")
    SetMapNorthAngle(0)
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_urban","all_inf_rocketeer","all_inf_engineer","all_inf_sniper","all_inf_officer","all_inf_wookiee","all_hero_leia")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_emperor","imp_hover_fightertank")
    SetupTeams({ 
        imp =         { team = IMP, units = 25, reinforcements = 200, 
          soldier =           { "imp_inf_rifleman", 11 }, 
          assault =           { "imp_inf_rocketeer", 4 }, 
          engineer =           { "imp_inf_engineer", 3 }, 
          sniper =           { "imp_inf_sniper", 2 }, 
          officer =           { "imp_inf_officer", 2 }, 
          special =           { "imp_inf_dark_trooper", 3 }
         }, 
        all =         { team = ALL, units = 25, reinforcements = 200, 
          soldier =           { "all_inf_rifleman_urban", 11 }, 
          assault =           { "all_inf_rocketeer", 4 }, 
          engineer =           { "all_inf_engineer", 3 }, 
          sniper =           { "all_inf_sniper", 2 }, 
          officer =           { "all_inf_officer", 2 }, 
          special =           { "all_inf_wookiee", 3 }
         }
       })
    SetHeroClass(ALL,"all_hero_leia")
    SetHeroClass(IMP,"imp_hero_emperor")
    ClearWalkers()
    SetMemoryPoolSize("MountedTurret",4)
    SetMemoryPoolSize("EntityHover",3)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("Obstacle",380)
    SetMemoryPoolSize("Weapon",260)
    SetMemoryPoolSize("EntityLight",63)
    SetMemoryPoolSize("Asteroid",100)
    SetSpawnDelay(10,0.25)
    ReadDataFile("pol\\pol1.lvl","pol1_Conquest")
    SetDenseEnvironment("True")
    AddDeathRegion("deathregion1")
    SetParticleLODBias(3000)
    SetMaxCollisionDistance(1500)
    FillAsteroidPath("pathas01",10,"pol1_prop_asteroid_01",20,1,0,0,-1,0,0)
    FillAsteroidPath("pathas01",20,"pol1_prop_asteroid_02",40,1,0,0,-1,0,0)
    FillAsteroidPath("pathas02",10,"pol1_prop_asteroid_01",10,1,0,0,-1,0,0)
    FillAsteroidPath("pathas03",10,"pol1_prop_asteroid_02",20,1,0,0,-1,0,0)
    FillAsteroidPath("pathas04",5,"pol1_prop_asteroid_02",2,1,0,0,-1,0,0)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\pol.lvl","pol1")
    OpenAudioStream("sound\\pol.lvl","pol1")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"all_pol_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_pol_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_pol_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_pol_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_pol_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_pol_amb_end",2,1)
    SetVictoryMusic(ALL,"all_pol_amb_victory")
    SetDefeatMusic(ALL,"all_pol_amb_defeat")
    SetVictoryMusic(IMP,"imp_pol_amb_victory")
    SetDefeatMusic(IMP,"imp_pol_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.85406500101089,-0.16903600096703,0.48257398605347,0.095509998500347,128.82421875,30.888416290283,-38.9797706604)
    AddCameraShot(-0.41455799341202,0.013601000420749,-0.90943199396133,-0.029836000874639,134.57727050781,22.840515136719,-72.278869628906)
    AddCameraShot(-0.1275289952755,0.0026879999786615,-0.99161100387573,-0.020903000608087,108.37355041504,13.554483413696,-114.7483291626)
    AddCameraShot(-0.19772699475288,0.01040400005877,-0.97884798049927,-0.051506999880075,79.075950622559,29.489900588989,35.428806304932)
    AddCameraShot(-0.22460900247097,0.091807000339031,-0.89799600839615,-0.3670499920845,75.250473022461,41.861679077148,46.076160430908)
    AddCameraShot(-0.37751001119614,0.045922998338938,-0.91809797286987,-0.11168400198221,-89.576377868652,36.126071929932,53.575286865234)
    AddCameraShot(0.39623698592186,-0.09884300082922,-0.88567101955414,-0.22093500196934,-119.81173706055,57.899345397949,-11.914485931396)
    AddCameraShot(0.98426997661591,-0.12962199747562,-0.11901500076056,-0.015674000605941,-74.040222167969,30.126516342163,47.421016693115)
    AddCameraShot(0.98591601848602,-0.14751300215721,0.077936001121998,0.011660999618471,-60.501594543457,30.210624694824,43.851440429688)
    AddCameraShot(-0.38474398851395,0.037819001823664,-0.9178249835968,-0.090218998491764,-38.854251861572,30.210624694824,2.0682051181793)
    AddCameraShot(0.93934601545334,0.081541001796722,0.33188799023628,-0.028810000047088,-17.522380828857,24.605794906616,-37.65604019165)
    AddCameraShot(0.62286001443863,-0.044911000877619,-0.77902001142502,-0.056171000003815,22.677572250366,20.374139785767,-120.13481140137)
    AddCameraShot(0.034506998956203,-0.0035069999285042,-0.99427700042725,-0.1010439991951,-104.15363311768,29.038522720337,-153.45225524902)
    AddCameraShot(0.77926898002625,-0.14476400613785,-0.59948402643204,-0.11136499792337,-109.15534973145,29.038522720337,-126.08100128174)
    AddCameraShot(0.080113001167774,-0.011087999679148,-0.98731201887131,-0.13664999604225,-118.77136993408,27.157234191895,-143.4631652832)
    AddCameraShot(0.38907900452614,0.014746000058949,-0.92042499780655,0.034885000437498,-114.27289581299,16.971555709839,-25.945049285889)
    AddCameraShot(0.98966902494431,0.0030610000248998,0.14334000647068,-0.00044299999717623,-99.405647277832,17.96580696106,-40.161994934082)
    AddCameraShot(0.95217299461365,-0.20846499502659,-0.21823400259018,-0.047779001295567,-63.606155395508,56.08479309082,32.748664855957)
end

