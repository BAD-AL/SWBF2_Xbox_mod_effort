--yav1g_con.lua
-- Decompiled with SWBF2CodeHelper
Conquest = ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
local local_2 = 1
local local_3 = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "Bazaar" })
    cp2 = CommandPost:New({ name = "CP1" })
    cp3 = CommandPost:New({ name = "LandingZone" })
    cp4 = CommandPost:New({ name = "ReflectingPool" })
    cp5 = CommandPost:New({ name = "Temple" })
    cp6 = CommandPost:New({ name = "Tflank" })
    cp7 = CommandPost:New({ name = "ViaDuct" })
    conquest = ObjectiveConquest:New({ teamATT = local_2, teamDEF = local_3, textATT = "level.yavin1.con.att", textDEF = "level.yavin1.con.def", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)
    conquest:AddCommandPost(cp7)
    conquest:Start()
    EnableSPHeroRules()
end
local local_0 = 2
local local_1 = 1

function ScriptInit()
    SetPS2ModelMemory(3728224)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(-17)
    ReadDataFile("sound\\yav.lvl;yav1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_jungle","all_inf_rocketeer_jungle","all_inf_sniper_jungle","all_inf_engineer_jungle","all_inf_officer_jungle","all_hero_chewbacca","all_inf_wookiee")
    ReadDataFile("SIDE\\imp.lvl","imp_hover_speederbike","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_bobafett")
    SetupTeams({ 
        all =         { team = local_0, units = 25, reinforcements = 200, 
          soldier =           { "all_inf_rifleman_jungle", 11 }, 
          assault =           { "all_inf_rocketeer_jungle", 4 }, 
          engineer =           { "all_inf_engineer_jungle", 3 }, 
          sniper =           { "all_inf_sniper_jungle", 2 }, 
          officer =           { "all_inf_officer_jungle", 2 }, 
          special =           { "all_inf_wookiee", 3 }
         }, 
        imp =         { team = local_1, units = 25, reinforcements = 200, 
          soldier =           { "imp_inf_rifleman", 11 }, 
          assault =           { "imp_inf_rocketeer", 4 }, 
          engineer =           { "imp_inf_engineer", 3 }, 
          sniper =           { "imp_inf_sniper", 2 }, 
          officer =           { "imp_inf_officer", 2 }, 
          special =           { "imp_inf_dark_trooper", 3 }
         }
       })
    SetHeroClass(local_0,"all_hero_chewbacca")
    SetHeroClass(local_1,"imp_hero_bobafett")
    AddWalkerType(0,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",17)
    SetMemoryPoolSize("AmmoCounter",186)
    SetMemoryPoolSize("Combo::DamageSample",256)
    SetMemoryPoolSize("BaseHint",1000)
    SetMemoryPoolSize("EnergyBar",186)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("EntityDroid",8)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityHover",4)
    SetMemoryPoolSize("EntityLight",50)
    SetMemoryPoolSize("EntityMine",28)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",20)
    SetMemoryPoolSize("MountedTurret",13)
    SetMemoryPoolSize("Navigator",49)
    SetMemoryPoolSize("Obstacle",760)
    SetMemoryPoolSize("Ordnance",96)
    SetMemoryPoolSize("PathNode",512)
    SetMemoryPoolSize("RayRequest",128)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("SoundSpaceRegion",46)
    SetMemoryPoolSize("TreeGridStack",500)
    SetMemoryPoolSize("UnitAgent",49)
    SetMemoryPoolSize("UnitController",49)
    SetMemoryPoolSize("Weapon",186)
    SetSpawnDelay(10,0.25)
    ReadDataFile("YAV\\yav1.lvl","Yavin1_Conquest")
    SetDenseEnvironment("false")
    SetNumBirdTypes(2)
    SetBirdType(0,1,"bird")
    SetBirdType(1,1.5,"bird2")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1_emt")
    SetBleedingVoiceOver(local_0,local_0,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(local_0,local_1,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_0,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_1,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(local_0,local_0,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_0,local_1,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_1,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_0,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"impleaving")
    SetOutOfBoundsVoiceOver(2,"allleaving")
    SetAmbientMusic(local_0,1,"all_yav_amb_start",0,1)
    SetAmbientMusic(local_0,0.89999997615814,"all_yav_amb_middle",1,1)
    SetAmbientMusic(local_0,0.10000000149012,"all_yav_amb_end",2,1)
    SetAmbientMusic(local_1,1,"imp_yav_amb_start",0,1)
    SetAmbientMusic(local_1,0.89999997615814,"imp_yav_amb_middle",1,1)
    SetAmbientMusic(local_1,0.10000000149012,"imp_yav_amb_end",2,1)
    SetVictoryMusic(local_0,"all_yav_amb_victory")
    SetDefeatMusic(local_0,"all_yav_amb_defeat")
    SetVictoryMusic(local_1,"imp_yav_amb_victory")
    SetDefeatMusic(local_1,"imp_yav_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(local_2)
    AddCameraShot(0.92569398880005,-0.056832000613213,0.37327700853348,0.022917000576854,132.35606384277,-65.527252197266,-25.416561126709)
    AddCameraShot(0.36135500669479,-0.024311000481248,-0.93000900745392,-0.062568999826908,93.845817565918,-52.247051239014,-194.74313354492)
    AddCameraShot(0.93407398462296,0.077334001660347,-0.34741699695587,0.028764000162482,102.66004943848,-30.127220153809,-335.16714477539)
end

