--mus1c_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "cp1" })
    cp2 = CommandPost:New({ name = "cp2" })
    cp3 = CommandPost:New({ name = "cp3" })
    cp4 = CommandPost:New({ name = "cp4" })
    cp5 = CommandPost:New({ name = "cp5" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.mode.con", textDEF = "game.mode.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:Start()
    PlayAnimRise()
    DisableBarriers("BALCONEY")
    DisableBarriers("bALCONEY2")
    DisableBarriers("hallway_f")
    DisableBarriers("hackdoor")
    DisableBarriers("outside")
    OnObjectRespawnName(PlayAnimRise,"DingDong")
    OnObjectKillName(PlayAnimDrop,"DingDong")
    EnableSPHeroRules()
end

function PlayAnimDrop()
    PauseAnimation("lava_bridge_raise")
    RewindAnimation("lava_bridge_drop")
    PlayAnimation("lava_bridge_drop")
    BlockPlanningGraphArcs("Connection82")
    BlockPlanningGraphArcs("Connection83")
    EnableBarriers("Bridge")
end

function PlayAnimRise()
    PauseAnimation("lava_bridge_drop")
    RewindAnimation("lava_bridge_raise")
    PlayAnimation("lava_bridge_raise")
    UnblockPlanningGraphArcs("Connection82")
    UnblockPlanningGraphArcs("Connection83")
    DisableBarriers("Bridge")
end

function ScriptInit()
    SetPS2ModelMemory(3600000)
    ReadDataFile("ingame.lvl")
    SetTeamAggressiveness(1,0.94999998807907)
    SetTeamAggressiveness(2,0.94999998807907)
    ReadDataFile("sound\\mus.lvl;mus1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_jettrooper","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_hero_obiwan")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_hero_darthmaul","CIS_inf_officer","cis_inf_droideka")
    SetAttackingTeam(1)
    SetupTeams({ 
        REP =         { team = 1, units = 25, reinforcements = 250, 
          soldier =           { "rep_inf_ep3_rifleman" }, 
          assault =           { "rep_inf_ep3_rocketeer" }, 
          engineer =           { "rep_inf_ep3_engineer" }, 
          sniper =           { "rep_inf_ep3_sniper" }, 
          officer =           { "rep_inf_ep3_officer" }, 
          special =           { "rep_inf_ep3_jettrooper" }
         }
       })
    SetupTeams({ 
        CIS =         { team = 2, units = 25, reinforcements = 250, 
          soldier =           { "CIS_inf_rifleman" }, 
          assault =           { "CIS_inf_rocketeer" }, 
          engineer =           { "CIS_inf_engineer" }, 
          sniper =           { "CIS_inf_sniper" }, 
          officer =           { "CIS_inf_officer" }, 
          special =           { "cis_inf_droideka" }
         }
       })
    SetHeroClass(1,"rep_hero_obiwan")
    SetHeroClass(2,"cis_hero_darthmaul")
    ClearWalkers()
    AddWalkerType(0,8)
    SetMemoryPoolSize("PowerupItem",60)
    SetMemoryPoolSize("EntityMine",40)
    SetMemoryPoolSize("Aimer",200)
    SetMemoryPoolSize("EntitySoundStatic",175)
    SetMemoryPoolSize("Obstacle",250)
    SetMemoryPoolSize("FlagItem",2)
    SetSpawnDelay(10,0.25)
    ReadDataFile("mus\\mus1.lvl","MUS1_CONQUEST")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\mus.lvl","mus1")
    OpenAudioStream("sound\\mus.lvl","mus1")
    SetBleedingVoiceOver(1,1,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(1,2,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(2,1,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(2,2,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(1,1,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(1,2,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(2,1,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(2,2,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(1,1,"rep_mus_amb_start",0,1)
    SetAmbientMusic(1,0.89999997615814,"rep_mus_amb_middle",1,1)
    SetAmbientMusic(1,0.10000000149012,"rep_mus_amb_end",2,1)
    SetAmbientMusic(2,1,"cis_mus_amb_start",0,1)
    SetAmbientMusic(2,0.89999997615814,"cis_mus_amb_middle",1,1)
    SetAmbientMusic(2,0.10000000149012,"cis_mus_amb_end",2,1)
    SetVictoryMusic(1,"rep_mus_amb_victory")
    SetDefeatMusic(1,"rep_mus_amb_defeat")
    SetVictoryMusic(2,"cis_mus_amb_victory")
    SetDefeatMusic(2,"cis_mus_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.88499200344086,-0.12753500044346,-0.44092801213264,-0.063873000442982,-96.635223388672,72.084869384766,8.2408618927002)
    AddCameraShot(0.88102000951767,-0.13016700744629,0.44993698596954,0.066476002335548,-25.155872344971,72.485176086426,-0.20587199926376)
    AddCameraShot(0.97234797477722,0.09859299659729,0.210632994771,-0.02135800011456,168.82385253906,30.84568977356,105.86446380615)
end

