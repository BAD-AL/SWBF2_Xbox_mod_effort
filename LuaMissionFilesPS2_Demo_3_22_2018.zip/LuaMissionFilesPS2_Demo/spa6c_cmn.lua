--spa6c_cmn.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function SetupUnits()
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_pilot","rep_inf_ep3_marine","rep_fly_assault_dome","rep_fly_anakinstarfighter_sc","rep_fly_arc170fighter_sc","rep_veh_remote_terminal","rep_fly_gunship_sc","rep_fly_vwing")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_pilot","cis_inf_marine","cis_fly_fedlander_dome","cis_fly_droidfighter_sc","cis_fly_droidgunship","cis_fly_greviousfighter","cis_fly_tridroidfighter")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_all_recoilless","tur_bldg_cis_chaingun","tur_bldg_imp_beam","tur_bldg_rep_cannon")
end
myTeamConfig = { 
  rep =   { team = REP, units = 16, reinforcements = -1, 
    pilot =     { "rep_inf_ep3_pilot", 6 }, 
    marine =     { "rep_inf_ep3_marine", 10 }
   }, 
  cis =   { team = CIS, units = 16, reinforcements = -1, 
    pilot =     { "cis_inf_pilot", 6 }, 
    marine =     { "cis_inf_marine", 10 }
   }
 }

function LockHangarWarsDoors()
    pairs({ "cis_cap1_door3", "cis_cap1_door4", "cis_cap1_door5", "rep_cap1_door1", "rep_cap1_door2", "rep_cap1_door3", "rep_cap2_door1", "rep_cap2_door2", "rep_cap3_door3" })
    ERROR_PROCESSING_FUNCTION = true
end

function PlayFrigateDeathAnim(PlayFrigateDeathAnimParam0)
    GetEntityName(PlayFrigateDeathAnimParam0)
    RewindAnimation()
    SetAnimationStartPoint()
    PlayAnimation()
    ERROR_PROCESSING_FUNCTION = true
end

function ScriptInit()
    SetPS2ModelMemory(4900000)
    ReadDataFile("ingame.lvl")
    SetMinFlyHeight(-1900)
    SetMaxFlyHeight(2000)
    SetMinPlayerFlyHeight(-1900)
    SetMaxPlayerFlyHeight(2000)
    SetAIVehicleNotifyRadius(100)
    ReadDataFile("sound\\spa.lvl;spa2cw")
    ScriptCB_SetDopplerFactor(0.40000000596046)
    ScaleSoundParameter("ordnance","MinDistance",5)
    ScaleSoundParameter("ordnance","MaxDistance",5)
    ScaleSoundParameter("ordnance","MuteDistance",5)
    ScaleSoundParameter("veh_weapon","MaxDistance",10)
    ScaleSoundParameter("veh_weapon","MuteDistance",10)
    ScaleSoundParameter("explosion","MaxDistance",15)
    ScaleSoundParameter("explosion","MuteDistance",15)
    SetupUnits()
    SetupTeams(myTeamConfig)
    ClearWalkers()
    SetMemoryPoolSize("Aimer",160)
    SetMemoryPoolSize("AmmoCounter",190)
    SetMemoryPoolSize("BaseHint",50)
    SetMemoryPoolSize("CommandFlyer",4)
    SetMemoryPoolSize("EnergyBar",190)
    SetMemoryPoolSize("EntityHover",0)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("EntityLight",90)
    SetMemoryPoolSize("EntityMine",32)
    SetMemoryPoolSize("EntitySoldier",32)
    SetMemoryPoolSize("EntityDroideka",0)
    SetMemoryPoolSize("EntityDroid",0)
    SetMemoryPoolSize("EntityRemoteTerminal",12)
    SetMemoryPoolSize("MountedTurret",60)
    SetMemoryPoolSize("Navigator",32)
    SetMemoryPoolSize("Obstacle",100)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("PathNode",128)
    SetMemoryPoolSize("UnitAgent",32 * 2)
    SetMemoryPoolSize("UnitController",32 * 2)
    SetMemoryPoolSize("TreeGridStack",150)
    SetMemoryPoolSize("Weapon",190)
    SetMemoryPoolSize("PowerupItem",30)
    SetSpawnDelay(10,0.25)
    ERROR_PROCESSING_FUNCTION = true
end

