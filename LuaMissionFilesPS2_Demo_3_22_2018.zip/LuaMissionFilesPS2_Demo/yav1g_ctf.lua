--yav1g_ctf.lua
-- Decompiled with SWBF2CodeHelper
CTF = ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")
ATT = 1
DEF = 2
ALL = ATT
IMP = DEF

function ScriptPostLoad()
    SetProperty("flag1","GeometryName","com_icon_alliance_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_alliance_flag")
    SetProperty("flag2","GeometryName","com_icon_imperial_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_imperial_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 8, text = "level.geo1.objectives.ctf", hideCPs = false, multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag1Capture", captureRegion = "flag2Capture", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag2Capture", captureRegion = "flag1Capture", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    StealArtistHeap(128 * 1024)
    SetPS2ModelMemory(2600000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(14)
    SetMaxPlayerFlyHeight(14)
    SetMaxFlyHeight(-17)
    ReadDataFile("sound\\yav.lvl;yav1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_jungle","all_inf_rocketeer_jungle","all_inf_sniper_jungle","all_inf_engineer_jungle","all_inf_officer_jungle","all_hero_chewbacca","all_inf_wookiee")
    ReadDataFile("SIDE\\imp.lvl","imp_hover_speederbike","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_pilot_atst","imp_inf_sniper","imp_inf_dark_trooper","imp_hero_bobafett","imp_walk_atst")
    SetupTeams({ 
        all =         { team = ALL, units = 25, reinforcements = -1, 
          soldier =           { "all_inf_rifleman_jungle", 11 }, 
          assault =           { "all_inf_rocketeer_jungle", 4 }, 
          engineer =           { "all_inf_engineer_jungle", 3 }, 
          sniper =           { "all_inf_sniper_jungle", 2 }, 
          officer =           { "all_inf_officer_jungle", 2 }, 
          special =           { "all_inf_wookiee", 3 }
         }, 
        imp =         { team = IMP, units = 25, reinforcements = -1, 
          soldier =           { "imp_inf_rifleman", 11 }, 
          assault =           { "imp_inf_rocketeer", 4 }, 
          engineer =           { "imp_inf_engineer", 3 }, 
          sniper =           { "imp_inf_sniper", 2 }, 
          officer =           { "imp_inf_officer", 2 }, 
          special =           { "imp_inf_dark_trooper", 3 }
         }
       })
    SetHeroClass(ALL,"all_hero_chewbacca")
    SetHeroClass(IMP,"imp_hero_bobafett")
    AddWalkerType(0,0)
    AddWalkerType(1,2)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",16)
    SetMemoryPoolSize("AmmoCounter",150)
    SetMemoryPoolSize("BaseHint",1000)
    SetMemoryPoolSize("EnergyBar",150)
    SetMemoryPoolSize("EntityHover",3)
    SetMemoryPoolSize("EntityLight",38)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",20)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("MountedTurret",13)
    SetMemoryPoolSize("Obstacle",751)
    SetMemoryPoolSize("PathNode",256)
    SetMemoryPoolSize("ShieldEffect",0)
    SetMemoryPoolSize("SoundSpaceRegion",48)
    SetMemoryPoolSize("TreeGridStack",500)
    SetMemoryPoolSize("Weapon",150)
    SetSpawnDelay(10,0.25)
    ReadDataFile("YAV\\yav1.lvl","Yavin1_CTF")
    SetDenseEnvironment("false")
    SetNumBirdTypes(2)
    SetBirdType(0,1,"bird")
    SetBirdType(1,1.5,"bird2")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1_emt")
    SetOutOfBoundsVoiceOver(1,"impleaving")
    SetOutOfBoundsVoiceOver(2,"allleaving")
    SetAmbientMusic(ALL,1,"all_yav_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_yav_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_yav_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_yav_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_yav_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_yav_amb_end",2,1)
    SetVictoryMusic(ALL,"all_yav_amb_victory")
    SetDefeatMusic(ALL,"all_yav_amb_defeat")
    SetVictoryMusic(IMP,"imp_yav_amb_victory")
    SetDefeatMusic(IMP,"imp_yav_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.92569398880005,-0.056832000613213,0.37327700853348,0.022917000576854,132.35606384277,-65.527252197266,-25.416561126709)
    AddCameraShot(0.36135500669479,-0.024311000481248,-0.93000900745392,-0.062568999826908,93.845817565918,-52.247051239014,-194.74313354492)
    AddCameraShot(0.93407398462296,0.077334001660347,-0.34741699695587,0.028764000162482,102.66004943848,-30.127220153809,-335.16714477539)
end

