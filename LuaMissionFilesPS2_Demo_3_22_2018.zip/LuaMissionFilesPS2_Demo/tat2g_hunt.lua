--tat2g_hunt.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("Objective")
ALL = 2
IMP = 1
ATT = 1
DEF = 2

function ScriptPostLoad()
    KillObject("cp2")
    KillObject("cp6")
    KillObject("cp7")
    KillObject("cp8")
    KillObject("cp1")
    KillObject("cp3")
    hunt = Objective:New({text = "level.end1.objectives.hunt"})
    hunt.OnStart = function(OnStartParam0)
        AddAIGoal(ATT, "Deathmatch", 1000)
        AddAIGoal(DEF, "Deathmatch", 1000)
    end

    hunt_timer = CreateTimer("hunt_timer")
    SetTimerValue(hunt_timer, 300)
    StartTimer(hunt_timer)
    victory =
        OnTimerElapse(
        function(hunt_timerParam0)
            MissionVictory(ATT)
            ReleaseTimerElapse(victory)
        end,
        hunt_timer
    )
    ShowTimer(hunt_timer)
    hunt:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(2097152 + 65536 * 10)
    ReadDataFile("ingame.lvl")
    AddMissionObjective(IMP, "red", "level.tat2.objectives.1")
    AddMissionObjective(ALL, "green", "level.tat2.objectives.1b")
    SetMaxFlyHeight(40)
    ReadDataFile("sound\\tat.lvl;tat2gcw")
    ReadDataFile("SIDE\\des.lvl", "tat_inf_jawa", "tat_inf_tuskenraider", "tat_inf_tuskenhunter")
    SetTeamName(1, "Tuskens")
    AddUnitClass(1, "tat_inf_tuskenhunter", 1)
    AddUnitClass(1, "tat_inf_tuskenraider", 0)
    SetUnitCount(1, 25)
    SetTeamAsEnemy(ATT, DEF)
    SetReinforcementCount(1, -1)
    SetTeamName(2, "Jawas")
    AddUnitClass(2, "tat_inf_jawa", 25)
    SetUnitCount(2, 25)
    SetTeamAsEnemy(DEF, ATT)
    SetReinforcementCount(2, -1)
    ClearWalkers()
    AddWalkerType(0, 0)
    AddWalkerType(1, 0)
    AddWalkerType(2, 0)
    AddWalkerType(3, 0)
    SetMemoryPoolSize("Aimer", 14)
    SetMemoryPoolSize("EntityDroid", 8)
    SetMemoryPoolSize("EntityMine", 30)
    SetMemoryPoolSize("MountedTurret", 14)
    SetMemoryPoolSize("Obstacle", 653)
    SetMemoryPoolSize("Ordnance", 60)
    SetMemoryPoolSize("ParticleEmitter", 256)
    SetMemoryPoolSize("ParticleEmitterInfoData", 256)
    SetMemoryPoolSize("ParticleEmitterObject", 128)
    SetMemoryPoolSize("PassengerSlot", 0)
    SetMemoryPoolSize("PathNode", 384)
    SetMemoryPoolSize("TreeGridStack", 500)
    SetSpawnDelay(10, 0.25)
    ReadDataFile("TAT\\tat2.lvl", "tat2_hunt")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl", "all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_slow", voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl", "all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_quick", voiceQuick)
    OpenAudioStream("sound\\global.lvl", "gcw_music")
    OpenAudioStream("sound\\tat.lvl", "tat2")
    OpenAudioStream("sound\\tat.lvl", "tat2")
    SetBleedingVoiceOver(ALL, ALL, "all_off_com_report_us_overwhelmed", 1)
    SetBleedingVoiceOver(ALL, IMP, "all_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(IMP, ALL, "imp_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(IMP, IMP, "imp_off_com_report_us_overwhelmed", 1)
    SetLowReinforcementsVoiceOver(ALL, ALL, "all_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(ALL, IMP, "all_off_victory_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(IMP, IMP, "imp_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(IMP, ALL, "imp_off_victory_im", 0.10000000149012, 1)
    SetOutOfBoundsVoiceOver(2, "Allleaving")
    SetOutOfBoundsVoiceOver(1, "Impleaving")
    SetAmbientMusic(ALL, 1, "all_tat_amb_start", 0, 1)
    SetAmbientMusic(ALL, 0.89999997615814, "all_tat_amb_middle", 1, 1)
    SetAmbientMusic(ALL, 0.10000000149012, "all_tat_amb_end", 2, 1)
    SetAmbientMusic(IMP, 1, "imp_tat_amb_start", 0, 1)
    SetAmbientMusic(IMP, 0.89999997615814, "imp_tat_amb_middle", 1, 1)
    SetAmbientMusic(IMP, 0.10000000149012, "imp_tat_amb_end", 2, 1)
    SetVictoryMusic(ALL, "all_tat_amb_victory")
    SetDefeatMusic(ALL, "all_tat_amb_defeat")
    SetVictoryMusic(IMP, "imp_tat_amb_victory")
    SetDefeatMusic(IMP, "imp_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(
        0.51487797498703,
        -0.14333200454712,
        -0.81423497200012,
        -0.22666700184345,
        -351.05249023438,
        31.599720001221,
        -71.300521850586
    )
    AddCameraShot(
        0.89931601285934,
        0.0074450001120567,
        0.43722000718117,
        -0.00362000009045,
        -212.96699523926,
        20.173393249512,
        56.179828643799
    )
    AddCameraShot(
        0.90299302339554,
        -0.019974999129772,
        -0.42908498644829,
        -0.0094919996336102,
        -205.00177001953,
        17.679758071899,
        77.177253723145
    )
end
