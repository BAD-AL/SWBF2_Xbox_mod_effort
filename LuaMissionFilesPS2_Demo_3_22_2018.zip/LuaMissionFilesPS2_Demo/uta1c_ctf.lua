--uta1c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = REP
DEF = CIS

function ScriptPostLoad()
    SetProperty("flag1","GeometryName","com_icon_republic_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_republic_flag")
    SetProperty("flag2","GeometryName","com_icon_cis_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_cis_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 8, text = "game.modes.ctf", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag2_cap", captureRegion = "flag1_cap", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag1_cap", captureRegion = "flag2_cap", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4880000)
    ReadDataFile("ingame.lvl")
    SetTeamAggressiveness(REP,0.94999998807907)
    SetTeamAggressiveness(CIS,0.94999998807907)
    ReadDataFile("sound\\uta.lvl;uta1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper","rep_hero_obiwan","rep_hover_fightertank")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka","cis_hero_grievous")
    SetupTeams({ 
        rep =         { team = REP, units = 20, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman", 8 }, 
          assault =           { "rep_inf_ep3_rocketeer", 3 }, 
          engineer =           { "rep_inf_ep3_engineer", 4 }, 
          sniper =           { "rep_inf_ep3_sniper", 2 }, 
          officer =           { "rep_inf_ep3_officer", 1 }, 
          special =           { "rep_inf_ep3_jettrooper", 2 }
         }, 
        cis =         { team = CIS, units = 20, reinforcements = -1, 
          soldier =           { "cis_inf_rifleman", 8 }, 
          assault =           { "cis_inf_rocketeer", 3 }, 
          engineer =           { "cis_inf_engineer", 4 }, 
          sniper =           { "cis_inf_sniper", 2 }, 
          officer =           { "cis_inf_officer", 1 }, 
          special =           { "cis_inf_droideka", 2 }
         }
       })
    SetHeroClass(REP,"rep_hero_obiwan")
    SetHeroClass(CIS,"cis_hero_grievous")
    ClearWalkers()
    AddWalkerType(0,3)
    AddWalkerType(1,0)
    SetMemoryPoolSize("Aimer",6)
    SetMemoryPoolSize("BaseHint",200)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityHover",0)
    SetMemoryPoolSize("EntityLight",36)
    SetMemoryPoolSize("EntitySoundStream",8)
    SetMemoryPoolSize("EntitySoundStatic",0)
    SetMemoryPoolSize("MountedTurret",0)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("PathNode",200)
    SetMemoryPoolSize("PowerupItem",60)
    SetMemoryPoolSize("Timer",10)
    SetMemoryPoolSize("TreeGridStack",250)
    SetMemoryPoolSize("Weapon",130)
    AddUnitClass(4,"rep_inf_ep3_rifleman",1)
    SetUnitCount(4,1)
    SetSpawnDelay(10,0.25)
    ReadDataFile("uta\\uta1.lvl","uta1_CTF2flag")
    SetDenseEnvironment("false")
    AddDeathRegion("deathregion")
    SetMaxFlyHeight(29.5)
    SetMaxPlayerFlyHeight(29.5)
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\uta.lvl","uta1")
    OpenAudioStream("sound\\uta.lvl","uta1")
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_uta_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_uta_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_uta_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_uta_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_uta_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_uta_amb_end",2,1)
    SetVictoryMusic(REP,"rep_uta_amb_victory")
    SetDefeatMusic(REP,"rep_uta_amb_defeat")
    SetVictoryMusic(CIS,"cis_uta_amb_victory")
    SetDefeatMusic(CIS,"cis_uta_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.42809098958969,0.045648999512196,-0.89749401807785,-0.09570299834013,162.71495056152,45.857063293457,40.647117614746)
end

