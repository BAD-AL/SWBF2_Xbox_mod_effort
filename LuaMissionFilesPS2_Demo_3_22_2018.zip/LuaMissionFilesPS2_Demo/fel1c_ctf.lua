--fel1c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
ATT = 1
DEF = 2
REP = ATT
CIS = DEF

function ScriptPostLoad()
    EnableSPHeroRules()
    SetProperty("flag1","GeometryName","com_icon_republic_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_republic_flag")
    SetProperty("flag2","GeometryName","com_icon_cis_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_cis_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 8, textATT = "game.modes.ctf", textDEF = "game.modes.ctf2", multiplayerRules = true, hideCPs = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag1_home", captureRegion = "flag2_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag2_home", captureRegion = "flag1_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
end

function ScriptInit()
    SetPS2ModelMemory(3200000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\fel.lvl;fel1cw")
    SetMaxFlyHeight(53)
    SetMaxPlayerFlyHeight(53)
    ReadDataFile("SIDE\\rep.lvl","Rep_hover_swampspeeder","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_jettrooper","rep_inf_ep3_sniper_felucia","rep_hero_aalya","REP_walk_atte","rep_inf_ep3_officer")
    ReadDataFile("SIDE\\cis.lvl","cis_hover_aat","cis_hover_stap","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_hero_jangofett","CIS_inf_officer","cis_inf_droideka")
    SetAttackingTeam(ATT)
    SetupTeams({ 
        rep =         { team = REP, units = 25, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman" }, 
          assault =           { "rep_inf_ep3_rocketeer" }, 
          engineer =           { "rep_inf_ep3_engineer" }, 
          sniper =           { "rep_inf_ep3_sniper_felucia" }, 
          officer =           { "rep_inf_ep3_officer" }, 
          special =           { "rep_inf_ep3_jettrooper" }
         }, 
        cis =         { team = CIS, units = 25, reinforcements = -1, 
          soldier =           { "CIS_inf_rifleman" }, 
          assault =           { "CIS_inf_rocketeer" }, 
          engineer =           { "CIS_inf_engineer" }, 
          sniper =           { "CIS_inf_sniper" }, 
          officer =           { "CIS_inf_officer" }, 
          special =           { "cis_inf_droideka" }
         }
       })
    SetHeroClass(REP,"rep_hero_aalya")
    SetHeroClass(CIS,"cis_hero_jangofett")
    ClearWalkers()
    AddWalkerType(0,3)
    AddWalkerType(3,1)
    SetMemoryPoolSize("CommandWalker",2)
    SetMemoryPoolSize("EntityHover",5)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("TreeGridStack",280)
    SetMemoryPoolSize("BaseHint",100)
    SetMemoryPoolSize("Obstacle",340)
    SetMemoryPoolSize("FlagItem",2)
    SetSpawnDelay(10,0.25)
    ReadDataFile("fel\\fel1.lvl","fel1_ctf")
    SetDenseEnvironment("false")
    SetAIViewMultiplier(0.46999999880791)
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\fel.lvl","fel1")
    OpenAudioStream("sound\\fel.lvl","fel1")
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_fel_amb_start",0,1)
    SetAmbientMusic(REP,0.99000000953674,"rep_fel_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_fel_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_fel_amb_start",0,1)
    SetAmbientMusic(CIS,0.99000000953674,"cis_fel_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_fel_amb_end",2,1)
    SetVictoryMusic(REP,"rep_fel_amb_victory")
    SetDefeatMusic(REP,"rep_fel_amb_defeat")
    SetVictoryMusic(CIS,"cis_fel_amb_victory")
    SetDefeatMusic(CIS,"cis_fel_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.89630699157715,-0.17134800553322,-0.40171599388123,-0.076796002686024,-116.30693054199,31.039505004883,20.757469177246)
    AddCameraShot(0.90934300422668,-0.2019670009613,-0.35508298873901,-0.078864999115467,-116.30693054199,31.039505004883,20.757469177246)
    AddCameraShot(0.54319900274277,0.11552099883556,-0.81342798471451,0.17298999428749,-108.37818908691,13.564240455627,-40.644149780273)
    AddCameraShot(0.97061002254486,0.13565899431705,0.1968660056591,-0.027514999732375,-3.2143459320068,11.924586296082,-44.687294006348)
    AddCameraShot(0.34613001346588,0.046310998499393,-0.92876601219177,0.12426699697971,87.431060791016,20.881387710571,13.070729255676)
    AddCameraShot(0.4680840075016,0.095610998570919,-0.86072397232056,0.1758120059967,18.063482284546,19.360580444336,18.178157806396)
end

