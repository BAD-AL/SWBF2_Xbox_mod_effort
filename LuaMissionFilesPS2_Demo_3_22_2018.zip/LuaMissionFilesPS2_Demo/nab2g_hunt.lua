--nab2g_hunt.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("Objective")
ScriptCB_DoFile("setup_teams")
IMP = 1
ALL = 2
ATT = IMP
DEF = ALL
EnableSPHeroRules()

function ScriptPostLoad()
    hunt = Objective:New({text = "level.end1.objectives.hunt"})
    hunt.OnStart = function(OnStartParam0)
        AddAIGoal(ATT, "Deathmatch", 1000)
        AddAIGoal(DEF, "Deathmatch", 1000)
    end

    hunt_timer = CreateTimer("hunt_timer")
    SetTimerValue(hunt_timer, 300)
    StartTimer(hunt_timer)
    victory =
        OnTimerElapse(
        function(hunt_timerParam0)
            MissionVictory(ATT)
            ReleaseTimerElapse(victory)
        end,
        hunt_timer
    )
    ShowTimer(hunt_timer)
    hunt:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(2097152 + 65536 * 10)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\nab.lvl;nab2gcw")
    ReadDataFile("SIDE\\gar.lvl", "gar_inf_temple_soldier", "gar_inf_temple_vanguard")
    ReadDataFile("SIDE\\imp.lvl", "imp_inf_dark_trooper")
    SetupTeams(
        {
            imp = {
                team = IMP,
                units = 32,
                reinforcements = -1,
                special = {"imp_inf_dark_trooper", 1}
            },
            all = {
                team = ALL,
                units = 32,
                reinforcements = -1,
                soldier = {"gar_inf_temple_soldier", 16},
                assault = {"gar_inf_temple_vanguard", 16}
            }
        }
    )
    SetTeamName(1, "Empire")
    SetTeamName(2, "Gungans")
    ClearWalkers()
    AddWalkerType(1, 0)
    SetMemoryPoolSize("EntityHover", 4)
    SetMemoryPoolSize("MountedTurret", 16)
    SetMemoryPoolSize("PathNode", 300)
    SetMemoryPoolSize("PassengerSlot", 0)
    SetMemoryPoolSize("TreeGridStack", 400)
    SetMemoryPoolSize("Ordnance", 50)
    SetMemoryPoolSize("ParticleEmitter", 300)
    SetMemoryPoolSize("ParticleEmitterObject", 128)
    SetMemoryPoolSize("ParticleEmitterInfoData", 512)
    SetMemoryPoolSize("Obstacle", 450)
    SetSpawnDelay(10, 0.25)
    ReadDataFile("NAB\\nab2.lvl", "naboo2_hunt")
    SetDenseEnvironment("true")
    AddDeathRegion("Water")
    AddDeathRegion("Waterfall")
    SetNumBirdTypes(1)
    SetBirdType(0, 1, "bird")
    SetBirdFlockMinHeight(-28)
    voiceSlow = OpenAudioStream("sound\\global.lvl", "all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_slow", voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl", "all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_quick", voiceQuick)
    OpenAudioStream("sound\\global.lvl", "gcw_music")
    OpenAudioStream("sound\\nab.lvl", "nab2")
    OpenAudioStream("sound\\nab.lvl", "nab2")
    OpenAudioStream("sound\\nab.lvl", "nab2_emt")
    SetBleedingVoiceOver(ALL, ALL, "all_off_com_report_us_overwhelmed", 1)
    SetBleedingVoiceOver(ALL, IMP, "all_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(IMP, ALL, "imp_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(IMP, IMP, "imp_off_com_report_us_overwhelmed", 1)
    SetLowReinforcementsVoiceOver(ALL, ALL, "all_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(ALL, IMP, "all_off_victory_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(IMP, IMP, "imp_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(IMP, ALL, "imp_off_victory_im", 0.10000000149012, 1)
    SetOutOfBoundsVoiceOver(1, "allleaving")
    SetOutOfBoundsVoiceOver(2, "impleaving")
    SetAmbientMusic(ALL, 1, "all_nab_amb_start", 0, 1)
    SetAmbientMusic(ALL, 0.89999997615814, "all_nab_amb_middle", 1, 1)
    SetAmbientMusic(ALL, 0.10000000149012, "all_nab_amb_end", 2, 1)
    SetAmbientMusic(IMP, 1, "imp_nab_amb_start", 0, 1)
    SetAmbientMusic(IMP, 0.89999997615814, "imp_nab_amb_middle", 1, 1)
    SetAmbientMusic(IMP, 0.10000000149012, "imp_nab_amb_end", 2, 1)
    SetVictoryMusic(ALL, "all_nab_amb_victory")
    SetDefeatMusic(ALL, "all_nab_amb_defeat")
    SetVictoryMusic(IMP, "imp_nab_amb_victory")
    SetDefeatMusic(IMP, "imp_nab_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    AddCameraShot(
        -0.007592000067234,
        -1.9999999949505e-006,
        -0.99997097253799,
        0.00020900000527035,
        -168.55972290039,
        -45.250122070313,
        13.399480819702
    )
    AddCameraShot(
        0.25503298640251,
        0.0037889999803156,
        -0.96681797504425,
        0.014364999718964,
        -45.806968688965,
        -47.785381317139,
        -45.429058074951
    )
    AddCameraShot(
        0.62141698598862,
        -0.11941699683666,
        -0.76041197776794,
        -0.14612799882889,
        -276.06744384766,
        -18.259653091431,
        -77.929229736328
    )
end
