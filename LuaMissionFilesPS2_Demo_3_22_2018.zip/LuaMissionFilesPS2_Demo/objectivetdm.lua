--objectivetdm.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("Objective")
ObjectiveTDM = Objective:New({  })

function Start(StartParam0)
    Objective.Start(StartParam0)
    ERROR_PROCESSING_FUNCTION = true
end

