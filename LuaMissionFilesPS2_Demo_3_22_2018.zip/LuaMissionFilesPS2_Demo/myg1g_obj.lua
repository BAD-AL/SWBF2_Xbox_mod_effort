-- myg1g_obj.lua
-- Decompiled with SWBF2CodeHelper

ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("ObjectiveAssault")
ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("MultiObjectiveContainer")
ALL = 1
IMP = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    Objective1CP = CommandPost:New({name = "CP9OBJ"})
    Objective1 = ObjectiveConquest:New({teamATT = ATT, teamDEF = DEF, text = "level.myg1.obj.c1"})
    Objective1:AddCommandPost(Objective1CP)
    Objective1.OnComplete = function(OnCompleteParam0)
        SetProperty("CP9OBJ", "SpawnPath", "cp9obj")
    end

    MainframeString = "level.myg1.obj.c2-"
    Mainframe01 = Target:New({name = "objturret1"})
    Mainframe02 = Target:New({name = "objturret2"})
    Mainframe03 = Target:New({name = "objturret3"})
    Mainframe04 = Target:New({name = "objturret4"})

    Objective2 = ObjectiveAssault:New({teamATT = ATT, teamDEF = DEF, text = "level.myg1.obj.c2"})
    Objective2:AddTarget(Mainframe01)
    Objective2:AddTarget(Mainframe02)
    Objective2:AddTarget(Mainframe03)
    Objective2:AddTarget(Mainframe04)
    Objective2.OnSingleTargetDestroyed = function(this, OnSingleTargetDestroyedParam1)
        local targets = this:GetNumSingleTargets()
        if targets > 0 then
            ShowMessageText(MainframeString .. targets + 1, 1)
        end
    end
    Objective2.OnComplete = function(OnCompleteParam0)
        ShowMessageText("level.myg1.obj.c2c", 1)
        UnlockHeroForTeam(1)
    end

    core = Target:New({name = "core"})
    Objective3 = ObjectiveAssault:New({teamATT = ATT, teamDEF = DEF, text = "level.myg1.obj.c4"})
    Objective3:AddTarget(core)
    Objective3.OnStart = function(OnStartParam0)
        PlayAnimation("gunship")
    end
    Objective3.OnComplete = function(OnCompleteParam0)
        Holocron1Spawn = GetPathPoint("codespawn", 0)
        CreateEntity("com_item_holocron", Holocron1Spawn, "holodisk")
        SetProperty("holodisk", "CarriedGeometryName", "com_icon_imperial")
    end

    Objective4 =
        ObjectiveCTF:New(
        {
            teamATT = ATT,
            teamDEF = DEF,
            captureLimit = 1,
            text = "level.myg1.obj.c5",
            showTeamPoints = false,
            AIGoalWeight = 0
        }
    )
    Objective4:AddFlag(
        {
            name = "holodisk",
            captureRegion = "droppoint",
            capRegionMarker = "rep_icon",
            capRegionMarkerScale = 3,
            mapIcon = "flag_icon",
            mapIconScale = 2
        }
    )
    objectiveSequence = MultiObjectiveContainer:New({})
    objectiveSequence:AddObjectiveSet(Objective1, Objective2)
    objectiveSequence:AddObjectiveSet(Objective3)
    objectiveSequence:AddObjectiveSet(Objective4)
    objectiveSequence:Start()
    Init("01")
    Init("02")
    Init("03")
    Init("04")
    Init("05")
    Init("06")
    Init("07")
    OnObjectRespawnName(Revived, "generator_01")
    OnObjectKillName(ShieldDied, "force_shield_01")
    OnObjectKillName(ShieldDied, "generator_01")
    OnObjectRespawnName(Revived, "generator_02")
    OnObjectKillName(ShieldDied, "force_shield_02")
    OnObjectKillName(ShieldDied, "generator_02")
    OnObjectRespawnName(Revived, "generator_03")
    OnObjectKillName(ShieldDied, "force_shield_03")
    OnObjectKillName(ShieldDied, "generator_03")
    OnObjectRespawnName(Revived, "generator_04")
    OnObjectKillName(ShieldDied, "force_shield_04")
    OnObjectKillName(ShieldDied, "generator_04")
    OnObjectRespawnName(Revived, "generator_05")
    OnObjectKillName(ShieldDied, "force_shield_05")
    OnObjectKillName(ShieldDied, "generator_05")
    OnObjectRespawnName(Revived, "generator_06")
    OnObjectKillName(ShieldDied, "force_shield_06")
    OnObjectKillName(ShieldDied, "generator_06")
    OnObjectRespawnName(Revived, "generator_07")
    OnObjectKillName(ShieldDied, "force_shield_07")
    OnObjectKillName(ShieldDied, "generator_07")
    OnObjectKillName(CoreDied, "core")
    OnObjectKillName(DestroyShield1, "force_shield_01")
    OnObjectKillName(DestroyShield2, "force_shield_02")
    OnObjectKillName(DestroyShield3, "force_shield_03")
    OnObjectKillName(DestroyShield1, "generator_01")
    OnObjectKillName(DestroyShield2, "generator_02")
    OnObjectKillName(DestroyShield3, "generator_03")
    OnObjectRespawnName(RepairShield1, "generator_01")
    OnObjectRespawnName(RepairShield2, "generator_02")
    OnObjectRespawnName(RepairShield3, "generator_03")
    EnableSPScriptedHeroes()
end

function Init(InitParam0)
    shieldName = "force_shield_" .. InitParam0
    genName = "generator_" .. InitParam0
    upAnim = "shield_up_" .. InitParam0
    downAnim = "shield_down_" .. InitParam0
    PlayShieldUp(shieldName, genName, upAnim, downAnim)
    BlockPlanningGraphArcs("shield_" .. InitParam0)
    EnableBarriers("shield_" .. InitParam0)
end

function ShieldDied(ShieldDiedParam0)
    fullName = GetEntityName(ShieldDiedParam0)
    numberStr = string.sub(fullName, -2, -1)
    shieldName = "force_shield_" .. numberStr
    genName = "generator_" .. numberStr
    upAnim = "shield_up_" .. numberStr
    downAnim = "shield_down_" .. numberStr
    PlayShieldDown(shieldName, genName, upAnim, downAnim)
    UnblockPlanningGraphArcs("shield_" .. numberStr)
    DisableBarriers("shield_" .. numberStr)
end

function Revived(RevivedParam0)
    fullName = GetEntityName(RevivedParam0)
    numberStr = string.sub(fullName, -2, -1)
    shieldName = "force_shield_" .. numberStr
    genName = "generator_" .. numberStr
    upAnim = "shield_up_" .. numberStr
    downAnim = "shield_down_" .. numberStr
    PlayShieldUp(shieldName, genName, upAnim, downAnim)
    BlockPlanningGraphArcs("shield_" .. numberStr)
    EnableBarriers("shield_" .. numberStr)
end

function PlayShieldDown(PlayShieldDownParam0, PlayShieldDownParam1, PlayShieldDownParam2, PlayShieldDownParam3)
    RespawnObject(PlayShieldDownParam0)
    KillObject(PlayShieldDownParam1)
    PauseAnimation(PlayShieldDownParam2)
    RewindAnimation(PlayShieldDownParam3)
    PlayAnimation(PlayShieldDownParam3)
end

function PlayShieldUp(PlayShieldUpParam0, PlayShieldUpParam1, PlayShieldUpParam2, PlayShieldUpParam3)
    RespawnObject(PlayShieldUpParam0)
    RespawnObject(PlayShieldUpParam1)
    PauseAnimation(PlayShieldUpParam3)
    RewindAnimation(PlayShieldUpParam2)
    PlayAnimation(PlayShieldUpParam2)
end

function DestroyShield1(DestroyShield1Param0)
    SetObjectTeam("CP2", 1)
    SetObjectTeam("CP5", 2)
    SetObjectTeam("CP6", 2)
end

function DestroyShield2(DestroyShield2Param0)
    SetObjectTeam("CP5", 1)
    SetObjectTeam("CP6", 2)
end

function DestroyShield3(DestroyShield3Param0)
    SetObjectTeam("CP4", 1)
    SetObjectTeam("CP6", 2)
end

function RepairShield1(RepairShield1Param0)
    SetObjectTeam("CP2", 2)
end

function RepairShield2(RepairShield2Param0)
    SetObjectTeam("CP5", 2)
end

function RepairShield3(RepairShield3Param0)
    SetObjectTeam("CP4", 2)
end

function ScriptInit()
    SetPS2ModelMemory(3900000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\myg.lvl;myg1gcw")
    ShowMessageText("Test- Destroy the Energy Collector", ATT)
    ShowMessageText("Test- Defend the Energy Collector", DEF)
    ReadDataFile(
        "SIDE\\all.lvl",
        "all_inf_rifleman",
        "all_inf_rocketeer",
        "all_inf_sniper",
        "all_inf_engineer",
        "all_inf_officer",
        "all_hero_luke_jedi",
        "all_inf_wookiee",
        "all_hover_combatspeeder"
    )
    ReadDataFile(
        "SIDE\\imp.lvl",
        "imp_inf_rifleman",
        "imp_inf_rocketeer",
        "imp_inf_officer",
        "imp_inf_sniper",
        "imp_inf_engineer",
        "imp_inf_dark_trooper",
        "imp_hero_bobafett",
        "imp_hover_fightertank",
        "imp_walk_atst"
    )
    ReadDataFile("SIDE\\tur.lvl", "tur_bldg_recoilless_lg")
    SetupTeams(
        {
            all = {
                team = ALL,
                units = 25,
                reinforcements = 150,
                soldier = {"all_inf_rifleman"},
                assault = {"all_inf_rocketeer"},
                engineer = {"all_inf_engineer"},
                sniper = {"all_inf_sniper"},
                officer = {"all_inf_officer"},
                special = {"all_inf_wookiee"}
            },
            imp = {
                team = IMP,
                units = 25,
                reinforcements = -1,
                soldier = {"imp_inf_rifleman"},
                assault = {"imp_inf_rocketeer"},
                engineer = {"imp_inf_engineer"},
                sniper = {"imp_inf_sniper"},
                officer = {"imp_inf_officer"},
                special = {"imp_inf_dark_trooper", 2, 5}
            }
        }
    )
    SetHeroClass(IMP, "imp_hero_bobafett")
    SetHeroClass(ALL, "all_hero_luke_jedi")
    ClearWalkers()
    AddWalkerType(1, 2)
    SetMemoryPoolSize("EntityHover", 10)
    SetMemoryPoolSize("FlagItem", 1)
    SetMemoryPoolSize("MountedTurret", 16)
    SetMemoryPoolSize("PowerupItem", 40)
    SetMemoryPoolSize("EntityMine", 30)
    SetMemoryPoolSize("EntityDroid", 12)
    SetMemoryPoolSize("Aimer", 100)
    SetMemoryPoolSize("Obstacle", 430)
    SetMemoryPoolSize("Decal", 0)
    SetMemoryPoolSize("PassengerSlot", 0)
    SetMemoryPoolSize("ParticleEmitter", 350)
    SetMemoryPoolSize("ParticleEmitterInfoData", 800)
    SetMemoryPoolSize("ParticleEmitterObject", 256)
    SetMemoryPoolSize("PathNode", 512)
    SetMemoryPoolSize("TreeGridStack", 300)
    SetMemoryPoolSize("Ordnance", 70)
    SetSpawnDelay(10, 0.25)
    ReadDataFile("myg\\myg1.lvl", "myg1_assult")
    SetDenseEnvironment("false")
    AddDeathRegion("deathregion")
    voiceSlow = OpenAudioStream("sound\\global.lvl", "all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_slow", voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl", "all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_quick", voiceQuick)
    OpenAudioStream("sound\\global.lvl", "gcw_music")
    OpenAudioStream("sound\\myg.lvl", "myg1gcw")
    OpenAudioStream("sound\\myg.lvl", "myg1gcw")
    SetOutOfBoundsVoiceOver(1, "allleaving")
    SetOutOfBoundsVoiceOver(2, "impleaving")
    SetAmbientMusic(ALL, 1, "all_myg_amb_start", 0, 1)
    SetAmbientMusic(ALL, 0.89999997615814, "all_myg_amb_middle", 1, 1)
    SetAmbientMusic(ALL, 0.10000000149012, "all_myg_amb_end", 2, 1)
    SetAmbientMusic(IMP, 1, "imp_myg_amb_start", 0, 1)
    SetAmbientMusic(IMP, 0.89999997615814, "imp_myg_amb_middle", 1, 1)
    SetAmbientMusic(IMP, 0.10000000149012, "imp_myg_amb_end", 2, 1)
    SetVictoryMusic(ALL, "all_myg_amb_victory")
    SetDefeatMusic(ALL, "all_myg_amb_defeat")
    SetVictoryMusic(IMP, "imp_myg_amb_victory")
    SetDefeatMusic(IMP, "imp_myg_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(
        0.94799000024796,
        -0.029190000146627,
        0.31680798530579,
        0.0097549995407462,
        -88.997039794922,
        14.15385055542,
        -17.227827072144
    )
    AddCameraShot(
        0.96342700719833,
        -0.26038599014282,
        -0.061110001057386,
        -0.016516000032425,
        -118.96892547607,
        39.055625915527,
        124.03238677979
    )
    AddCameraShot(
        0.73388397693634,
        -0.18114300072193,
        0.63560098409653,
        0.15688399970531,
        67.597633361816,
        39.055625915527,
        55.312774658203
    )
    AddCameraShot(
        0.0083149997517467,
        9.9999999747524e-007,
        -0.99996501207352,
        7.4000003223773e-005,
        -64.894348144531,
        5.541570186615,
        201.71109008789
    )
end
