--yav1c_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
local local_2 = 1
local local_3 = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "Bazaar" })
    cp2 = CommandPost:New({ name = "CP1" })
    cp3 = CommandPost:New({ name = "LandingZone" })
    cp4 = CommandPost:New({ name = "ReflectingPool" })
    cp5 = CommandPost:New({ name = "Temple" })
    cp6 = CommandPost:New({ name = "Tflank" })
    cp7 = CommandPost:New({ name = "ViaDuct" })
    conquest = ObjectiveConquest:New({ teamATT = local_2, teamDEF = local_3, textATT = "level.yavin1.con.att", textDEF = "level.yavin1.con.def", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)
    conquest:AddCommandPost(cp7)
    conquest:Start()
    EnableSPHeroRules()
end
local local_0 = 2
local local_1 = 1

function ScriptInit()
    StealArtistHeap(512 * 1024)
    SetPS2ModelMemory(3000000)
    ReadDataFile("ingame.lvl")
    SetTeamAggressiveness(local_0,1)
    SetTeamAggressiveness(local_1,1)
    SetMaxFlyHeight(14)
    SetMaxPlayerFlyHeight(14)
    ReadDataFile("sound\\yav.lvl;yav1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep2_rifleman","rep_inf_ep2_rocketeer","rep_inf_ep2_engineer","rep_inf_ep2_sniper","rep_inf_ep2_officer","rep_inf_ep2_jettrooper","rep_hero_macewindu","rep_hover_barcspeeder","rep_walk_oneman_atst")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka","cis_hero_darthmaul","cis_hover_aat","cis_hover_stap")
    SetupTeams({ 
        rep =         { team = local_0, units = 24, reinforcements = 200, 
          soldier =           { "rep_inf_ep2_rifleman", 10 }, 
          assault =           { "rep_inf_ep2_rocketeer", 4 }, 
          engineer =           { "rep_inf_ep2_engineer", 3 }, 
          sniper =           { "rep_inf_ep2_sniper", 2 }, 
          officer =           { "rep_inf_ep2_officer", 2 }, 
          special =           { "rep_inf_ep2_jettrooper", 3 }
         }, 
        cis =         { team = local_1, units = 24, reinforcements = 200, 
          soldier =           { "cis_inf_rifleman", 10 }, 
          assault =           { "cis_inf_rocketeer", 4 }, 
          engineer =           { "cis_inf_engineer", 3 }, 
          sniper =           { "cis_inf_sniper", 2 }, 
          officer =           { "cis_inf_officer", 2 }, 
          special =           { "cis_inf_droideka", 3 }
         }
       })
    SetHeroClass(local_1,"cis_hero_darthmaul")
    SetHeroClass(local_0,"rep_hero_macewindu")
    ClearWalkers()
    AddWalkerType(0,3)
    AddWalkerType(1,1)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",51)
    SetMemoryPoolSize("AmmoCounter",180)
    SetMemoryPoolSize("BaseHint",975)
    SetMemoryPoolSize("ConnectivityGraphFollower",47)
    SetMemoryPoolSize("EnergyBar",180)
    SetMemoryPoolSize("EntityHover",6)
    SetMemoryPoolSize("EntityLight",36)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",20)
    SetMemoryPoolSize("MountedTurret",15)
    SetMemoryPoolSize("Navigator",47)
    SetMemoryPoolSize("Obstacle",760)
    SetMemoryPoolSize("PathFollower",47)
    SetMemoryPoolSize("PathNode",128)
    SetMemoryPoolSize("RayRequest",96)
    SetMemoryPoolSize("SoundSpaceRegion",48)
    SetMemoryPoolSize("TreeGridStack",490)
    SetMemoryPoolSize("UnitAgent",47)
    SetMemoryPoolSize("UnitController",47)
    SetMemoryPoolSize("Weapon",180)
    SetSpawnDelay(10,0.25)
    ReadDataFile("YAV\\yav1.lvl","yavin1_Conquest")
    SetDenseEnvironment("false")
    SetNumBirdTypes(2)
    SetBirdType(0,1,"bird")
    SetBirdType(1,1.5,"bird2")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1_emt")
    SetOutOfBoundsVoiceOver(1,"cisleaving")
    SetOutOfBoundsVoiceOver(2,"repleaving")
    SetAmbientMusic(local_0,1,"rep_yav_amb_start",0,1)
    SetAmbientMusic(local_0,0.89999997615814,"rep_yav_amb_middle",1,1)
    SetAmbientMusic(local_0,0.10000000149012,"rep_yav_amb_end",2,1)
    SetAmbientMusic(local_1,1,"cis_yav_amb_start",0,1)
    SetAmbientMusic(local_1,0.89999997615814,"cis_yav_amb_middle",1,1)
    SetAmbientMusic(local_1,0.10000000149012,"cis_yav_amb_end",2,1)
    SetVictoryMusic(local_0,"rep_yav_amb_victory")
    SetDefeatMusic(local_0,"rep_yav_amb_defeat")
    SetVictoryMusic(local_1,"cis_yav_amb_victory")
    SetDefeatMusic(local_1,"cis_yav_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(local_2)
    AddCameraShot(0.92569398880005,-0.056832000613213,0.37327700853348,0.022917000576854,132.35606384277,-65.527252197266,-25.416561126709)
    AddCameraShot(0.36135500669479,-0.024311000481248,-0.93000900745392,-0.062568999826908,93.845817565918,-52.247051239014,-194.74313354492)
    AddCameraShot(0.93407398462296,0.077334001660347,-0.34741699695587,0.028764000162482,102.66004943848,-30.127220153809,-335.16714477539)
end

