--kas2g_hunt.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("Objective")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    hunt = Objective:New({text = "level.geo1.objectives.hunt"})
    hunt.OnStart = function(OnStartParam0)
        AddAIGoal(ATT, "Deathmatch", 1000)
        AddAIGoal(DEF, "Deathmatch", 1000)
    end

    hunt_timer = CreateTimer("hunt_timer")
    SetTimerValue(hunt_timer, 300)
    StartTimer(hunt_timer)
    victory =
        OnTimerElapse(
        function(hunt_timerParam0)
            MissionVictory(ATT)
            ReleaseTimerElapse(victory)
        end,
        hunt_timer
    )
    ShowTimer(hunt_timer)
    hunt:Start()
    EnableSPHeroRules()
    BlockPlanningGraphArcs("seawall1")
    OnObjectKillName(PlayAnimDown, "gatepanel")
end

function PlayAnimDown()
    PlayAnimation("thegatedown")
    UnblockPlanningGraphArcs("seawall1")
    DisableBarriers("seawalldoor1")
    DisableBarriers("vehicleblocker")
end

function ScriptInit()
    SetPS2ModelMemory(3720000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(70)
    ReadDataFile("sound\\kas.lvl;kas2cw")
    ReadDataFile("SIDE\\rep.lvl", "rep_fly_cat_dome")
    ReadDataFile("SIDE\\wok.lvl", "wok_inf_basic")
    ReadDataFile("SIDE\\imp.lvl", "imp_inf_officer")
    ReadDataFile("SIDE\\cis.lvl", "cis_fly_gunship_dome")
    ReadDataFile("SIDE\\tur.lvl", "tur_bldg_recoilless_lg")
    SetupTeams(
        {
            rep = {
                team = REP,
                units = 25,
                reinforcements = -1,
                sniper = {"imp_inf_officer", 1}
            },
            cis = {
                team = CIS,
                units = 25,
                reinforcements = -1,
                soldier = {"wok_inf_mechanic", 5},
                engineer = {"wok_inf_warrior", 20}
            }
        }
    )
    SetTeamName(1, "Empire")
    SetTeamName(2, "Wookiees")
    SetHeroClass(REP, "rep_hero_yoda")
    SetHeroClass(CIS, "cis_hero_jangofett")
    ClearWalkers()
    AddWalkerType(0, 8)
    AddWalkerType(1, 0)
    AddWalkerType(2, 2)
    AddWalkerType(3, 0)
    SetMemoryPoolSize("CommandHover", 0)
    SetMemoryPoolSize("MountedTurret", 20)
    SetMemoryPoolSize("EntityHover", 15)
    SetMemoryPoolSize("EntityCarrier", 0)
    SetMemoryPoolSize("EntityBuildingArmedDynamic", 0)
    SetMemoryPoolSize("EntityDroid", 8)
    SetMemoryPoolSize("EntityLight", 60)
    SetMemoryPoolSize("PowerupItem", 30)
    SetMemoryPoolSize("EntityMine", 30)
    SetMemoryPoolSize("Aimer", 100)
    SetMemoryPoolSize("Obstacle", 590)
    SetMemoryPoolSize("BaseHint", 50)
    SetMemoryPoolSize("TreeGridStack", 300)
    SetMemoryPoolSize("Weapon", 265)
    SetMemoryPoolSize("Ordnance", 100)
    SetMemoryPoolSize("PathNode", 512)
    SetMemoryPoolSize("ParticleEmitter", 512)
    SetMemoryPoolSize("ParticleEmitterInfoData", 512)
    SetMemoryPoolSize("PassengerSlot", 0)
    SetSpawnDelay(10, 0.25)
    ReadDataFile("KAS\\kas2.lvl", "kas2_tdm")
    SetDenseEnvironment("false")
    SetNumBirdTypes(1)
    SetBirdType(0, 1, "bird")
    SetNumFishTypes(1)
    SetFishType(0, 0.80000001192093, "fish")
    musicStream = OpenAudioStream("sound\\global.lvl", "rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "cis_unit_vo_slow", musicStream)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", musicStream)
    OpenAudioStream("sound\\global.lvl", "cw_music")
    OpenAudioStream("sound\\kas.lvl", "kas")
    OpenAudioStream("sound\\kas.lvl", "kas")
    SetAmbientMusic(REP, 1, "rep_kas_amb_start", 0, 1)
    SetAmbientMusic(REP, 0.99000000953674, "rep_kas_amb_middle", 1, 1)
    SetAmbientMusic(REP, 0.10000000149012, "rep_kas_amb_end", 2, 1)
    SetAmbientMusic(CIS, 1, "cis_kas_amb_start", 0, 1)
    SetAmbientMusic(CIS, 0.99000000953674, "cis_kas_amb_middle", 1, 1)
    SetAmbientMusic(CIS, 0.10000000149012, "cis_kas_amb_end", 2, 1)
    SetVictoryMusic(REP, "rep_kas_amb_victory")
    SetDefeatMusic(REP, "rep_kas_amb_defeat")
    SetVictoryMusic(CIS, "cis_kas_amb_victory")
    SetDefeatMusic(CIS, "cis_kas_amb_defeat")
    SetOutOfBoundsVoiceOver(1, "repleaving")
    SetOutOfBoundsVoiceOver(2, "cisleaving")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(
        0.99366897344589,
        -0.09961000084877,
        -0.051708001643419,
        -0.0051830001175404,
        109.47354888916,
        34.506076812744,
        272.88922119141
    )
    AddCameraShot(
        -0.13082699477673,
        0.02471400052309,
        -0.97387301921844,
        -0.18396799266338,
        146.41287231445,
        60.191699981689,
        -191.87882995605
    )
    AddCameraShot(
        0.94083100557327,
        -0.10825499892235,
        -0.31901299953461,
        -0.036706998944283,
        -65.793930053711,
        66.455177307129,
        289.43267822266
    )
    AddCameraShot(
        0.52312701940536,
        -0.055344998836517,
        -0.84573602676392,
        -0.089475996792316,
        -170.51907348633,
        66.455177307129,
        -248.87753295898
    )
end
