--end1g_hunt.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("Objective")
ALL = 2
IMP = 1
ATT = 1
DEF = 2

function ScriptPostLoad()
    hunt = Objective:New({text = "level.end1.objectives.hunt"})

    hunt.OnStart = function(OnStartParam0)
        AddAIGoal(ATT, "Deathmatch", 1000)
        AddAIGoal(DEF, "Deathmatch", 1000)
    end

    hunt_timer = CreateTimer("hunt_timer")
    SetTimerValue(hunt_timer, 300)
    StartTimer(hunt_timer)
    victory =
        OnTimerElapse(
        function(hunt_timerParam0)
            MissionVictory(ATT)
            ReleaseTimerElapse(victory)
        end,
        hunt_timer
    )
    ShowTimer(hunt_timer)
    hunt:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(2860000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\end.lvl;end1gcw")
    SetTeamAggressiveness(ALL, 1)
    SetTeamAggressiveness(IMP, 0.69999998807907)
    SetMaxFlyHeight(43)
    SetMaxPlayerFlyHeight(43)
    ReadDataFile("SIDE\\all.lvl", "all_inf_rifleman_jungle")
    ReadDataFile("SIDE\\imp.lvl", "imp_inf_sniper")
    ReadDataFile("SIDE\\ewk.lvl", "ewk_inf_basic")
    SetUnitCount(ATT, 22)
    SetReinforcementCount(ATT, -1)
    SetUnitCount(DEF, 24)
    SetReinforcementCount(DEF, -1)
    SetTeamName(ALL, "Ewoks")
    SetTeamIcon(ALL, "all_icon")
    AddUnitClass(ALL, "ewk_inf_trooper", 8)
    AddUnitClass(ALL, "ewk_inf_repair", 8)
    AddUnitClass(ALL, "ewk_inf_scout", 8)
    SetTeamName(IMP, "Empire")
    SetTeamIcon(IMP, "imp_icon")
    AddUnitClass(IMP, "imp_inf_sniper", 1)
    AddAIGoal(1, "Conquest", 100)
    AddAIGoal(2, "Conquest", 100)
    AddAIGoal(3, "Conquest", 100)
    ClearWalkers()
    AddWalkerType(0, 0)
    AddWalkerType(1, 3)
    AddWalkerType(2, 0)
    AddWalkerType(3, 0)
    SetMemoryPoolSize("ActiveRegion", 4)
    SetMemoryPoolSize("Aimer", 24)
    SetMemoryPoolSize("AmmoCounter", 211)
    SetMemoryPoolSize("BaseHint", 225)
    SetMemoryPoolSize("Combo::DamageSample", 64)
    SetMemoryPoolSize("EnergyBar", 211)
    SetMemoryPoolSize("EntityCarrier", 0)
    SetMemoryPoolSize("EntityDefenseGridTurret", 4)
    SetMemoryPoolSize("EntityDroid", 2)
    SetMemoryPoolSize("EntityFlyer", 0)
    SetMemoryPoolSize("EntityHover", 9)
    SetMemoryPoolSize("EntityLight", 20)
    SetMemoryPoolSize("EntityMine", 8)
    SetMemoryPoolSize("EntityPortableTurret", 4)
    SetMemoryPoolSize("EntitySoundStream", 4)
    SetMemoryPoolSize("EntitySoundStatic", 95)
    SetMemoryPoolSize("LightFlash", 6)
    SetMemoryPoolSize("LightningBoltEffectObject", 3)
    SetMemoryPoolSize("MountedTurret", 3)
    SetMemoryPoolSize("Navigator", 59)
    SetMemoryPoolSize("Obstacle", 745)
    SetMemoryPoolSize("Ordnance", 40)
    SetMemoryPoolSize("ParticleEmitter", 600)
    SetMemoryPoolSize("ParticleEmitterInfoData", 312)
    SetMemoryPoolSize("ParticleEmitterObject", 144)
    SetMemoryPoolSize("PathFollower", 59)
    SetMemoryPoolSize("PathNode", 100)
    SetMemoryPoolSize("PowerupItem", 16)
    SetMemoryPoolSize("RayRequest", 96)
    SetMemoryPoolSize("SoundSpaceRegion", 6)
    SetMemoryPoolSize("StickInfo", 20)
    SetMemoryPoolSize("TreeGridStack", 505)
    SetMemoryPoolSize("UnitAgent", 59)
    SetMemoryPoolSize("UnitController", 59)
    SetMemoryPoolSize("Weapon", 211)
    SetSpawnDelay(10, 0.25)
    ReadDataFile("end\\end1.lvl", "end1_hunt")
    SetDenseEnvironment("true")
    AddDeathRegion("deathregion")
    SetStayInTurrets(1)
    voiceSlow = OpenAudioStream("sound\\global.lvl", "all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_slow", voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl", "all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl", "imp_unit_vo_quick", voiceQuick)
    OpenAudioStream("sound\\global.lvl", "gcw_music")
    OpenAudioStream("sound\\end.lvl", "end1gcw")
    OpenAudioStream("sound\\end.lvl", "end1gcw")
    OpenAudioStream("sound\\end.lvl", "end1gcw_emt")
    SetOutOfBoundsVoiceOver(1, "allleaving")
    SetOutOfBoundsVoiceOver(2, "impleaving")
    SetAmbientMusic(ALL, 1, "all_end_amb_start", 0, 1)
    SetAmbientMusic(ALL, 0.89999997615814, "all_end_amb_middle", 1, 1)
    SetAmbientMusic(ALL, 0.10000000149012, "all_end_amb_end", 2, 1)
    SetAmbientMusic(IMP, 1, "imp_end_amb_start", 0, 1)
    SetAmbientMusic(IMP, 0.89999997615814, "imp_end_amb_middle", 1, 1)
    SetAmbientMusic(IMP, 0.10000000149012, "imp_end_amb_end", 2, 1)
    SetVictoryMusic(ALL, "all_end_amb_victory")
    SetDefeatMusic(ALL, "all_end_amb_defeat")
    SetVictoryMusic(IMP, "imp_end_amb_victory")
    SetDefeatMusic(IMP, "imp_end_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(
        0.99765402078629,
        0.066982001066208,
        0.014139000326395,
        -0.00094900000840425,
        155.1371307373,
        0.91150498390198,
        -138.07707214355
    )
    AddCameraShot(
        0.72976100444794,
        0.019262000918388,
        0.68319398164749,
        -0.018032999709249,
        -98.584869384766,
        0.29528400301933,
        263.23928833008
    )
    AddCameraShot(
        0.69427698850632,
        0.0051000001840293,
        0.71967101097107,
        -0.0052869999781251,
        -11.105946540833,
        -2.7532069683075,
        67.982200622559
    )
end
