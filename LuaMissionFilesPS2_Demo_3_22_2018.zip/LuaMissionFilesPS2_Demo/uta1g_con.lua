--uta1g_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
local local_2 = 1
local local_3 = 2

function ScriptPostLoad()
    EnableSPHeroRules()
    cp1 = CommandPost:New({ name = "CON_CP1" })
    cp2 = CommandPost:New({ name = "con_CP1a" })
    cp3 = CommandPost:New({ name = "CON_CP2" })
    cp4 = CommandPost:New({ name = "CON_CP5" })
    cp5 = CommandPost:New({ name = "CON_CP6" })
    conquest = ObjectiveConquest:New({ teamATT = local_2, teamDEF = local_3, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:Start()
end
local local_0 = 1
local local_1 = 2

function ScriptInit()
    SetPS2ModelMemory(4880000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\uta.lvl;uta1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_inf_officer","all_inf_wookiee","all_hero_hansolo_tat","all_hover_combatspeeder")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_bobafett","imp_fly_destroyer_dome","imp_hover_fightertank")
    SetupTeams({ 
        all =         { team = local_0, units = 20, reinforcements = 200, 
          soldier =           { "all_inf_rifleman", 8 }, 
          assault =           { "all_inf_rocketeer", 3 }, 
          engineer =           { "all_inf_engineer", 4 }, 
          sniper =           { "all_inf_sniper", 2 }, 
          officer =           { "all_inf_officer", 1 }, 
          special =           { "all_inf_wookiee", 2 }
         }
       })
    SetupTeams({ 
        imp =         { team = local_1, units = 20, reinforcements = 200, 
          soldier =           { "imp_inf_rifleman", 8 }, 
          assault =           { "imp_inf_rocketeer", 3 }, 
          engineer =           { "imp_inf_engineer", 4 }, 
          sniper =           { "imp_inf_sniper", 2 }, 
          officer =           { "imp_inf_officer", 1 }, 
          special =           { "imp_inf_dark_trooper", 2 }
         }
       })
    SetHeroClass(local_1,"imp_hero_bobafett")
    SetHeroClass(local_0,"all_hero_hansolo_tat")
    ClearWalkers()
    SetMemoryPoolSize("EntityHover",4)
    SetMemoryPoolSize("EntityLight",80)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("Weapon",260)
    ReadDataFile("uta\\uta1.lvl","uta1_Conquest")
    SetDenseEnvironment("false")
    AddDeathRegion("deathregion")
    SetMaxFlyHeight(29.5)
    SetMaxPlayerFlyHeight(29.5)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\uta.lvl","uta1")
    OpenAudioStream("sound\\uta.lvl","uta1")
    SetBleedingVoiceOver(local_0,local_0,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(local_0,local_1,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_0,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(local_1,local_1,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(local_0,local_0,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_0,local_1,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_1,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(local_1,local_0,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(local_0,1,"all_uta_amb_start",0,1)
    SetAmbientMusic(local_0,0.89999997615814,"all_uta_amb_middle",1,1)
    SetAmbientMusic(local_0,0.10000000149012,"all_uta_amb_end",2,1)
    SetAmbientMusic(local_1,1,"imp_uta_amb_start",0,1)
    SetAmbientMusic(local_1,0.89999997615814,"imp_uta_amb_middle",1,1)
    SetAmbientMusic(local_1,0.10000000149012,"imp_uta_amb_end",2,1)
    SetVictoryMusic(local_0,"all_uta_amb_victory")
    SetDefeatMusic(local_0,"all_uta_amb_defeat")
    SetVictoryMusic(local_1,"imp_uta_amb_victory")
    SetDefeatMusic(local_1,"imp_uta_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.42809098958969,0.045648999512196,-0.89749401807785,-0.09570299834013,162.71495056152,45.857063293457,40.647117614746)
end

