--nab2g_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("setup_teams")
ATT = 1
DEF = 2
ALL = ATT
IMP = DEF

function ScriptPostLoad()
    ctf = ObjectiveOneFlagCTF:New({ teamATT = 1, teamDEF = 2, textATT = "level.naboo2.1flag.att", textDEF = "level.naboo2.1flag.def", captureLimit = 5, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "HomeRegion", captureRegionATT = "Team1Capture", captureRegionDEF = "Team2Capture", capRegionMarkerATT = "listbox_cursor", capRegionMarkerDEF = "listbox_cursor", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(2097152 + 65536 * 10)
    ReadDataFile("ingame.lvl")
    ATT = 1
    DEF = 2
    ALL = ATT
    IMP = DEF
    SetMapNorthAngle(0)
    ReadDataFile("sound\\nab.lvl;nab2gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_engineer","all_inf_sniper","all_inf_officer","all_inf_wookiee","all_hero_leia","all_hover_combatspeeder")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_emperor","imp_hover_fightertank")
    SetupTeams({ 
        imp =         { team = IMP, units = 25, reinforcements = 200, 
          soldier =           { "imp_inf_rifleman", 11 }, 
          assault =           { "imp_inf_rocketeer", 4 }, 
          engineer =           { "imp_inf_engineer", 3 }, 
          sniper =           { "imp_inf_sniper", 2 }, 
          officer =           { "imp_inf_officer", 2 }, 
          special =           { "imp_inf_dark_trooper", 3 }
         }, 
        all =         { team = ALL, units = 25, reinforcements = 200, 
          soldier =           { "all_inf_rifleman", 11 }, 
          assault =           { "all_inf_rocketeer", 4 }, 
          engineer =           { "all_inf_engineer", 3 }, 
          sniper =           { "all_inf_sniper", 2 }, 
          officer =           { "all_inf_officer", 2 }, 
          special =           { "all_inf_wookiee", 3 }
         }
       })
    SetHeroClass(ALL,"all_hero_leia")
    SetHeroClass(IMP,"imp_hero_emperor")
    ClearWalkers()
    AddWalkerType(1,0)
    SetMemoryPoolSize("EntityHover",4)
    SetMemoryPoolSize("MountedTurret",16)
    SetMemoryPoolSize("PathNode",300)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("TreeGridStack",400)
    SetMemoryPoolSize("Ordnance",50)
    SetMemoryPoolSize("ParticleEmitter",300)
    SetMemoryPoolSize("ParticleEmitterObject",128)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("Obstacle",450)
    SetMemoryPoolSize("FlagItem",2)
    SetSpawnDelay(10,0.25)
    ReadDataFile("NAB\\nab2.lvl","naboo2_1Flag")
    SetDenseEnvironment("true")
    AddDeathRegion("Water")
    AddDeathRegion("Waterfall")
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    SetBirdFlockMinHeight(-28)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\nab.lvl","nab2")
    OpenAudioStream("sound\\nab.lvl","nab2")
    OpenAudioStream("sound\\nab.lvl","nab2_emt")
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"all_nab_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_nab_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_nab_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_nab_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_nab_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_nab_amb_end",2,1)
    SetVictoryMusic(ALL,"all_nab_amb_victory")
    SetDefeatMusic(ALL,"all_nab_amb_defeat")
    SetVictoryMusic(IMP,"imp_nab_amb_victory")
    SetDefeatMusic(IMP,"imp_nab_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.007592000067234,-1.9999999949505e-006,-0.99997097253799,0.00020900000527035,-168.55972290039,-45.250122070313,13.399480819702)
    AddCameraShot(0.25503298640251,0.0037889999803156,-0.96681797504425,0.014364999718964,-45.806968688965,-47.785381317139,-45.429058074951)
    AddCameraShot(0.62141698598862,-0.11941699683666,-0.76041197776794,-0.14612799882889,-276.06744384766,-18.259653091431,-77.929229736328)
end

