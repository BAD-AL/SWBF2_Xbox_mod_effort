--spa8g_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("spa8g_cmn")
myGameMode = "spa8_ctf"

function myScriptInit()
    SetMemoryPoolSize("FlagItem",2)
end

function ScriptPostLoad()
    SetProperty("imp_flag","GeometryName","com_icon_imperial_flag")
    SetProperty("imp_flag","CarriedGeometryName","com_icon_imperial_flag")
    SetProperty("all_flag","GeometryName","com_icon_alliance")
    SetProperty("all_flag","CarriedGeometryName","com_icon_alliance_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = IMP, teamDEF = ALL, captureLimit = 10, text = "game.modes.ctf", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "all_flag", homeRegion = "ctf_all_home", captureRegion = "ctf_imp_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3, AIGoalWeight = 0 })
    ctf:AddFlag({ name = "imp_flag", homeRegion = "ctf_imp_home", captureRegion = "ctf_all_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3, AIGoalWeight = 0 })
    ctf:Start()
    AddAIGoal(ATT,"Attack",5000,"all_flag")
    AddAIGoal(ATT,"Defend",3000,"imp_flag")
    AddAIGoal(DEF,"Attack",5000,"imp_flag")
    AddAIGoal(DEF,"Defend",3000,"all_flag")
    LockHangarWarsDoors()
end

