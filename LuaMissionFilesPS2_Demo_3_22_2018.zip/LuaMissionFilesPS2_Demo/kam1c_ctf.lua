--kam1c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")
local local_2 = 1
local local_3 = 2

function ScriptPostLoad()
    SetProperty("cp1","CaptureRegion","DEATH")
    SetProperty("cp2","CaptureRegion","DEATH")
    SetProperty("cp3","CaptureRegion","DEATH")
    SetProperty("cp4","CaptureRegion","DEATH")
    SetProperty("cp5","CaptureRegion","DEATH")
    SetProperty("cp2","SpawnPath","cp2_spawn")
    UnblockPlanningGraphArcs("connection71")
    UnblockPlanningGraphArcs("connection85")
    UnblockPlanningGraphArcs("connection48")
    UnblockPlanningGraphArcs("connection63")
    UnblockPlanningGraphArcs("connection59")
    UnblockPlanningGraphArcs("close")
    UnblockPlanningGraphArcs("open")
    EnableBarriers("frog")
    EnableBarriers("close")
    EnableBarriers("open")
    UnblockPlanningGraphArcs("connection194")
    UnblockPlanningGraphArcs("connection200")
    UnblockPlanningGraphArcs("connection118")
    EnableBarriers("frontdoor2-3")
    EnableBarriers("frontdoor2-1")
    EnableBarriers("frontdoor2-2")
    UnblockPlanningGraphArcs("connection10")
    UnblockPlanningGraphArcs("connection159")
    UnblockPlanningGraphArcs("connection31")
    EnableBarriers("frontdoor1-3")
    EnableBarriers("frontdoor1-1")
    EnableBarriers("frontdoor1-2")
    SetProperty("flag1","GeometryName","com_icon_republic_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_republic_flag")
    SetProperty("flag2","GeometryName","com_icon_cis_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_cis_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = local_2, teamDEF = local_3, captureLimit = 8, textATT = "game.mode.ctf", textDEF = "game.mode.ctf2", multiplayerRules = true, hideCPs = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag1_home", captureRegion = "FLAG2_HOME", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "FLAG2_HOME", captureRegion = "flag1_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end
local local_0 = 2
local local_1 = 1

function ScriptInit()
    SetPS2ModelMemory(3000000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\kam.lvl;kam1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_jettrooper","rep_hero_macewindu","rep_inf_ep3_officer")
    ReadDataFile("SIDE\\CIS.lvl","CIS_fly_fedlander_dome","CIS_inf_rifleman","CIS_inf_rocketeer","CIS_inf_engineer","CIS_inf_sniper","CIS_hero_jangofett","CIS_inf_droideka","CIS_inf_officer")
    SetAttackingTeam(local_2)
    SetupTeams({ 
        rep =         { team = local_0, units = 25, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman" }, 
          assault =           { "rep_inf_ep3_rocketeer" }, 
          engineer =           { "rep_inf_ep3_engineer" }, 
          sniper =           { "rep_inf_ep3_sniper" }, 
          officer =           { "rep_inf_ep3_officer" }, 
          special =           { "rep_inf_ep3_jettrooper" }
         }, 
        CIS =         { team = local_1, units = 25, reinforcements = -1, 
          soldier =           { "CIS_inf_rifleman" }, 
          assault =           { "CIS_inf_rocketeer" }, 
          engineer =           { "CIS_inf_engineer" }, 
          sniper =           { "CIS_inf_sniper" }, 
          officer =           { "CIS_inf_officer" }, 
          special =           { "CIS_inf_droideka" }
         }
       })
    SetHeroClass(local_0,"rep_hero_macewindu")
    SetHeroClass(local_1,"CIS_hero_jangofett")
    ClearWalkers()
    AddWalkerType(0,16)
    SetMemoryPoolSize("EntityLight",64)
    SetSpawnDelay(10,0.25)
    SetMemoryPoolSize("FlagItem",2)
    SetDenseEnvironment("false")
    ReadDataFile("KAM\\kam1.lvl","kamino1_CTF")
    SetMinFlyHeight(60)
    SetMaxFlyHeight(140)
    SetAllowBlindJetJumps(0)
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\kam.lvl","kam1")
    OpenAudioStream("sound\\kam.lvl","kam1")
    SetAmbientMusic(local_0,1,"rep_kam_amb_start",0,1)
    SetAmbientMusic(local_0,0.89999997615814,"rep_kam_amb_middle",1,1)
    SetAmbientMusic(local_0,0.10000000149012,"rep_kam_amb_end",2,1)
    SetAmbientMusic(local_1,1,"CIS_kam_amb_start",0,1)
    SetAmbientMusic(local_1,0.89999997615814,"CIS_kam_amb_middle",1,1)
    SetAmbientMusic(local_1,0.10000000149012,"CIS_kam_amb_end",2,1)
    SetVictoryMusic(local_0,"rep_kam_amb_victory")
    SetDefeatMusic(local_0,"rep_kam_amb_defeat")
    SetVictoryMusic(local_1,"CIS_kam_amb_victory")
    SetDefeatMusic(local_1,"CIS_kam_amb_defeat")
    SetOutOfBoundsVoiceOver(2,"repleaving")
    SetOutOfBoundsVoiceOver(1,"CISleaving")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(local_2)
    AddDeathRegion("DeathRegion")
    AddCameraShot(0.19047799706459,-0.010944999754429,-0.98001402616501,-0.056311998516321,-26.091287612915,55.96501159668,159.45809936523)
    AddCameraShot(-0.37657099962234,-0.019636999815702,-0.92492300271988,0.04823200032115,176.04246520996,53.957565307617,244.26113891602)
    AddCameraShot(0.63925397396088,-0.073532998561859,0.76045697927475,0.087475001811981,78.395347595215,72.538581848145,344.08660888672)
end

