--tan1c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
ATT = 1
DEF = 2
REP = ATT
CIS = DEF

function ScriptPostLoad()
    SetProperty("flag1","GeometryName","com_icon_republic_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_republic_flag")
    SetProperty("flag2","GeometryName","com_icon_cis_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_cis_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 8, textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag1_home", captureRegion = "flag2_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag2_home", captureRegion = "flag1_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4800000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\tan.lvl;tan1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_jettrooper","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_hero_yoda")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka","cis_hero_grievous")
    SetupTeams({ 
        rep =         { team = REP, units = 18, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman" }, 
          assault =           { "rep_inf_ep3_rocketeer" }, 
          engineer =           { "rep_inf_ep3_engineer" }, 
          sniper =           { "rep_inf_ep3_sniper" }, 
          officer =           { "rep_inf_ep3_officer" }, 
          special =           { "rep_inf_ep3_jettrooper" }
         }, 
        cis =         { team = CIS, units = 18, reinforcements = -1, 
          soldier =           { "cis_inf_rifleman" }, 
          assault =           { "cis_inf_rocketeer" }, 
          engineer =           { "cis_inf_engineer" }, 
          sniper =           { "cis_inf_sniper" }, 
          officer =           { "cis_inf_officer" }, 
          special =           { "cis_inf_droideka", 1, 4 }
         }
       })
    SetHeroClass(REP,"rep_hero_yoda")
    SetHeroClass(CIS,"cis_hero_grievous")
    ClearWalkers()
    AddWalkerType(0,3)
    SetMemoryPoolSize("Aimer",9)
    SetMemoryPoolSize("EntityMine",40)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("MountedTurret",0)
    SetMemoryPoolSize("SoundspaceRegion",15)
    SetMemoryPoolSize("PowerupItem",60)
    SetMemoryPoolSize("TreeGridStack",256)
    SetMemoryPoolSize("Weapon",128)
    SetSpawnDelay(10,0.25)
    ReadDataFile("tan\\tan1.lvl","tan1_ctf")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\tan.lvl","tan1")
    OpenAudioStream("sound\\tan.lvl","tan1")
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_tan_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_tan_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_tan_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_tan_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_tan_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_tan_amb_end",2,1)
    SetVictoryMusic(REP,"rep_tan_amb_victory")
    SetDefeatMusic(REP,"rep_tan_amb_defeat")
    SetVictoryMusic(CIS,"cis_tan_amb_victory")
    SetDefeatMusic(CIS,"cis_tan_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.23319900035858,-0.019440999254584,-0.96887397766113,-0.080770999193192,-240.75592041016,11.457644462585,105.94417572021)
    AddCameraShot(-0.39556100964546,0.079428002238274,-0.89709198474884,-0.18013499677181,-264.02227783203,6.7458729743958,122.71575164795)
    AddCameraShot(0.54670298099518,-0.041547000408173,-0.83389097452164,-0.063371002674103,-309.70989990234,5.1683039665222,145.33438110352)
end

