--kam1g_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ATT = 1
DEF = 2
IMP = ATT
ALL = DEF

function ScriptPostLoad()
    SetProperty("cp1","CaptureRegion","DEATH")
    SetProperty("cp2","CaptureRegion","DEATH")
    SetProperty("cp3","CaptureRegion","DEATH")
    SetProperty("cp4","CaptureRegion","DEATH")
    SetProperty("cp5","CaptureRegion","DEATH")
    SetProperty("cp2","SpawnPath","cp2_spawn")
    UnblockPlanningGraphArcs("connection71")
    UnblockPlanningGraphArcs("connection85")
    UnblockPlanningGraphArcs("connection48")
    UnblockPlanningGraphArcs("connection63")
    UnblockPlanningGraphArcs("connection59")
    UnblockPlanningGraphArcs("close")
    UnblockPlanningGraphArcs("open")
    EnableBarriers("frog")
    EnableBarriers("close")
    EnableBarriers("open")
    UnblockPlanningGraphArcs("connection194")
    UnblockPlanningGraphArcs("connection200")
    UnblockPlanningGraphArcs("connection118")
    EnableBarriers("frontdoor2-3")
    EnableBarriers("frontdoor2-1")
    EnableBarriers("frontdoor2-2")
    UnblockPlanningGraphArcs("connection10")
    UnblockPlanningGraphArcs("connection159")
    UnblockPlanningGraphArcs("connection31")
    EnableBarriers("frontdoor1-3")
    EnableBarriers("frontdoor1-1")
    EnableBarriers("frontdoor1-2")
    SetProperty("flag1","GeometryName","com_icon_alliance")
    SetProperty("flag1","CarriedGeometryName","com_icon_alliance")
    SetProperty("flag2","GeometryName","com_icon_imperial")
    SetProperty("flag2","CarriedGeometryName","com_icon_imperial")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveOneFlagCTF:New({ teamATT = 1, teamDEF = 2, textATT = "game.mode.1flag", textDEF = "game.mode.1flag2", captureLimit = 8, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "flag_home", captureRegionATT = "lag_capture2", captureRegionDEF = "lag_capture1", capRegionMarkerATT = "hud_objective_icon", capRegionMarkerDEF = "hud_objective_icon", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3, hideCPs = true, multiplayerRules = true })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(3400000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\kam.lvl;kam1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_hero_hansolo_tat","all_inf_wookiee","all_inf_officer")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_dark_trooper","imp_hero_bobafett","imp_inf_officer")
    ClearWalkers()
    SetMemoryPoolSize("EntityHover",0)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("Obstacle",250)
    SetMemoryPoolSize("Weapon",260)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("EntitySoundStatic",175)
    SetMemoryPoolSize("EntityLight",64)
    SetupTeams({ 
        all =         { team = ALL, units = 25, reinforcements = -1, 
          soldier =           { "all_inf_rifleman" }, 
          assault =           { "all_inf_rocketeer" }, 
          engineer =           { "all_inf_engineer" }, 
          sniper =           { "all_inf_sniper" }, 
          officer =           { "all_inf_officer" }, 
          special =           { "all_inf_wookiee" }
         }
       })
    SetupTeams({ 
        imp =         { team = IMP, units = 25, reinforcements = -1, 
          soldier =           { "imp_inf_rifleman" }, 
          assault =           { "imp_inf_rocketeer" }, 
          engineer =           { "imp_inf_engineer" }, 
          sniper =           { "imp_inf_sniper" }, 
          officer =           { "imp_inf_officer" }, 
          special =           { "imp_inf_dark_trooper" }
         }
       })
    SetHeroClass(ALL,"all_hero_hansolo_tat")
    SetHeroClass(IMP,"imp_hero_bobafett")
    SetSpawnDelay(10,0.25)
    SetMemoryPoolSize("FlagItem",2)
    ReadDataFile("KAM\\kam1.lvl","KAMINO1_1ctf")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\kam.lvl","kam1")
    OpenAudioStream("sound\\kam.lvl","kam1")
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"all_mus_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_mus_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_mus_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_mus_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_mus_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_mus_amb_end",2,1)
    SetVictoryMusic(ALL,"all_mus_amb_victory")
    SetDefeatMusic(ALL,"all_mus_amb_defeat")
    SetVictoryMusic(IMP,"imp_mus_amb_victory")
    SetDefeatMusic(IMP,"imp_mus_amb_defeat")
    SetAttackingTeam(ATT)
    AddCameraShot(0.99765402078629,0.066982001066208,0.014139000326395,-0.00094900000840425,155.1371307373,0.91150498390198,-138.07707214355)
    AddCameraShot(0.72976100444794,0.019262000918388,0.68319398164749,-0.018032999709249,-98.584869384766,0.29528400301933,263.23928833008)
    AddCameraShot(0.69427698850632,0.0051000001840293,0.71967101097107,-0.0052869999781251,-11.105946540833,-2.7532069683075,67.982200622559)
end

