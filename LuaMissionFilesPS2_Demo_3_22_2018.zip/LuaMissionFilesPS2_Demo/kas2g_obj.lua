--kas2g_obj.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
ALL = 2
IMP = 1
ATT = 1
DEF = 2

function ScriptPostLoad()
    EnableSPHeroRules()
    cp1 = CommandPost:New({ name = "CP1" })
    cp2 = CommandPost:New({ name = "CP2" })
    cp3 = CommandPost:New({ name = "CP3" })
    cp5 = CommandPost:New({ name = "CP5" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, text = "level.kas2.con" })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp5)
    BlockPlanningGraphArcs("seawall1")
    OnObjectKillName(PlayAnimDown,"gatepanel")
end

function PlayAnimDown()
    PlayAnimation("thegatedown")
    UnblockPlanningGraphArcs("seawall1")
    DisableBarriers("seawalldoor1")
    DisableBarriers("vehicleblocker")
end

function ScriptInit()
    SetPS2ModelMemory(3550000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(70)
    ReadDataFile("sound\\kas.lvl;kas2gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_jungle","all_inf_rocketeer_jungle","all_inf_sniper_jungle","all_inf_engineer","all_inf_officer","all_hero_chewbacca","all_inf_wookiee")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_dark_trooper","imp_inf_officer","imp_walk_atst","imp_hero_bobafett")
    ReadDataFile("SIDE\\wok.lvl","wok_inf_basic")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_recoilless_lg")
    SetupTeams({ 
        all =         { team = ALL, units = 25, reinforcements = 250, 
          soldier =           { "all_inf_rifleman_jungle" }, 
          assault =           { "all_inf_rocketeer_jungle" }, 
          engineer =           { "all_inf_engineer" }, 
          sniper =           { "all_inf_sniper_jungle" }, 
          officer =           { "all_inf_officer" }, 
          special =           { "all_inf_wookiee" }
         }, 
        imp =         { team = IMP, units = 32, reinforcements = 250, 
          soldier =           { "imp_inf_rifleman" }, 
          assault =           { "imp_inf_rocketeer" }, 
          engineer =           { "imp_inf_engineer" }, 
          sniper =           { "imp_inf_sniper" }, 
          officer =           { "imp_inf_officer" }, 
          special =           { "imp_inf_dark_trooper" }
         }
       })
    SetHeroClass(ALL,"all_hero_chewbacca")
    SetHeroClass(IMP,"imp_hero_bobafett")
    SetTeamAsEnemy(ATT,3)
    SetTeamAsFriend(DEF,3)
    ClearWalkers()
    AddWalkerType(0,0)
    AddWalkerType(1,0)
    AddWalkerType(2,3)
    AddWalkerType(3,0)
    SetMemoryPoolSize("EntityLight",44)
    SetMemoryPoolSize("CommandWalker",0)
    SetMemoryPoolSize("MountedTurret",20)
    SetMemoryPoolSize("EntityHover",0)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("EntityBuildingArmedDynamic",0)
    SetMemoryPoolSize("PowerupItem",30)
    SetMemoryPoolSize("EntityMine",30)
    SetMemoryPoolSize("Aimer",100)
    SetMemoryPoolSize("Obstacle",600)
    SetMemoryPoolSize("Weapon",265)
    SetMemoryPoolSize("PassengerSlot",0)
    SetSpawnDelay(10,0.25)
    ReadDataFile("KAS\\kas2.lvl","kas2_obj")
    SetDenseEnvironment("false")
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    SetTeamName(3,"locals")
    SetTeamIcon(3,"all_icon")
    AddUnitClass(3,"wok_inf_warrior",3)
    AddUnitClass(3,"wok_inf_rocketeer",2)
    AddUnitClass(3,"wok_inf_mechanic",2)
    SetUnitCount(3,7)
    SetTeamAsEnemy(3,ATT)
    SetTeamAsFriend(3,DEF)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\kas.lvl","kas")
    OpenAudioStream("sound\\kas.lvl","kas")
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(ALL,1,"all_kas_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_kas_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_kas_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_kas_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_kas_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_kas_amb_end",2,1)
    SetVictoryMusic(ALL,"all_kas_amb_victory")
    SetDefeatMusic(ALL,"all_kas_amb_defeat")
    SetVictoryMusic(IMP,"imp_kas_amb_victory")
    SetDefeatMusic(IMP,"imp_kas_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.99366897344589,-0.09961000084877,-0.051708001643419,-0.0051830001175404,109.47354888916,34.506076812744,272.88922119141)
    AddCameraShot(-0.13082699477673,0.02471400052309,-0.97387301921844,-0.18396799266338,146.41287231445,60.191699981689,-191.87882995605)
    AddCameraShot(0.94083100557327,-0.10825499892235,-0.31901299953461,-0.036706998944283,-65.793930053711,66.455177307129,289.43267822266)
    AddCameraShot(0.52312701940536,-0.055344998836517,-0.84573602676392,-0.089475996792316,-170.51907348633,66.455177307129,-248.87753295898)
end

