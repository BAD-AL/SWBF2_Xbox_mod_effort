--uta1g_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")
IMP = 1
ALL = 2
ATT = IMP
DEF = ALL

function ScriptPostLoad()
    SetProperty("flag1","GeometryName","com_icon_alliance_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_alliance_flag")
    SetProperty("flag2","GeometryName","com_icon_imperial_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_imperial_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 8, text = "game.modes.ctf", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag2_cap", captureRegion = "flag1_cap", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag1_cap", captureRegion = "flag2_cap", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4880000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\uta.lvl;uta1gcw")
    SetMaxFlyHeight(29.5)
    SetMaxPlayerFlyHeight(29.5)
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_inf_officer","all_inf_wookiee","all_hero_hansolo_tat")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_bobafett")
    SetupTeams({ 
        all =         { team = ALL, units = 20, reinforcements = -1, 
          soldier =           { "all_inf_rifleman", 8 }, 
          assault =           { "all_inf_rocketeer", 3 }, 
          engineer =           { "all_inf_engineer", 4 }, 
          sniper =           { "all_inf_sniper", 2 }, 
          officer =           { "all_inf_officer", 1 }, 
          special =           { "all_inf_wookiee", 2 }
         }
       })
    SetupTeams({ 
        imp =         { team = IMP, units = 20, reinforcements = -1, 
          soldier =           { "imp_inf_rifleman", 8 }, 
          assault =           { "imp_inf_rocketeer", 3 }, 
          engineer =           { "imp_inf_engineer", 4 }, 
          sniper =           { "imp_inf_sniper", 2 }, 
          officer =           { "imp_inf_officer", 1 }, 
          special =           { "imp_inf_dark_trooper", 2 }
         }
       })
    SetHeroClass(IMP,"imp_hero_bobafett")
    SetHeroClass(ALL,"all_hero_hansolo_tat")
    ClearWalkers()
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("EntityHover",4)
    SetMemoryPoolSize("EntityLight",80)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("Obstacle",400)
    SetMemoryPoolSize("Weapon",260)
    SetSpawnDelay(10,0.25)
    ReadDataFile("uta\\uta1.lvl","uta1_CTF2flag")
    SetDenseEnvironment("false")
    AddDeathRegion("DeathRegion01")
    SetMaxFlyHeight(29.5)
    SetMaxPlayerFlyHeight(29.5)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\uta.lvl","uta1")
    OpenAudioStream("sound\\uta.lvl","uta1")
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"all_uta_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_uta_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_uta_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_uta_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_uta_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_uta_amb_end",2,1)
    SetVictoryMusic(ALL,"all_uta_amb_victory")
    SetDefeatMusic(ALL,"all_uta_amb_defeat")
    SetVictoryMusic(IMP,"imp_uta_amb_victory")
    SetDefeatMusic(IMP,"imp_uta_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.42809098958969,0.045648999512196,-0.89749401807785,-0.09570299834013,162.71495056152,45.857063293457,40.647117614746)
end

