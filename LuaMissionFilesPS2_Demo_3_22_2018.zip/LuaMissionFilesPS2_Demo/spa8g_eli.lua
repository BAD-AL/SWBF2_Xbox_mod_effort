--spa8g_eli.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("spa8g_cmn")
myGameMode = "spa8_eli"
myTeamConfig = { 
  all =   { team = ALL, units = 16, reinforcements = 100, 
    pilot =     { "all_inf_pilot", 10 }, 
    marine =     { "all_inf_marine", 6 }
   }, 
  imp =   { team = IMP, units = 16, reinforcements = 100, 
    pilot =     { "imp_inf_pilot", 10 }, 
    marine =     { "imp_inf_marine", 6 }
   }
 }

function ScriptPostLoad()
    EnableSPHeroRules()
    tdm = ObjectiveTDM:New({ teamATT = IMP, teamDEF = ALL, textATT = "level.kamino1.objectives.tdm.1", textDEF = "level.kamino1.objectives.tdm.2", multiplayerRules = true, HideCps = true })
    tdm:Start()
    LockHangarWarsDoors()
end

