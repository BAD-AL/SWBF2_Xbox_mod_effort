--cor1c_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("setup_teams")
ATT = 1
DEF = 2
REP = ATT
CIS = DEF

function ScriptPostLoad()
    EnableSPHeroRules()
    DisableBarriers("SideDoor1")
    DisableBarriers("MainLibraryDoors")
    DisableBarriers("SideDoor2")
    DisableBarriers("SIdeDoor3")
    DisableBarriers("ComputerRoomDoor1")
    DisableBarriers("StarChamberDoor1")
    DisableBarriers("StarChamberDoor2")
    DisableBarriers("WarRoomDoor1")
    DisableBarriers("WarRoomDoor2")
    DisableBarriers("WarRoomDoor3")
    PlayAnimation("DoorOpen01")
    PlayAnimation("DoorOpen02")
    ctf = ObjectiveOneFlagCTF:New({ teamATT = 1, teamDEF = 2, textATT = "level.naboo2.1flag.team1", textDEF = "level.naboo2.1flag.team2", captureLimit = 5, flag = "Flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "HomeRegion", captureRegionATT = "Team1Capture", captureRegionDEF = "Team2Capture", capRegionMarkerATT = "listbox_cursor", capRegionMarkerDEF = "listbox_cursor", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4100000)
    ReadDataFile("ingame.lvl")
    SetMapNorthAngle(0)
    ReadDataFile("sound\\cor.lvl;cor1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper","rep_fly_assault_DOME","rep_fly_gunship_DOME","rep_hero_macewindu")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_fly_droidfighter_DOME","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka","cis_hero_darthmaul")
    SetupTeams({ 
        rep =         { team = REP, units = 25, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman", 11 }, 
          assault =           { "rep_inf_ep3_rocketeer", 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 3 }, 
          sniper =           { "rep_inf_ep3_sniper", 2 }, 
          officer =           { "rep_inf_ep3_officer", 2 }, 
          special =           { "rep_inf_ep3_jettrooper", 3 }
         }, 
        cis =         { team = CIS, units = 25, reinforcements = -1, 
          soldier =           { "cis_inf_rifleman", 11 }, 
          assault =           { "cis_inf_rocketeer", 4 }, 
          engineer =           { "cis_inf_engineer", 3 }, 
          sniper =           { "cis_inf_sniper", 2 }, 
          officer =           { "cis_inf_officer", 2 }, 
          special =           { "cis_inf_droideka", 3 }
         }
       })
    SetHeroClass(CIS,"cis_hero_darthmaul")
    SetHeroClass(REP,"rep_hero_macewindu")
    SetMemoryPoolSize("Combo",16)
    SetMemoryPoolSize("Combo::State",192)
    SetMemoryPoolSize("Combo::Transition",256)
    SetMemoryPoolSize("Combo::Condition",256)
    SetMemoryPoolSize("Combo::Attack",128)
    SetMemoryPoolSize("Combo::DamageSample",2048)
    SetMemoryPoolSize("Combo::Deflect",16)
    ClearWalkers()
    AddWalkerType(0,4)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("MountedTurret",11)
    SetMemoryPoolSize("EntityHover",4)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("EntityLight",96)
    SetMemoryPoolSize("SoundSpaceRegion",38)
    SetMemoryPoolSize("FlagItem",1)
    SetSpawnDelay(10,0.25)
    ReadDataFile("cor\\cor1.lvl","cor1_1Flag")
    SetDenseEnvironment("True")
    AddDeathRegion("DeathRegion1")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\cor.lvl","corcw_music")
    OpenAudioStream("sound\\cor.lvl","cor1")
    OpenAudioStream("sound\\cor.lvl","cor1")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_cor_amb_start",0,1)
    SetAmbientMusic(REP,0.99000000953674,"rep_cor_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_cor_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_cor_amb_start",0,1)
    SetAmbientMusic(CIS,0.99000000953674,"cis_cor_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_cor_amb_end",2,1)
    SetVictoryMusic(REP,"rep_cor_amb_victory")
    SetDefeatMusic(REP,"rep_cor_amb_defeat")
    SetVictoryMusic(CIS,"cis_cor_amb_victory")
    SetDefeatMusic(CIS,"cis_cor_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.40489500761032,0.0009919999865815,-0.91435998678207,-0.0022400000598282,-85.539894104004,20.536296844482,141.6994934082)
    AddCameraShot(0.040922001004219,0.004048999864608,-0.99429899454117,0.098380997776985,-139.72952270508,17.546598434448,-34.360893249512)
    AddCameraShot(-0.31235998868942,0.016223000362515,-0.94854700565338,-0.049263000488281,-217.38148498535,20.150953292847,54.514324188232)
end

