--tat2g_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
ATT = 1
DEF = 2
ALL = DEF
IMP = ATT

function ScriptPostLoad()
    SetProperty("flag1","GeometryName","com_icon_alliance_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_alliance_flag")
    SetProperty("flag2","GeometryName","com_icon_imperial_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_imperial_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 10, textATT = "game.mode.ctf", textDEF = "game.mode.ctf2", multiplayerRules = true, hideCPs = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag1_home", captureRegion = "flag2_home", capRegionMarker = "all_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 2 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag2_home", captureRegion = "flag1_home", capRegionMarker = "imp_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 2 })
    ctf:Start()
    KillObject("CP1")
    KillObject("CP2")
    KillObject("CP3")
    KillObject("CP4")
    KillObject("CP5")
    KillObject("CP6")
    KillObject("CP7")
    KillObject("CP8")
    SetProperty("flag1","AllowTeamPickup",0)
    SetProperty("flag2","AllowTeamPickup",0)
    AddAIGoal(3,"Deathmatch",1000)
end

function ScriptInit()
    SetPS2ModelMemory(2097152 + 65536 * 10)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(40)
    ReadDataFile("sound\\tat.lvl;tat2gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_inf_officer","all_inf_wookiee","all_hero_hansolo_tat")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_bobafett")
    ReadDataFile("SIDE\\des.lvl","tat_inf_jawa")
    SetupTeams({ 
        all =         { team = ALL, units = 25, reinforcements = 250, 
          soldier =           { "all_inf_rifleman" }, 
          assault =           { "all_inf_rocketeer" }, 
          engineer =           { "all_inf_engineer" }, 
          sniper =           { "all_inf_sniper" }, 
          officer =           { "all_inf_officer" }, 
          special =           { "all_inf_wookiee" }
         }
       })
    SetupTeams({ 
        imp =         { team = IMP, units = 25, reinforcements = 250, 
          soldier =           { "imp_inf_rifleman" }, 
          assault =           { "imp_inf_rocketeer" }, 
          engineer =           { "imp_inf_engineer" }, 
          sniper =           { "imp_inf_sniper" }, 
          officer =           { "imp_inf_officer" }, 
          special =           { "imp_inf_dark_trooper" }
         }
       })
    SetTeamName(3,"locals")
    AddUnitClass(3,"tat_inf_jawa",14)
    SetUnitCount(3,14)
    SetTeamAsFriend(3,ATT)
    SetTeamAsFriend(3,DEF)
    SetHeroClass(ALL,"all_hero_hansolo_tat")
    SetHeroClass(IMP,"imp_hero_bobafett")
    ClearWalkers()
    AddWalkerType(0,0)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",14)
    SetMemoryPoolSize("EntityDroid",8)
    SetMemoryPoolSize("EntityLight",40)
    SetMemoryPoolSize("EntityMine",20)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("MountedTurret",14)
    SetMemoryPoolSize("Obstacle",653)
    SetMemoryPoolSize("Ordnance",60)
    SetMemoryPoolSize("ParticleEmitter",256)
    SetMemoryPoolSize("ParticleEmitterInfoData",256)
    SetMemoryPoolSize("ParticleEmitterObject",128)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("PathNode",384)
    SetMemoryPoolSize("PowerupItem",20)
    SetMemoryPoolSize("TreeGridStack",450)
    SetSpawnDelay(10,0.25)
    ReadDataFile("TAT\\tat2.lvl","tat2_ctf")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\tat.lvl","tat2")
    OpenAudioStream("sound\\tat.lvl","tat2")
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(ALL,1,"all_tat_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_tat_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_tat_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_tat_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_tat_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_tat_amb_end",2,1)
    SetVictoryMusic(ALL,"all_tat_amb_victory")
    SetDefeatMusic(ALL,"all_tat_amb_defeat")
    SetVictoryMusic(IMP,"imp_tat_amb_victory")
    SetDefeatMusic(IMP,"imp_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.51487797498703,-0.14333200454712,-0.81423497200012,-0.22666700184345,-351.05249023438,31.599720001221,-71.300521850586)
    AddCameraShot(0.89931601285934,0.0074450001120567,0.43722000718117,-0.00362000009045,-212.96699523926,20.173393249512,56.179828643799)
    AddCameraShot(0.90299302339554,-0.019974999129772,-0.42908498644829,-0.0094919996336102,-205.00177001953,17.679758071899,77.177253723145)
end

