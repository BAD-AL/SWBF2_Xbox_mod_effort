--spa5g_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")

function ScriptPostLoad()
end

function ScriptInit()
    SetPS2ModelMemory(3800000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\spa.lvl;spa4cross")
    ScriptCB_SetDopplerFactor(0.40000000596046)
    ScaleSoundParameter("weapons","MaxDistance",5)
    ScaleSoundParameter("weapons","MuteDistance",5)
    ScaleSoundParameter("ordnance","MinDistance",5)
    ScaleSoundParameter("ordnance","MaxDistance",5)
    ScaleSoundParameter("ordnance","MuteDistance",5)
    ScaleSoundParameter("veh_weapon","MaxDistance",10)
    ScaleSoundParameter("veh_weapon","MuteDistance",10)
    ScaleSoundParameter("explosion","MaxDistance",15)
    ScaleSoundParameter("explosion","MuteDistance",15)
    ReadDataFile("SIDE\\imp.lvl","imp_inf_pilot","imp_inf_marine","imp_fly_tiefighter_sc","imp_fly_tiebomber_sc","imp_fly_tieinterceptor","imp_fly_trooptrans","imp_veh_remote_terminal")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_pilot","rep_inf_ep3_marine","rep_fly_assault_dome","rep_fly_anakinstarfighter_sc","rep_fly_arc170fighter_sc","rep_veh_remote_terminal","rep_fly_arc170fighter_dome","rep_fly_vwing")
    SetupTeams({ 
        imp =         { team = 1, units = 10, reinforcements = 25, 
          marine =           { "imp_inf_marine", 4 }, 
          pilot =           { "imp_inf_pilot", 6 }
         }, 
        rep =         { team = 2, units = 22, reinforcements = 25, 
          marine =           { "rep_inf_ep3_marine", 8 }, 
          pilot =           { "rep_inf_ep3_pilot", 14 }
         }
       })
    ClearWalkers()
    AddWalkerType(0,8)
    SetMemoryPoolSize("CommandFlyer",2)
    SetMemoryPoolSize("PowerupItem",60)
    SetMemoryPoolSize("EntityMine",40)
    SetMemoryPoolSize("Aimer",200)
    SetSpawnDelay(10,0.25)
    ReadDataFile("spa\\spa5.lvl")
    SetDenseEnvironment("false")
    musicStream = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",musicStream)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",musicStream)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\spa.lvl","spa")
    OpenAudioStream("sound\\spa.lvl","spa")
    SetBleedingVoiceOver(2,2,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(2,1,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(1,2,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(1,1,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(2,2,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(2,1,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(1,1,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(1,2,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"impleaving")
    SetOutOfBoundsVoiceOver(2,"repleaving")
    SetAmbientMusic(2,1,"imp_spa_amb_start",0,1)
    SetAmbientMusic(2,0.89999997615814,"imp_spa_amb_middle",1,1)
    SetAmbientMusic(2,0.10000000149012,"imp_spa_amb_end",2,1)
    SetAmbientMusic(1,1,"imp_spa_amb_start",0,1)
    SetAmbientMusic(1,0.89999997615814,"imp_spa_amb_middle",1,1)
    SetAmbientMusic(1,0.10000000149012,"imp_spa_amb_end",2,1)
    SetVictoryMusic(2,"rep_spa_amb_victory")
    SetDefeatMusic(2,"rep_spa_amb_defeat")
    SetVictoryMusic(1,"imp_spa_amb_victory")
    SetDefeatMusic(1,"imp_spa_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.40489500761032,0.0009919999865815,-0.91435998678207,-0.0022400000598282,-85.539894104004,20.536296844482,141.6994934082)
if gPlatformStr == "PS2" then
end
    ScriptCB_DisableFlyerShadows()
end

