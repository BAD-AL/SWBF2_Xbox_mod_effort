-- spa2c_con.lua
-- Decompiled by cbadal & SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    AddAIGoal(ATT, "conquest", 900)
    AddAIGoal(DEF, "conquest", 900)
    OnCharacterDeathTeam(
        function(ATTParam0, ATTParam1)
            AddReinforcements(ATT, -1)
        end,
        ATT
    )
    OnCharacterDeathTeam(
        function(DEFParam0, DEFParam1)
            AddReinforcements(DEF, -1)
        end,
        DEF
    )
    OnTicketCountChange(
        function(Param0, Param1)
            if Param1 <= 0 then
            end
            MissionDefeat(Param0)
        end
    )
    SetObjectTeam("cp2", 2)
    SetObjectTeam("cp3", 1)
end

function ScriptInit()
    SetPS2ModelMemory(4407152)
    ReadDataFile("ingame.lvl")
    SetMinFlyHeight(-1900)
    SetMaxFlyHeight(2000)
    SetMinPlayerFlyHeight(-1900)
    SetMaxPlayerFlyHeight(2000)
    SetAIVehicleNotifyRadius(100)
    ReadDataFile("sound\\spa.lvl;spa2cw")
    ScriptCB_SetDopplerFactor(0.40000000596046)
    ScaleSoundParameter("ordnance", "MinDistance", 5)
    ScaleSoundParameter("ordnance", "MaxDistance", 5)
    ScaleSoundParameter("ordnance", "MuteDistance", 5)
    ScaleSoundParameter("veh_weapon", "MaxDistance", 10)
    ScaleSoundParameter("veh_weapon", "MuteDistance", 10)
    ScaleSoundParameter("explosion", "MaxDistance", 15)
    ScaleSoundParameter("explosion", "MuteDistance", 15)
    ReadDataFile(
        "SIDE\\rep.lvl",
        "rep_inf_ep3_pilot",
        "rep_inf_ep3_marine",
        "rep_fly_assault_dome",
        "rep_fly_anakinstarfighter_sc",
        "rep_fly_arc170fighter_sc",
        "rep_veh_remote_terminal",
        "rep_fly_arc170fighter_dome",
        "rep_fly_vwing"
    )
    ReadDataFile(
        "SIDE\\cis.lvl",
        "cis_inf_pilot",
        "cis_inf_marine",
        "cis_fly_fedlander_dome",
        "cis_fly_droidfighter_sc",
        "cis_fly_droidfighter_dome",
        "cis_fly_greviousfighter",
        "cis_fly_tridroidfighter"
    )
    ReadDataFile("SIDE\\tur.lvl", "tur_bldg_all_recoilless")
    SetupTeams(
        {
            rep = {
                team = REP,
                units = 16,
                reinforcements = 25,
                pilot = {"rep_inf_ep3_pilot", 12},
                marine = {"rep_inf_ep3_marine", 4}
            },
            cis = {
                team = CIS,
                units = 16,
                reinforcements = 25,
                pilot = {"cis_inf_pilot", 3},
                marine = {"cis_inf_marine", 11}
            }
        }
    )
    ClearWalkers()
    SetMemoryPoolSize("CommandFlyer", 2)
    SetMemoryPoolSize("EntityFlyer", 32)
    SetMemoryPoolSize("PowerupItem", 30)
    SetMemoryPoolSize("EntityMine", 8)
    SetMemoryPoolSize("EntityRemoteTerminal", 8)
    SetMemoryPoolSize("Obstacle", 80)
    SetMemoryPoolSize("PathNode", 48)
    SetMemoryPoolSize("BaseHint", 0)
    SetMemoryPoolSize("PassengerSlot", 0)
    SetMemoryPoolSize("EntitySoldier", 32)
    SetMemoryPoolSize("EntityDroideka", 0)
    SetMemoryPoolSize("EntityDroid", 0)
    SetMemoryPoolSize("TreeGridStack", 100)
    SetMemoryPoolSize("Aimer", 350)
    SetMemoryPoolSize("UnitController", 90)
    SetMemoryPoolSize("UnitAgent", 90)
    SetMemoryPoolSize("MountedTurret", 60)
    SetMemoryPoolSize("Weapon", 270)
    SetSpawnDelay(10, 0.25)
    ReadDataFile("spa\\spa2.lvl")
    SetDenseEnvironment("false")
    SetParticleLODBias(15000)
    musicStream = OpenAudioStream("sound\\global.lvl", "rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl", "cis_unit_vo_slow", musicStream)
    AudioStreamAppendSegments("sound\\global.lvl", "global_vo_slow", musicStream)
    OpenAudioStream("sound\\global.lvl", "cw_music")
    OpenAudioStream("sound\\spa.lvl", "spa")
    OpenAudioStream("sound\\spa.lvl", "spa")
    SetBleedingVoiceOver(REP, REP, "rep_off_com_report_us_overwhelmed", 1)
    SetBleedingVoiceOver(REP, CIS, "rep_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(CIS, REP, "cis_off_com_report_enemy_losing", 1)
    SetBleedingVoiceOver(CIS, CIS, "cis_off_com_report_us_overwhelmed", 1)
    SetLowReinforcementsVoiceOver(REP, REP, "rep_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(REP, CIS, "rep_off_victory_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(CIS, CIS, "cis_off_defeat_im", 0.10000000149012, 1)
    SetLowReinforcementsVoiceOver(CIS, REP, "cis_off_victory_im", 0.10000000149012, 1)
    SetOutOfBoundsVoiceOver(1, "Repleaving")
    SetOutOfBoundsVoiceOver(2, "Cisleaving")
    SetAmbientMusic(REP, 1, "rep_spa_amb_start", 0, 1)
    SetAmbientMusic(REP, 0.89999997615814, "rep_spa_amb_middle", 1, 1)
    SetAmbientMusic(REP, 0.10000000149012, "rep_spa_amb_end", 2, 1)
    SetAmbientMusic(CIS, 1, "cis_spa_amb_start", 0, 1)
    SetAmbientMusic(CIS, 0.89999997615814, "cis_spa_amb_middle", 1, 1)
    SetAmbientMusic(CIS, 0.10000000149012, "cis_spa_amb_end", 2, 1)
    SetVictoryMusic(REP, "rep_spa_amb_victory")
    SetDefeatMusic(REP, "rep_spa_amb_defeat")
    SetVictoryMusic(CIS, "cis_spa_amb_victory")
    SetDefeatMusic(CIS, "cis_spa_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn", "binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut", "binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange", "shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange", "shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept", "shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack", "shell_menu_exit")
    AddCameraShot(
        0.018921999260783,
        0.004317999817431,
        -0.97475498914719,
        0.22243200242519,
        -546.70269775391,
        412.00747680664,
        -1779.9544677734
    )
    AddLandingRegion("CP1Control")
    AddLandingRegion("CP2CONTROL")
    AddLandingRegion("cp3control")
    AddLandingRegion("cp4control")
    if gPlatformStr == "PS2" then
        ScriptCB_DisableFlyerShadows()
    end
end
