--spa3c_eli.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveTDM")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    EnableSPHeroRules()
    TDM = ObjectiveTDM:New({ teamATT = 1, teamDEF = 2, textATT = "game.modes.tdm", textDEF = "game.modes.tdm2", multiplayerRules = true })
    TDM:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4697152)
    ReadDataFile("ingame.lvl")
    SetMinFlyHeight(-1900)
    SetMaxFlyHeight(2000)
    SetMinPlayerFlyHeight(-1900)
    SetMaxPlayerFlyHeight(2000)
    SetAIVehicleNotifyRadius(100)
    ReadDataFile("sound\\spa.lvl;spa2cw")
    ScriptCB_SetDopplerFactor(0.40000000596046)
    ScaleSoundParameter("weapons","MaxDistance",5)
    ScaleSoundParameter("weapons","MuteDistance",5)
    ScaleSoundParameter("ordnance","MinDistance",5)
    ScaleSoundParameter("ordnance","MaxDistance",5)
    ScaleSoundParameter("ordnance","MuteDistance",5)
    ScaleSoundParameter("veh_weapon","MaxDistance",10)
    ScaleSoundParameter("veh_weapon","MuteDistance",10)
    ScaleSoundParameter("explosion","MaxDistance",15)
    ScaleSoundParameter("explosion","MuteDistance",15)
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_pilot","rep_inf_ep3_marine","rep_fly_assault_dome","rep_fly_anakinstarfighter_sc","rep_fly_arc170fighter_sc","rep_veh_remote_terminal","rep_fly_arc170fighter_dome","rep_fly_vwing")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_pilot","cis_inf_marine","cis_fly_fedlander_dome","cis_fly_droidfighter_sc","cis_fly_droidfighter_dome","cis_fly_greviousfighter","cis_fly_tridroidfighter")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_chaingun_tripod","tur_bldg_cis_chaingun","tur_bldg_chaingun_roof")
    SetupTeams({ 
        rep =         { team = REP, units = 16, reinforcements = 40, 
          pilot =           { "rep_inf_ep3_pilot", 10 }, 
          marine =           { "rep_inf_ep3_marine", 6 }
         }, 
        cis =         { team = CIS, units = 16, reinforcements = 40, 
          pilot =           { "cis_inf_pilot", 10 }, 
          marine =           { "cis_inf_marine", 6 }
         }
       })
    ClearWalkers()
    SetMemoryPoolSize("CommandFlyer",2)
    SetMemoryPoolSize("EntityFlyer",32)
    SetMemoryPoolSize("PowerupItem",30)
    SetMemoryPoolSize("EntityMine",32)
    SetMemoryPoolSize("EntityRemoteTerminal",8)
    SetMemoryPoolSize("Obstacle",80)
    SetMemoryPoolSize("PathNode",48)
    SetMemoryPoolSize("BaseHint",0)
    SetMemoryPoolSize("EntitySoldier",32)
    SetMemoryPoolSize("EntityDroideka",0)
    SetMemoryPoolSize("EntityDroid",0)
    SetMemoryPoolSize("TreeGridStack",100)
    SetMemoryPoolSize("EntitySoundStream",48)
    SetMemoryPoolSize("Aimer",350)
    SetMemoryPoolSize("UnitController",90)
    SetMemoryPoolSize("UnitAgent",90)
    SetMemoryPoolSize("Weapon",270)
    SetSpawnDelay(10,0.25)
    ReadDataFile("spa\\spa3.lvl")
    SetDenseEnvironment("false")
    SetParticleLODBias(15000)
    musicStream = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",musicStream)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",musicStream)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\spa.lvl","spa")
    OpenAudioStream("sound\\spa.lvl","spa")
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_spa_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_spa_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_spa_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_spa_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_spa_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_spa_amb_end",2,1)
    SetVictoryMusic(REP,"rep_spa_amb_victory")
    SetDefeatMusic(REP,"rep_spa_amb_defeat")
    SetVictoryMusic(CIS,"cis_spa_amb_victory")
    SetDefeatMusic(CIS,"cis_spa_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.91192698478699,0.05723299831152,-0.40554401278496,0.025451999157667,-747.64849853516,639.81549072266,-304.17987060547)
    AddCameraShot(0.86017102003098,-0.064814999699593,-0.50444000959396,-0.038010001182556,-492.78005981445,660.19860839844,-932.8525390625)
    AddCameraShot(0.018921999260783,0.004317999817431,-0.97475498914719,0.22243200242519,-546.70269775391,412.00747680664,-1779.9544677734)
    AddLandingRegion("CP1Control")
    AddLandingRegion("CP2Control")
if gPlatformStr == "PS2" then
end
    ScriptCB_DisableFlyerShadows()
end

