--mus1c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("objectivectf")
ScriptCB_DoFile("setup_teams")
ATT = 1
DEF = 2
REP = ATT
CIS = DEF

function ScriptPostLoad()
    PlayAnimRise()
    DisableBarriers("BALCONEY")
    DisableBarriers("bALCONEY2")
    DisableBarriers("hallway_f")
    DisableBarriers("hackdoor")
    DisableBarriers("outside")
    OnObjectRespawnName(PlayAnimRise,"DingDong")
    OnObjectKillName(PlayAnimDrop,"DingDong")
    SetProperty("FLAG1","GeometryName","com_icon_republic_flag")
    SetProperty("FLAG1","CarriedGeometryName","com_icon_republic_flag")
    SetProperty("FLAG2","GeometryName","com_icon_cis_flag")
    SetProperty("FLAG2","CarriedGeometryName","com_icon_cis_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 8, textATT = "game.mode.ctf", textDEF = "game.mode.ctf2", multiplayerRules = true })
    ctf:AddFlag({ name = "FLAG1", homeRegion = "FLAG1_HOME", captureRegion = "FLAG2_HOME", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "FLAG2", homeRegion = "FLAG2_HOME", captureRegion = "FLAG1_HOME", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function PlayAnimDrop()
    PauseAnimation("lava_bridge_raise")
    RewindAnimation("lava_bridge_drop")
    PlayAnimation("lava_bridge_drop")
    BlockPlanningGraphArcs("Connection82")
    BlockPlanningGraphArcs("Connection83")
    EnableBarriers("Bridge")
end

function PlayAnimRise()
    PauseAnimation("lava_bridge_drop")
    RewindAnimation("lava_bridge_raise")
    PlayAnimation("lava_bridge_raise")
    UnblockPlanningGraphArcs("Connection82")
    UnblockPlanningGraphArcs("Connection83")
    DisableBarriers("Bridge")
end

function ScriptInit()
    SetPS2ModelMemory(3600000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\mus.lvl;mus1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_jettrooper","rep_inf_ep3_sniper_felucia","rep_inf_ep3_officer","rep_hero_obiwan")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","CIS_inf_officer","cis_hero_darthmaul","cis_inf_droideka")
    SetupTeams({ 
        REP =         { team = REP, units = 25, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman" }, 
          assault =           { "rep_inf_ep3_rocketeer" }, 
          engineer =           { "rep_inf_ep3_engineer" }, 
          sniper =           { "rep_inf_ep3_sniper_felucia" }, 
          officer =           { "rep_inf_ep3_officer" }, 
          special =           { "rep_inf_ep3_jettrooper" }
         }
       })
    SetupTeams({ 
        CIS =         { team = CIS, units = 25, reinforcements = -1, 
          soldier =           { "CIS_inf_rifleman" }, 
          assault =           { "CIS_inf_rocketeer" }, 
          engineer =           { "CIS_inf_engineer" }, 
          sniper =           { "CIS_inf_sniper" }, 
          officer =           { "CIS_inf_officer" }, 
          special =           { "cis_inf_droideka" }
         }
       })
    SetHeroClass(REP,"rep_hero_obiwan")
    SetHeroClass(CIS,"cis_hero_darthmaul")
    ClearWalkers()
    SetMemoryPoolSize("PowerupItem",60)
    SetMemoryPoolSize("EntityMine",40)
    SetMemoryPoolSize("Aimer",200)
    SetMemoryPoolSize("Obstacle",290)
    SetMemoryPoolSize("EntitySoundStatic",175)
    SetSpawnDelay(10,0.25)
    SetDenseEnvironment("false")
    SetMemoryPoolSize("FlagItem",2)
    ReadDataFile("mus\\mus1.lvl","MUS1_CTF")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\mus.lvl","mus1")
    OpenAudioStream("sound\\mus.lvl","mus1")
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetAmbientMusic(REP,1,"rep_mus_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_mus_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_mus_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_mus_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_mus_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_mus_amb_end",2,1)
    SetVictoryMusic(REP,"rep_mus_amb_victory")
    SetDefeatMusic(REP,"rep_mus_amb_defeat")
    SetVictoryMusic(CIS,"cis_mus_amb_victory")
    SetDefeatMusic(CIS,"cis_mus_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.40489500761032,0.0009919999865815,-0.91435998678207,-0.0022400000598282,-85.539894104004,20.536296844482,141.6994934082)
    AddCameraShot(0.040922001004219,0.004048999864608,-0.99429899454117,0.098380997776985,-139.72952270508,17.546598434448,-34.360893249512)
    AddCameraShot(-0.31235998868942,0.016223000362515,-0.94854700565338,-0.049263000488281,-217.38148498535,20.150953292847,54.514324188232)
end

