--tat2c_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "cp1" })
    cp2 = CommandPost:New({ name = "cp2" })
    cp3 = CommandPost:New({ name = "cp3" })
    cp6 = CommandPost:New({ name = "cp6" })
    cp7 = CommandPost:New({ name = "cp7" })
    cp8 = CommandPost:New({ name = "cp8" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.mode.con", textDEF = "game.mode.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp6)
    conquest:AddCommandPost(cp7)
    conquest:AddCommandPost(cp8)
    conquest:Start()
    AddAIGoal(1,"conquest",1000)
    AddAIGoal(2,"conquest",1000)
    AddAIGoal(3,"conquest",1000)
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(2097152 + 65536 * 10)
    ReadDataFile("ingame.lvl")
    REP = 1
    CIS = 2
    DES = 3
    ATT = 1
    DEF = 2
    SetTeamAggressiveness(REP,0.94999998807907)
    SetTeamAggressiveness(CIS,0.94999998807907)
    SetMaxFlyHeight(40)
    ReadDataFile("sound\\tat.lvl;tat2cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rocketeer","rep_inf_ep3_rifleman","rep_inf_ep3_sniper","rep_inf_ep3_engineer","rep_inf_ep3_jettrooper","rep_inf_ep3_officer","rep_hero_obiwan")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_hero_darthmaul","cis_inf_droideka")
    ReadDataFile("SIDE\\des.lvl","tat_inf_jawa")
    SetAttackingTeam(ATT)
    SetupTeams({ 
        rep =         { team = REP, units = 25, reinforcements = 250, 
          rifleman =           { "rep_inf_ep3_rifleman", 1, 50 }, 
          rocketeer =           { "rep_inf_ep3_rocketeer", 1, 50 }, 
          engineer =           { "rep_inf_ep3_engineer", 1, 50 }, 
          sniper =           { "rep_inf_ep3_sniper", 1, 50 }, 
          officer =           { "rep_inf_ep3_officer", 1, 50 }, 
          special =           { "rep_inf_ep3_jettrooper", 1, 50 }
         }
       })
    SetupTeams({ 
        cis =         { team = CIS, units = 25, reinforcements = 250, 
          soldier =           { "CIS_inf_rifleman", 1, 50 }, 
          assault =           { "CIS_inf_rocketeer", 1, 50 }, 
          engineer =           { "CIS_inf_engineer", 1, 50 }, 
          sniper =           { "CIS_inf_sniper", 1, 50 }, 
          officer =           { "CIS_inf_officer", 1, 50 }, 
          special =           { "cis_inf_droideka", 1, 50 }
         }
       })
    SetTeamName(3,"locals")
    AddUnitClass(3,"tat_inf_jawa",14)
    SetUnitCount(3,14)
    SetTeamAsFriend(3,ATT)
    SetTeamAsFriend(3,DEF)
    SetHeroClass(CIS,"cis_hero_darthmaul")
    SetHeroClass(REP,"rep_hero_obiwan")
    SetTeamAsFriend(ATT,3)
    ClearWalkers()
    AddWalkerType(0,3)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",23)
    SetMemoryPoolSize("EntityDroid",8)
    SetMemoryPoolSize("EntityHover",1)
    SetMemoryPoolSize("EntityMine",40)
    SetMemoryPoolSize("MountedTurret",15)
    SetMemoryPoolSize("ParticleEmitter",256)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("ParticleEmitterObject",128)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("PathNode",256)
    SetMemoryPoolSize("Obstacle",667)
    SetMemoryPoolSize("Ordnance",50)
    SetMemoryPoolSize("Weapon",200)
    SetSpawnDelay(10,0.25)
    ReadDataFile("TAT\\tat2.lvl")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\tat.lvl","tat2")
    OpenAudioStream("sound\\tat.lvl","tat2")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(REP,REP,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(REP,CIS,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,CIS,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,REP,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"repleaving")
    SetOutOfBoundsVoiceOver(2,"cisleaving")
    SetAmbientMusic(REP,1,"rep_tat_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_tat_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_tat_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_tat_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_tat_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_tat_amb_end",2,1)
    SetVictoryMusic(REP,"rep_tat_amb_victory")
    SetDefeatMusic(REP,"rep_tat_amb_defeat")
    SetVictoryMusic(CIS,"cis_tat_amb_victory")
    SetDefeatMusic(CIS,"cis_tat_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.51487797498703,-0.14333200454712,-0.81423497200012,-0.22666700184345,-351.05249023438,31.599720001221,-71.300521850586)
    AddCameraShot(0.89931601285934,0.0074450001120567,0.43722000718117,-0.00362000009045,-212.96699523926,20.173393249512,56.179828643799)
    AddCameraShot(0.90299302339554,-0.019974999129772,-0.42908498644829,-0.0094919996336102,-205.00177001953,17.679758071899,77.177253723145)
end

