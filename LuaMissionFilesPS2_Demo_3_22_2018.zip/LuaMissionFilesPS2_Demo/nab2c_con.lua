--nab2c_con.lua
-- Decompiled with SWBF2CodeHelper
Conquest = ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
CIS = 1
REP = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "CP1" })
    cp2 = CommandPost:New({ name = "CP2" })
    cp3 = CommandPost:New({ name = "CP3" })
    cp4 = CommandPost:New({ name = "CP4" })
    cp5 = CommandPost:New({ name = "CP5" })
    cp6 = CommandPost:New({ name = "CP6" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "level.yavin1.con.att", textDEF = "level.yavin1.con.def", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:AddCommandPost(cp6)
    conquest:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(3000000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\nab.lvl;nab2cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper","rep_hero_obiwan","rep_walk_oneman_atst")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka","cis_hero_darthmaul")
    SetupTeams({ 
        rep =         { team = REP, units = 25, reinforcements = 200, 
          soldier =           { "rep_inf_ep3_rifleman", 11 }, 
          assault =           { "rep_inf_ep3_rocketeer", 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 3 }, 
          sniper =           { "rep_inf_ep3_sniper", 2 }, 
          officer =           { "rep_inf_ep3_officer", 2 }, 
          special =           { "rep_inf_ep3_jettrooper", 3 }
         }, 
        cis =         { team = CIS, units = 25, reinforcements = 200, 
          soldier =           { "cis_inf_rifleman", 11 }, 
          assault =           { "cis_inf_rocketeer", 4 }, 
          engineer =           { "cis_inf_engineer", 3 }, 
          sniper =           { "cis_inf_sniper", 2 }, 
          officer =           { "cis_inf_officer", 2 }, 
          special =           { "cis_inf_droideka", 3 }
         }
       })
    SetHeroClass(CIS,"cis_hero_darthmaul")
    SetHeroClass(REP,"rep_hero_obiwan")
    ClearWalkers()
    AddWalkerType(0,3)
    AddWalkerType(1,4)
    SetMemoryPoolSize("Aimer",22)
    SetMemoryPoolSize("BaseHint",128)
    SetMemoryPoolSize("EntitySoundStream",1)
    SetMemoryPoolSize("EntitySoundStatic",41)
    SetMemoryPoolSize("MountedTurret",4)
    SetMemoryPoolSize("Navigator",32)
    SetMemoryPoolSize("Obstacle",450)
    SetMemoryPoolSize("Ordnance",50)
    SetMemoryPoolSize("ParticleEmitter",300)
    SetMemoryPoolSize("ParticleEmitterObject",128)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("PathNode",200)
    SetMemoryPoolSize("TreeGridStack",400)
    SetMemoryPoolSize("UnitAgent",32)
    SetMemoryPoolSize("UnitController",32)
    SetMemoryPoolSize("Weapon",144)
    SetSpawnDelay(10,0.25)
    ReadDataFile("NAB\\nab2.lvl","naboo2_Conquest")
    SetDenseEnvironment("true")
    AddDeathRegion("Water")
    AddDeathRegion("Waterfall")
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    SetBirdFlockMinHeight(-28)
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\nab.lvl","nab2")
    OpenAudioStream("sound\\nab.lvl","nab2")
    OpenAudioStream("sound\\nab.lvl","nab2_emt")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(REP,REP,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(REP,CIS,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,CIS,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,REP,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(2,"repleaving")
    SetOutOfBoundsVoiceOver(1,"cisleaving")
    SetAmbientMusic(REP,1,"rep_nab_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_nab_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_nab_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_nab_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_nab_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_nab_amb_end",2,1)
    SetVictoryMusic(REP,"rep_nab_amb_victory")
    SetDefeatMusic(REP,"rep_nab_amb_defeat")
    SetVictoryMusic(CIS,"cis_nab_amb_victory")
    SetDefeatMusic(CIS,"cis_nab_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.007592000067234,-1.9999999949505e-006,-0.99997097253799,0.00020900000527035,-168.55972290039,-45.250122070313,13.399480819702)
    AddCameraShot(0.25503298640251,0.0037889999803156,-0.96681797504425,0.014364999718964,-45.806968688965,-47.785381317139,-45.429058074951)
    AddCameraShot(0.62141698598862,-0.11941699683666,-0.76041197776794,-0.14612799882889,-276.06744384766,-18.259653091431,-77.929229736328)
end

