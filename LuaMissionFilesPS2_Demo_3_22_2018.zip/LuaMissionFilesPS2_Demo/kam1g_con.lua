--kam1g_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")
ALL = 1
IMP = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    SetAIDamageThreshold("Comp1",0)
    SetAIDamageThreshold("Comp2",0)
    SetAIDamageThreshold("Comp3",0)
    SetAIDamageThreshold("Comp4",0)
    SetAIDamageThreshold("Comp5",0)
    SetProperty("Kam_Bldg_Podroom_Door32","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door33","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door32","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door34","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door35","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door27","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door28","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door36","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door20","Islocked",1)
    UnblockPlanningGraphArcs("connection71")
    UnblockPlanningGraphArcs("connection85")
    UnblockPlanningGraphArcs("connection48")
    UnblockPlanningGraphArcs("connection63")
    UnblockPlanningGraphArcs("connection59")
    UnblockPlanningGraphArcs("close")
    UnblockPlanningGraphArcs("open")
    EnableBarriers("frog")
    EnableBarriers("close")
    EnableBarriers("open")
    UnblockPlanningGraphArcs("connection194")
    UnblockPlanningGraphArcs("connection200")
    UnblockPlanningGraphArcs("connection118")
    EnableBarriers("frontdoor2-3")
    EnableBarriers("frontdoor2-1")
    EnableBarriers("frontdoor2-2")
    UnblockPlanningGraphArcs("connection10")
    UnblockPlanningGraphArcs("connection159")
    UnblockPlanningGraphArcs("connection31")
    EnableBarriers("frontdoor1-3")
    EnableBarriers("frontdoor1-1")
    EnableBarriers("frontdoor1-2")
    cp1 = CommandPost:New({ name = "cp1" })
    cp2 = CommandPost:New({ name = "cp2" })
    cp3 = CommandPost:New({ name = "cp3" })
    cp4 = CommandPost:New({ name = "cp4" })
    cp5 = CommandPost:New({ name = "cp5" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.mode.con", textDEF = "game.mode.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:Start()
    EnableSPHeroRules()
    SetProperty("cp2","spawnpath","cp2_spawn")
    SetProperty("cp2","captureregion","cp2_capture")
end

function ScriptInit()
    SetPS2ModelMemory(3600000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\kam.lvl;kam1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_inf_wookiee","all_inf_officer","all_hero_hansolo_tat")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_bobafett")
    ClearWalkers()
    SetMemoryPoolSize("EntityHover",0)
    SetMemoryPoolSize("EntityLight",64)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("Obstacle",250)
    SetMemoryPoolSize("Weapon",260)
    SetupTeams({ 
        all =         { team = ALL, units = 25, reinforcements = 250, 
          soldier =           { "all_inf_rifleman" }, 
          assault =           { "all_inf_rocketeer" }, 
          engineer =           { "all_inf_engineer" }, 
          sniper =           { "all_inf_sniper" }, 
          officer =           { "all_inf_officer" }, 
          special =           { "all_inf_wookiee" }
         }
       })
    SetupTeams({ 
        imp =         { team = IMP, units = 25, reinforcements = 250, 
          soldier =           { "imp_inf_rifleman" }, 
          assault =           { "imp_inf_rocketeer" }, 
          engineer =           { "imp_inf_engineer" }, 
          sniper =           { "imp_inf_sniper" }, 
          officer =           { "imp_inf_officer" }, 
          special =           { "imp_inf_dark_trooper" }
         }
       })
    SetHeroClass(ALL,"all_hero_hansolo_tat")
    SetHeroClass(IMP,"imp_hero_bobafett")
    SetMemoryPoolSize("EntitySoundStatic",175)
    SetSpawnDelay(10,0.25)
    ReadDataFile("KAM\\kam1.lvl","kamino1_conquest")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\kam.lvl","kam1")
    OpenAudioStream("sound\\kam.lvl","kam1")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(ALL,ALL,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(ALL,IMP,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,IMP,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(IMP,ALL,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"all_mus_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_mus_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_mus_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_mus_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_mus_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_mus_amb_end",2,1)
    SetVictoryMusic(ALL,"all_mus_amb_victory")
    SetDefeatMusic(ALL,"all_mus_amb_defeat")
    SetVictoryMusic(IMP,"imp_mus_amb_victory")
    SetDefeatMusic(IMP,"imp_mus_amb_defeat")
    SetAttackingTeam(ATT)
    AddCameraShot(0.99765402078629,0.066982001066208,0.014139000326395,-0.00094900000840425,155.1371307373,0.91150498390198,-138.07707214355)
    AddCameraShot(0.72976100444794,0.019262000918388,0.68319398164749,-0.018032999709249,-98.584869384766,0.29528400301933,263.23928833008)
    AddCameraShot(0.69427698850632,0.0051000001840293,0.71967101097107,-0.0052869999781251,-11.105946540833,-2.7532069683075,67.982200622559)
end

