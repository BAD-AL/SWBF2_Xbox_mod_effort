--hot1g_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ALL = 2
IMP = 1
ATT = 1
DEF = 2

function ScriptPostLoad()
    EnableSPHeroRules()
    KillObject("shield")
    SetProperty("flag","GeometryName","com_icon_republic_flag")
    SetProperty("flag","CarriedGeometryName","com_icon_republic_flag")
    ctf = ObjectiveOneFlagCTF:New({ teamATT = 1, teamDEF = 2, textATT = "game.modes.1flag", textDEF = "game.modes.1flag2", captureLimit = 8, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "HomeRegion", captureRegionATT = "Team1Capture", captureRegionDEF = "Team2Capture", capRegionMarkerATT = "hud_objective_icon", capRegionMarkerDEF = "hud_objective_icon", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3 })
    ctf:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4600000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(70)
    SetMaxPlayerFlyHeight(70)
    ReadDataFile("sound\\hot.lvl;hot1gcw")
    ReadDataFile("SIDE\\all.lvl","all_fly_snowspeeder","all_inf_rifleman_snow","all_inf_rocketeer_snow","all_inf_engineer_snow","all_inf_sniper_snow","all_inf_officer_snow","all_hero_luke_jedi","all_inf_wookiee_snow","all_walk_tauntaun")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman_snow","imp_inf_rocketeer_snow","imp_inf_sniper_snow","imp_inf_dark_trooper","imp_inf_engineer","imp_inf_officer","imp_hero_darthvader","imp_walk_atat","imp_walk_atst_snow")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_chaingun_roof")
    SetupTeams({ 
        all =         { team = ALL, units = 20, reinforcements = -1, 
          soldier =           { "all_inf_rifleman_snow" }, 
          assault =           { "all_inf_rocketeer_snow" }, 
          engineer =           { "all_inf_engineer_snow" }, 
          sniper =           { "all_inf_sniper_snow" }, 
          officer =           { "all_inf_officer_snow" }, 
          special =           { "all_inf_wookiee_snow" }
         }, 
        imp =         { team = IMP, units = 20, reinforcements = -1, 
          soldier =           { "imp_inf_rifleman_snow" }, 
          assault =           { "imp_inf_rocketeer_snow" }, 
          engineer =           { "imp_inf_engineer" }, 
          sniper =           { "imp_inf_sniper_snow" }, 
          officer =           { "imp_inf_officer" }, 
          special =           { "imp_inf_dark_trooper" }
         }
       })
    SetHeroClass(IMP,"imp_hero_darthvader")
    SetHeroClass(ALL,"all_hero_luke_jedi")
    ClearWalkers()
    SetMemoryPoolSize("EntityWalker",0)
    AddWalkerType(0,0)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    SetMemoryPoolSize("CommandWalker",0)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("MountedTurret",26)
    SetMemoryPoolSize("Weapon",260)
    SetMemoryPoolSize("EntityLight",226)
    SetMemoryPoolSize("FlagItem",1)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("PowerupItem",24)
    SetMemoryPoolSize("Ordnance",45)
    SetMemoryPoolSize("EntityDroid",4)
    SetMemoryPoolSize("BaseHint",133)
    SetMemoryPoolSize("Obstacle",335)
    SetMemoryPoolSize("PathNode",180)
    SetMemoryPoolSize("Aimer",38)
    SetMemoryPoolSize("AmmoCounter",181)
    SetMemoryPoolSize("EnergyBar",181)
    SetMemoryPoolSize("EntityMine",24)
    SetMemoryPoolSize("EntitySoundStream",4)
    SetMemoryPoolSize("EntitySoundStatic",13)
    SetMemoryPoolSize("Navigator",40)
    SetMemoryPoolSize("OrdnanceTowCable",4)
    SetMemoryPoolSize("ParticleEmitter",375)
    SetMemoryPoolSize("ParticleEmitterInfoData",425)
    SetMemoryPoolSize("ParticleEmitterObject",192)
    SetMemoryPoolSize("TreeGridStack",285)
    SetMemoryPoolSize("UnitAgent",40)
    SetMemoryPoolSize("UnitController",40)
    SetMemoryPoolSize("Weapon",181)
    ReadDataFile("HOT\\hot1.lvl","hoth_ctf")
    SetSpawnDelay(10,0.25)
    SetDenseEnvironment("false")
    SetDefenderSnipeRange(170)
    AddDeathRegion("Death")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    OpenAudioStream("sound\\hot.lvl","hot1gcw")
    SetBleedingVoiceOver(ALL,ALL,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(ALL,IMP,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,ALL,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(IMP,IMP,"imp_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(2,"Allleaving")
    SetOutOfBoundsVoiceOver(1,"Impleaving")
    SetAmbientMusic(ALL,1,"all_hot_amb_start",0,1)
    SetAmbientMusic(ALL,0.5,"all_hot_amb_middle",1,1)
    SetAmbientMusic(ALL,0.25,"all_hot_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_hot_amb_start",0,1)
    SetAmbientMusic(IMP,0.5,"imp_hot_amb_middle",1,1)
    SetAmbientMusic(IMP,0.25,"imp_hot_amb_end",2,1)
    SetVictoryMusic(ALL,"all_hot_amb_victory")
    SetDefeatMusic(ALL,"all_hot_amb_defeat")
    SetVictoryMusic(IMP,"imp_hot_amb_victory")
    SetDefeatMusic(IMP,"imp_hot_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.94420999288559,0.065540999174118,0.3219830095768,-0.022350000217557,-500.48983764648,0.79747200012207,-68.773849487305)
    AddCameraShot(0.37119698524475,0.0081900004297495,-0.92829197645187,0.020481999963522,-473.38415527344,-17.880533218384,132.12680053711)
    AddCameraShot(0.92708301544189,0.020455999299884,-0.37420600652695,0.0082569997757673,-333.22155761719,0.67604297399521,-14.027347564697)
end

