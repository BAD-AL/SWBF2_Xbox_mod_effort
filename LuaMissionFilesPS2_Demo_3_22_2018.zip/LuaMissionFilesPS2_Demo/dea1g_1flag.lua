--dea1g_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("setup_teams")
ATT = 1
DEF = 2
ALL = ATT
IMP = DEF

function ScriptPostLoad()
    PlayAnimExtend()
    PlayAnimTakExtend()
    DisableBarriers("start_room_barrier")
    OnObjectRespawnName(PlayAnimExtend,"Panel-Chasm")
    OnObjectKillName(PlayAnimRetract,"Panel-Chasm")
    OnObjectRespawnName(PlayAnimTakExtend,"Panel-Tak")
    OnObjectKillName(PlayAnimTakRetract,"Panel-Tak")
    ctf = ObjectiveOneFlagCTF:New({ teamATT = 1, teamDEF = 2, textATT = "game.modes.1flag", textDEF = "game.modes.1flag2", captureLimit = 8, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "Flag_Home", captureRegionATT = "Team1Cap", captureRegionDEF = "Team2Cap", capRegionMarkerATT = "hud_objective_icon", capRegionMarkerDEF = "hud_objective_icon", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function PlayAnimExtend()
    PauseAnimation("bridgeclose")
    RewindAnimation("bridgeopen")
    PlayAnimation("bridgeopen")
    UnblockPlanningGraphArcs("Connection122")
    DisableBarriers("BridgeBarrier")
end

function PlayAnimRetract()
    PauseAnimation("bridgeopen")
    RewindAnimation("bridgeclose")
    PlayAnimation("bridgeclose")
    BlockPlanningGraphArcs("Connection122")
    EnableBarriers("BridgeBarrier")
end

function PlayAnimTakExtend()
    PauseAnimation("CTFBridgeOpen")
    RewindAnimation("CTFBridgeClose")
    PlayAnimation("CTFBridgeClose")
    UnblockPlanningGraphArcs("Connection128")
    DisableBarriers("Barrier222")
end

function PlayAnimTakRetract()
    PauseAnimation("CTFBridgeClose")
    RewindAnimation("CTFBridgeOpen")
    PlayAnimation("CTFBridgeOpen")
    BlockPlanningGraphArcs("Connection128")
    EnableBarriers("Barrier222")
end

function ScriptInit()
    SetPS2ModelMemory(4000000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\dea.lvl;dea1gcw")
    SetMaxFlyHeight(72)
    SetMaxPlayerFlyHeight(72)
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_fleet","all_inf_rocketeer_fleet","all_inf_engineer_fleet","all_inf_sniper_fleet","all_inf_officer","all_hero_luke_jedi","all_inf_wookiee")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper")
    ReadDataFile("SIDE\\imp.lvl","imp_hero_emperor")
    SetupTeams({ 
        all =         { team = ALL, units = 25, reinforcements = 250, 
          soldier =           { "all_inf_rifleman_fleet", 10 }, 
          assault =           { "all_inf_rocketeer_fleet", 3 }, 
          engineer =           { "all_inf_engineer_fleet", 3 }, 
          sniper =           { "all_inf_sniper_fleet", 3 }, 
          officer =           { "all_inf_officer", 3 }, 
          special =           { "all_inf_wookiee", 3 }
         }, 
        imp =         { team = IMP, units = 25, reinforcements = 250, 
          soldier =           { "imp_inf_rifleman", 10 }, 
          assault =           { "imp_inf_rocketeer", 3 }, 
          engineer =           { "imp_inf_engineer", 3 }, 
          sniper =           { "imp_inf_sniper", 3 }, 
          officer =           { "imp_inf_officer", 3 }, 
          special =           { "imp_inf_dark_trooper", 3 }
         }
       })
    SetHeroClass(ALL,"all_hero_luke_jedi")
    SetHeroClass(IMP,"imp_hero_emperor")
    ClearWalkers()
    SetMemoryPoolSize("EntityLight",170)
    SetMemoryPoolSize("EntityHover",0)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("SoundSpaceRegion",105)
    SetMemoryPoolSize("EntitySoundStream",55)
    SetMemoryPoolSize("Obstacle",260)
    SetMemoryPoolSize("Weapon",260)
    SetMemoryPoolSize("FlagItem",1)
    SetMemoryPoolSize("RedOmniLight",130)
    SetUnitCount(ATT,25)
    SetReinforcementCount(ATT,-1)
    SetUnitCount(DEF,25)
    SetReinforcementCount(DEF,-1)
    SetSpawnDelay(10,0.25)
    ReadDataFile("dea\\dea1.lvl","dea1_CTF-SingleFlag")
    SetDenseEnvironment("true")
    AddDeathRegion("DeathRegion01")
    AddDeathRegion("DeathRegion02")
    AddDeathRegion("DeathRegion03")
    AddDeathRegion("DeathRegion04")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\dea.lvl","dea1")
    OpenAudioStream("sound\\dea.lvl","dea1")
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"all_dea_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_dea_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_dea_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_dea_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_dea_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_dea_amb_end",2,1)
    SetVictoryMusic(ALL,"all_dea_amb_victory")
    SetDefeatMusic(ALL,"all_dea_amb_defeat")
    SetVictoryMusic(IMP,"imp_dea_amb_victory")
    SetDefeatMusic(IMP,"imp_dea_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.99765402078629,0.066982001066208,0.014139000326395,-0.00094900000840425,155.1371307373,0.91150498390198,-138.07707214355)
    AddCameraShot(0.72976100444794,0.019262000918388,0.68319398164749,-0.018032999709249,-98.584869384766,0.29528400301933,263.23928833008)
    AddCameraShot(0.69427698850632,0.0051000001840293,0.71967101097107,-0.0052869999781251,-11.105946540833,-2.7532069683075,67.982200622559)
end

