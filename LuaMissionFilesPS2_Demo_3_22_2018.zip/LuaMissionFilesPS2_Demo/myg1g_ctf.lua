--myg1g_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
ALL = 1
IMP = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    DisableBarriers("shield_01")
    DisableBarriers("shield_02")
    DisableBarriers("shield_03")
    DisableBarriers("corebar1")
    DisableBarriers("corebar2")
    DisableBarriers("corebar3")
    DisableBarriers("corebar4")
    SetProperty("flag1","GeometryName","com_icon_alliance_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_alliance_flag")
    SetProperty("flag2","GeometryName","com_icon_imperial_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_imperial_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 8, textATT = "game.modes.CTF", textDEF = "game.modes.CTF2", hideCPs = true, multiplayerRules = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag1_home", captureRegion = "flag2_home", capRegionMarker = "all_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag2_home", captureRegion = "flag1_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(4100000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\myg.lvl;myg1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_inf_officer","all_hero_luke_jedi","all_inf_wookiee","all_hover_combatspeeder")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_officer","imp_inf_sniper","imp_inf_engineer","imp_inf_dark_trooper","imp_hero_bobafett","imp_hover_fightertank","imp_hover_speederbike","imp_walk_atst")
    ReadDataFile("SIDE\\tur.lvl","tur_bldg_recoilless_lg")
    SetupTeams({ 
        all =         { team = ALL, units = 25, reinforcements = -1, 
          soldier =           { "all_inf_rifleman" }, 
          assault =           { "all_inf_rocketeer" }, 
          engineer =           { "all_inf_engineer" }, 
          sniper =           { "all_inf_sniper" }, 
          officer =           { "all_inf_officer" }, 
          special =           { "all_inf_wookiee" }
         }, 
        imp =         { team = IMP, units = 25, reinforcements = -1, 
          soldier =           { "imp_inf_rifleman" }, 
          assault =           { "imp_inf_rocketeer" }, 
          engineer =           { "imp_inf_engineer" }, 
          sniper =           { "imp_inf_sniper" }, 
          officer =           { "imp_inf_officer" }, 
          special =           { "imp_inf_dark_trooper", 2, 5 }
         }
       })
    SetHeroClass(IMP,"imp_hero_bobafett")
    SetHeroClass(ALL,"all_hero_luke_jedi")
    ClearWalkers()
    AddWalkerType(1,0)
    SetMemoryPoolSize("EntityHover",8)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("Weapon",260)
    SetMemoryPoolSize("Decal",0)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("MountedTurret",14)
    SetMemoryPoolSize("PowerupItem",36)
    SetMemoryPoolSize("EntityMine",24)
    SetMemoryPoolSize("EntityLight",36)
    SetMemoryPoolSize("Aimer",80)
    SetMemoryPoolSize("Obstacle",440)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("ParticleEmitter",350)
    SetMemoryPoolSize("ParticleEmitterInfoData",512)
    SetMemoryPoolSize("ParticleEmitterObject",200)
    SetMemoryPoolSize("PathNode",512)
    SetMemoryPoolSize("TreeGridStack",300)
    SetMemoryPoolSize("Ordnance",70)
    SetSpawnDelay(10,0.25)
    ReadDataFile("myg\\myg1.lvl","myg1_ctf")
    SetDenseEnvironment("false")
    AddDeathRegion("deathregion")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\myg.lvl","myg1gcw")
    OpenAudioStream("sound\\myg.lvl","myg1gcw")
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"all_myg_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_myg_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_myg_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_myg_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_myg_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_myg_amb_end",2,1)
    SetVictoryMusic(ALL,"all_myg_amb_victory")
    SetDefeatMusic(ALL,"all_myg_amb_defeat")
    SetVictoryMusic(IMP,"imp_myg_amb_victory")
    SetDefeatMusic(IMP,"imp_myg_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.94799000024796,-0.029190000146627,0.31680798530579,0.0097549995407462,-88.997039794922,14.15385055542,-17.227827072144)
    AddCameraShot(0.96342700719833,-0.26038599014282,-0.061110001057386,-0.016516000032425,-118.96892547607,39.055625915527,124.03238677979)
    AddCameraShot(0.73388397693634,-0.18114300072193,0.63560098409653,0.15688399970531,67.597633361816,39.055625915527,55.312774658203)
    AddCameraShot(0.0083149997517467,9.9999999747524e-007,-0.99996501207352,7.4000003223773e-005,-64.894348144531,5.541570186615,201.71109008789)
end

