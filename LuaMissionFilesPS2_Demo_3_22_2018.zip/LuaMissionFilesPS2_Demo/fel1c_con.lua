--fel1c_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveConquest")

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "cp1-1" })
    cp2 = CommandPost:New({ name = "cp2-1" })
    cp3 = CommandPost:New({ name = "cp3-1" })
    cp4 = CommandPost:New({ name = "cp4-1" })
    cp5 = CommandPost:New({ name = "cp5-1" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(3200000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\fel.lvl;fel1cw")
    SetMaxFlyHeight(53)
    SetMaxPlayerFlyHeight(53)
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper_felucia","rep_inf_ep3_jettrooper","rep_inf_ep3_officer","rep_hero_aalya")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","CIS_inf_officer","cis_inf_droideka","cis_hero_jangofett")
    SetAttackingTeam(1)
    SetupTeams({ 
        rep =         { team = 1, units = 25, reinforcements = 250, 
          soldier =           { "rep_inf_ep3_rifleman" }, 
          assault =           { "rep_inf_ep3_rocketeer" }, 
          engineer =           { "rep_inf_ep3_engineer" }, 
          sniper =           { "rep_inf_ep3_sniper_felucia" }, 
          officer =           { "rep_inf_ep3_officer" }, 
          special =           { "rep_inf_ep3_jettrooper" }
         }, 
        cis =         { team = 2, units = 25, reinforcements = 250, 
          soldier =           { "CIS_inf_rifleman" }, 
          assault =           { "CIS_inf_rocketeer" }, 
          engineer =           { "CIS_inf_engineer" }, 
          sniper =           { "CIS_inf_sniper" }, 
          officer =           { "CIS_inf_officer" }, 
          special =           { "cis_inf_droideka" }
         }
       })
    SetHeroClass(1,"rep_HERO_aalya")
    SetHeroClass(2,"cis_hero_jangofett")
    ClearWalkers()
    SetMemoryPoolSize("EntityWalker",5)
    AddWalkerType(5,2)
    AddWalkerType(3,1)
    SetMemoryPoolSize("Aimer",75)
    SetMemoryPoolSize("TreeGridStack",280)
    SetMemoryPoolSize("BaseHint",100)
    SetMemoryPoolSize("Obstacle",500)
    SetSpawnDelay(10,0.25)
    ReadDataFile("fel\\fel1.lvl","fel1_conquest")
    SetDenseEnvironment("false")
    SetAIViewMultiplier(0.46999999880791)
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\fel.lvl","fel1")
    OpenAudioStream("sound\\fel.lvl","fel1")
    SetBleedingVoiceOver(1,1,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(1,2,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(2,1,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(2,2,"cis_off_com_report_us_overwhelmed",1)
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(1,1,"rep_fel_amb_start",0,1)
    SetAmbientMusic(1,0.89999997615814,"rep_fel_amb_middle",1,1)
    SetAmbientMusic(1,0.10000000149012,"rep_fel_amb_end",2,1)
    SetAmbientMusic(2,1,"cis_fel_amb_start",0,1)
    SetAmbientMusic(2,0.89999997615814,"cis_fel_amb_middle",1,1)
    SetAmbientMusic(2,0.10000000149012,"cis_fel_amb_end",2,1)
    SetVictoryMusic(1,"rep_fel_amb_victory")
    SetDefeatMusic(1,"rep_fel_amb_defeat")
    SetVictoryMusic(2,"cis_fel_amb_victory")
    SetDefeatMusic(2,"cis_fel_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.89630699157715,-0.17134800553322,-0.40171599388123,-0.076796002686024,-116.30693054199,31.039505004883,20.757469177246)
    AddCameraShot(0.90934300422668,-0.2019670009613,-0.35508298873901,-0.078864999115467,-116.30693054199,31.039505004883,20.757469177246)
    AddCameraShot(0.54319900274277,0.11552099883556,-0.81342798471451,0.17298999428749,-108.37818908691,13.564240455627,-40.644149780273)
    AddCameraShot(0.97061002254486,0.13565899431705,0.1968660056591,-0.027514999732375,-3.2143459320068,11.924586296082,-44.687294006348)
    AddCameraShot(0.34613001346588,0.046310998499393,-0.92876601219177,0.12426699697971,87.431060791016,20.881387710571,13.070729255676)
    AddCameraShot(0.4680840075016,0.095610998570919,-0.86072397232056,0.1758120059967,18.063482284546,19.360580444336,18.178157806396)
end

