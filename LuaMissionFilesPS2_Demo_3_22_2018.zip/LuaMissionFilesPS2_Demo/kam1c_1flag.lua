--kam1c_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveOneFlagCTF")

function ScriptPostLoad()
    SetProperty("cp1","CaptureRegion","DEATH")
    SetProperty("cp2","CaptureRegion","DEATH")
    SetProperty("cp3","CaptureRegion","DEATH")
    SetProperty("cp4","CaptureRegion","DEATH")
    SetProperty("cp5","CaptureRegion","DEATH")
    SetProperty("cp2","SpawnPath","cp2_spawn")
    UnblockPlanningGraphArcs("connection71")
    SetAIDamageThreshold("Comp1",0)
    SetAIDamageThreshold("Comp2",0)
    SetAIDamageThreshold("Comp3",0)
    SetAIDamageThreshold("Comp4",0)
    SetAIDamageThreshold("Comp5",0)
    SetProperty("Kam_Bldg_Podroom_Door32","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door33","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door32","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door34","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door35","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door27","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door28","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door36","Islocked",1)
    SetProperty("Kam_Bldg_Podroom_Door20","Islocked",1)
    UnblockPlanningGraphArcs("connection71")
    UnblockPlanningGraphArcs("connection85")
    UnblockPlanningGraphArcs("connection48")
    UnblockPlanningGraphArcs("connection63")
    UnblockPlanningGraphArcs("connection59")
    UnblockPlanningGraphArcs("close")
    UnblockPlanningGraphArcs("open")
    EnableBarriers("frog")
    EnableBarriers("close")
    EnableBarriers("open")
    UnblockPlanningGraphArcs("connection194")
    UnblockPlanningGraphArcs("connection200")
    UnblockPlanningGraphArcs("connection118")
    EnableBarriers("frontdoor2-3")
    EnableBarriers("frontdoor2-1")
    EnableBarriers("frontdoor2-2")
    UnblockPlanningGraphArcs("connection10")
    UnblockPlanningGraphArcs("connection159")
    UnblockPlanningGraphArcs("connection31")
    EnableBarriers("frontdoor1-3")
    EnableBarriers("frontdoor1-1")
    EnableBarriers("frontdoor1-2")
    EnableSPHeroRules()
    ctf = ObjectiveOneFlagCTF:New({ teamATT = 1, teamDEF = 2, textATT = "game.mode.1flag", textDEF = "game.mode.1flag2", captureLimit = 8, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "flag_home", captureRegionATT = "lag_capture2", captureRegionDEF = "lag_capture1", capRegionMarkerATT = "hud_objective_icon", capRegionMarkerDEF = "hud_objective_icon", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3, hideCPs = true, multiplayerRules = true })
    ctf:Start()
end

function ScriptInit()
    SetPS2ModelMemory(3000000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\kam.lvl;kam1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_jettrooper","rep_hero_obiwan","rep_inf_ep3_officer")
    ReadDataFile("SIDE\\cis.lvl","cis_fly_fedlander_dome","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_hero_jangofett","cis_inf_droideka","CIS_inf_officer")
    SetAttackingTeam(1)
    SetupTeams({ 
        REP =         { team = 2, units = 25, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman" }, 
          assault =           { "rep_inf_ep3_rocketeer" }, 
          engineer =           { "rep_inf_ep3_engineer" }, 
          sniper =           { "rep_inf_ep3_sniper" }, 
          officer =           { "rep_inf_ep3_officer" }, 
          special =           { "rep_inf_ep3_jettrooper" }
         }
       })
    SetupTeams({ 
        CIS =         { team = 1, units = 25, reinforcements = -1, 
          soldier =           { "CIS_inf_rifleman" }, 
          assault =           { "CIS_inf_rocketeer" }, 
          engineer =           { "CIS_inf_engineer" }, 
          sniper =           { "CIS_inf_sniper" }, 
          officer =           { "CIS_inf_officer" }, 
          special =           { "cis_inf_droideka" }
         }
       })
    SetHeroClass(2,"rep_hero_obiwan")
    SetHeroClass(1,"cis_hero_jangofett")
    ClearWalkers()
    AddWalkerType(0,16)
    SetMemoryPoolSize("EntityLight",64)
    SetSpawnDelay(10,0.25)
    SetMemoryPoolSize("FlagItem",2)
    ReadDataFile("KAM\\kam1.lvl","kamino1_1CTF")
    SetDenseEnvironment("false")
    SetMinFlyHeight(60)
    SetMaxFlyHeight(140)
    SetAllowBlindJetJumps(0)
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\kam.lvl","kam1")
    OpenAudioStream("sound\\kam.lvl","kam1")
    SetAmbientMusic(2,1,"rep_kam_amb_start",0,1)
    SetAmbientMusic(2,0.89999997615814,"rep_kam_amb_middle",1,1)
    SetAmbientMusic(2,0.10000000149012,"rep_kam_amb_end",2,1)
    SetAmbientMusic(1,1,"cis_kam_amb_start",0,1)
    SetAmbientMusic(1,0.89999997615814,"cis_kam_amb_middle",1,1)
    SetAmbientMusic(1,0.10000000149012,"cis_kam_amb_end",2,1)
    SetVictoryMusic(2,"rep_kam_amb_victory")
    SetDefeatMusic(2,"rep_kam_amb_defeat")
    SetVictoryMusic(1,"cis_kam_amb_victory")
    SetDefeatMusic(1,"cis_kam_amb_defeat")
    SetOutOfBoundsVoiceOver(2,"repleaving")
    SetOutOfBoundsVoiceOver(1,"cisleaving")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(1)
    AddDeathRegion("DeathRegion")
    AddCameraShot(0.19047799706459,-0.010944999754429,-0.98001402616501,-0.056311998516321,-26.091287612915,55.96501159668,159.45809936523)
    AddCameraShot(-0.37657099962234,-0.019636999815702,-0.92492300271988,0.04823200032115,176.04246520996,53.957565307617,244.26113891602)
    AddCameraShot(0.63925397396088,-0.073532998561859,0.76045697927475,0.087475001811981,78.395347595215,72.538581848145,344.08660888672)
end

