--fel1g_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("ObjectiveCTF")
ATT = 1
DEF = 2
IMP = DEF
ALL = ATT

function ScriptPostLoad()
    SetProperty("flag1","GeometryName","com_icon_alliance_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_alliance_flag")
    SetProperty("flag2","GeometryName","com_icon_imperial_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_imperial_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 8, textATT = "game.modes.ctf", textDEF = "game.modes.ctf2", multiplayerRules = true, hideCPs = true })
    ctf:AddFlag({ name = "flag1", homeRegion = "flag1_home", captureRegion = "flag2_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "flag2", homeRegion = "flag2_home", captureRegion = "flag1_home", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(3200000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\fel.lvl;fel1gcw")
    SetMaxFlyHeight(53)
    SetMaxPlayerFlyHeight(53)
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_jungle","all_inf_rocketeer_jungle","all_inf_sniper_jungle","all_inf_engineer_jungle","all_inf_officer_jungle","all_inf_wookiee","all_hero_chewbacca","all_hover_combatspeeder")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_bobafett","imp_walk_atst_jungle")
    SetupTeams({ 
        all =         { team = 1, units = 25, reinforcements = -1, 
          soldier =           { "all_inf_rifleman_jungle" }, 
          assault =           { "all_inf_rocketeer_jungle" }, 
          engineer =           { "all_inf_engineer_jungle" }, 
          sniper =           { "all_inf_sniper_jungle" }, 
          officer =           { "all_inf_officer_jungle" }, 
          special =           { "all_inf_wookiee" }
         }, 
        imp =         { team = 2, units = 25, reinforcements = -1, 
          soldier =           { "imp_inf_rifleman" }, 
          assault =           { "imp_inf_rocketeer" }, 
          engineer =           { "imp_inf_engineer" }, 
          sniper =           { "imp_inf_sniper" }, 
          officer =           { "imp_inf_officer" }, 
          special =           { "imp_inf_dark_trooper" }
         }
       })
    SetHeroClass(ALL,"all_hero_chewbacca")
    SetHeroClass(IMP,"imp_hero_bobafett")
    ClearWalkers()
    SetMemoryPoolSize("EntityWalker",3)
    AddWalkerType(2,2)
    SetMemoryPoolSize("EntityHover",4)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("Obstacle",340)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("TreeGridStack",261)
    SetMemoryPoolSize("Weapon",230)
    SetMemoryPoolSize("Aimer",75)
    SetSpawnDelay(10,0.25)
    ReadDataFile("fel\\fel1.lvl","fel1_ctf")
    SetDenseEnvironment("false")
    SetAIViewMultiplier(0.44999998807907)
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\fel.lvl","fel1")
    OpenAudioStream("sound\\fel.lvl","fel1")
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"all_fel_amb_start",0,1)
    SetAmbientMusic(ALL,0.99000000953674,"all_fel_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_fel_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_fel_amb_start",0,1)
    SetAmbientMusic(IMP,0.99000000953674,"imp_fel_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_fel_amb_end",2,1)
    SetVictoryMusic(ALL,"all_fel_amb_victory")
    SetDefeatMusic(ALL,"all_fel_amb_defeat")
    SetVictoryMusic(IMP,"imp_fel_amb_victory")
    SetDefeatMusic(IMP,"imp_fel_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(0.89630699157715,-0.17134800553322,-0.40171599388123,-0.076796002686024,-116.30693054199,31.039505004883,20.757469177246)
    AddCameraShot(0.90934300422668,-0.2019670009613,-0.35508298873901,-0.078864999115467,-116.30693054199,31.039505004883,20.757469177246)
    AddCameraShot(0.54319900274277,0.11552099883556,-0.81342798471451,0.17298999428749,-108.37818908691,13.564240455627,-40.644149780273)
    AddCameraShot(0.97061002254486,0.13565899431705,0.1968660056591,-0.027514999732375,-3.2143459320068,11.924586296082,-44.687294006348)
    AddCameraShot(0.34613001346588,0.046310998499393,-0.92876601219177,0.12426699697971,87.431060791016,20.881387710571,13.070729255676)
    AddCameraShot(0.4680840075016,0.095610998570919,-0.86072397232056,0.1758120059967,18.063482284546,19.360580444336,18.178157806396)
end

