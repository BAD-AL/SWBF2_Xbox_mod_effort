--nab2c_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveCTF")
ScriptCB_DoFile("setup_teams")

function ScriptPostLoad()
    EnableSPHeroRules()
    SetProperty("flag1","GeometryName","com_icon_cis_flag")
    SetProperty("flag1","CarriedGeometryName","com_icon_cis_flag")
    SetProperty("flag2","GeometryName","com_icon_republic_flag")
    SetProperty("flag2","CarriedGeometryName","com_icon_republic_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 8, text = "level.geo1.objectives.ctf", hideCPs = false, multiplayerRules = true })
    ctf:AddFlag({ name = "Flag1", homeRegion = "FlagHome1", captureRegion = "FlagHome2", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "Flag2", homeRegion = "FlagHome2", captureRegion = "FlagHome1", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
end

function ScriptInit()
    SetPS2ModelMemory(4000000)
    ReadDataFile("ingame.lvl")
    SetMapNorthAngle(0)
    ReadDataFile("sound\\nab.lvl;nab2cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper","rep_hero_obiwan")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka","cis_hero_darthmaul")
    SetupTeams({ 
        rep =         { team = 2, units = 25, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman", 11 }, 
          assault =           { "rep_inf_ep3_rocketeer", 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 3 }, 
          sniper =           { "rep_inf_ep3_sniper", 2 }, 
          officer =           { "rep_inf_ep3_officer", 2 }, 
          special =           { "rep_inf_ep3_jettrooper", 3 }
         }, 
        cis =         { team = 1, units = 25, reinforcements = -1, 
          soldier =           { "cis_inf_rifleman", 11 }, 
          assault =           { "cis_inf_rocketeer", 4 }, 
          engineer =           { "cis_inf_engineer", 3 }, 
          sniper =           { "cis_inf_sniper", 2 }, 
          officer =           { "cis_inf_officer", 2 }, 
          special =           { "cis_inf_droideka", 3 }
         }
       })
    SetHeroClass(1,"cis_hero_darthmaul")
    SetHeroClass(2,"rep_hero_obiwan")
    ClearWalkers()
    AddWalkerType(0,3)
    SetMemoryPoolSize("Aimer",13)
    SetMemoryPoolSize("AmmoCounter",150)
    SetMemoryPoolSize("BaseHint",256)
    SetMemoryPoolSize("EnergyBar",150)
    SetMemoryPoolSize("EntityHover",0)
    SetMemoryPoolSize("EntitySoundStream",1)
    SetMemoryPoolSize("EntitySoundStatic",41)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("MountedTurret",4)
    SetMemoryPoolSize("Navigator",50)
    SetMemoryPoolSize("Obstacle",450)
    SetMemoryPoolSize("PathFollower",50)
    SetMemoryPoolSize("PathNode",300)
    SetMemoryPoolSize("UnitAgent",50)
    SetMemoryPoolSize("UnitController",50)
    SetMemoryPoolSize("Weapon",150)
    SetSpawnDelay(10,0.25)
    ReadDataFile("NAB\\nab2.lvl","naboo2_CTF")
    SetDenseEnvironment("true")
    AddDeathRegion("Water")
    AddDeathRegion("Waterfall")
    SetNumBirdTypes(1)
    SetBirdType(0,1,"bird")
    SetBirdFlockMinHeight(-28)
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\nab.lvl","nab2")
    OpenAudioStream("sound\\nab.lvl","nab2")
    OpenAudioStream("sound\\nab.lvl","nab2_emt")
    SetOutOfBoundsVoiceOver(2,"repleaving")
    SetOutOfBoundsVoiceOver(1,"cisleaving")
    SetAmbientMusic(2,1,"rep_nab_amb_start",0,1)
    SetAmbientMusic(2,0.89999997615814,"rep_nab_amb_middle",1,1)
    SetAmbientMusic(2,0.10000000149012,"rep_nab_amb_end",2,1)
    SetAmbientMusic(1,1,"cis_nab_amb_start",0,1)
    SetAmbientMusic(1,0.89999997615814,"cis_nab_amb_middle",1,1)
    SetAmbientMusic(1,0.10000000149012,"cis_nab_amb_end",2,1)
    SetVictoryMusic(2,"rep_nab_amb_victory")
    SetDefeatMusic(2,"rep_nab_amb_defeat")
    SetVictoryMusic(1,"cis_nab_amb_victory")
    SetDefeatMusic(1,"cis_nab_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.007592000067234,-1.9999999949505e-006,-0.99997097253799,0.00020900000527035,-168.55972290039,-45.250122070313,13.399480819702)
    AddCameraShot(0.25503298640251,0.0037889999803156,-0.96681797504425,0.014364999718964,-45.806968688965,-47.785381317139,-45.429058074951)
    AddCameraShot(0.62141698598862,-0.11941699683666,-0.76041197776794,-0.14612799882889,-276.06744384766,-18.259653091431,-77.929229736328)
end

