--setup_teams.lua
-- Decompiled with SWBF2CodeHelper

function SetupTeams(SetupTeamsParam0)
    ScriptCB_IsMissionSetupSaved()
    ERROR_PROCESSING_FUNCTION = true
end

