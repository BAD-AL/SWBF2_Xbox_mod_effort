--dag1c_con.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveConquest")
ScriptCB_DoFile("setup_teams")
REP = 1
CIS = 2
ATT = 1
DEF = 2

function ScriptPostLoad()
    cp1 = CommandPost:New({ name = "cp1" })
    cp2 = CommandPost:New({ name = "cp2" })
    cp3 = CommandPost:New({ name = "cp3" })
    cp4 = CommandPost:New({ name = "cp4" })
    cp5 = CommandPost:New({ name = "cp5" })
    conquest = ObjectiveConquest:New({ teamATT = ATT, teamDEF = DEF, textATT = "game.modes.con", textDEF = "game.modes.con2", multiplayerRules = true })
    conquest:AddCommandPost(cp1)
    conquest:AddCommandPost(cp2)
    conquest:AddCommandPost(cp3)
    conquest:AddCommandPost(cp4)
    conquest:AddCommandPost(cp5)
    conquest:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(2497152 + 65536 * 0)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\dag.lvl;dag1cw")
    SetMaxFlyHeight(20)
    SetMaxPlayerFlyHeight(20)
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep3_rifleman","rep_inf_ep3_rocketeer","rep_inf_ep3_engineer","rep_inf_ep3_sniper","rep_inf_ep3_officer","rep_inf_ep3_jettrooper","rep_hero_yoda")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_officer","cis_inf_sniper","cis_inf_droideka","cis_hero_grievous")
    ClearWalkers()
    AddWalkerType(0,3)
    SetMemoryPoolSize("Aimer",9)
    SetMemoryPoolSize("BaseHint",128)
    SetMemoryPoolSize("EntitySoundStream",1)
    SetMemoryPoolSize("EntitySoundStatic",1)
    SetMemoryPoolSize("MountedTurret",0)
    SetMemoryPoolSize("Obstacle",136)
    SetMemoryPoolSize("TreeGridStack",300)
    SetMemoryPoolSize("Weapon",135)
    SetupTeams({ 
        rep =         { team = REP, units = 25, reinforcements = -1, 
          soldier =           { "rep_inf_ep3_rifleman", 11 }, 
          assault =           { "rep_inf_ep3_rocketeer", 4 }, 
          engineer =           { "rep_inf_ep3_engineer", 3 }, 
          sniper =           { "rep_inf_ep3_sniper", 2 }, 
          officer =           { "rep_inf_ep3_officer", 2 }, 
          special =           { "rep_inf_ep3_jettrooper", 3 }
         }, 
        cis =         { team = CIS, units = 25, reinforcements = -1, 
          soldier =           { "cis_inf_rifleman", 11 }, 
          assault =           { "cis_inf_rocketeer", 4 }, 
          engineer =           { "cis_inf_engineer", 3 }, 
          sniper =           { "cis_inf_sniper", 2 }, 
          officer =           { "cis_inf_officer", 2 }, 
          special =           { "cis_inf_droideka", 3 }
         }
       })
    SetHeroClass(REP,"rep_hero_yoda")
    SetHeroClass(CIS,"cis_hero_grievous")
    SetUnitCount(ATT,25)
    SetReinforcementCount(ATT,200)
    SetUnitCount(DEF,25)
    SetReinforcementCount(DEF,200)
    SetSpawnDelay(10,0.25)
    ReadDataFile("dag\\dag1.lvl","dag1_conquest","dag1_cw")
    SetDenseEnvironment("false")
    SetAIViewMultiplier(0.34999999403954)
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\dag.lvl","dag1")
    OpenAudioStream("sound\\dag.lvl","dag1")
    SetBleedingVoiceOver(REP,REP,"rep_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(REP,CIS,"rep_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,REP,"cis_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(CIS,CIS,"cis_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(REP,REP,"rep_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(REP,CIS,"rep_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,CIS,"cis_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(CIS,REP,"cis_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"Repleaving")
    SetOutOfBoundsVoiceOver(2,"Cisleaving")
    SetAmbientMusic(REP,1,"rep_dag_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_dag_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_dag_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_dag_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_dag_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_dag_amb_end",2,1)
    SetVictoryMusic(REP,"rep_dag_amb_victory")
    SetDefeatMusic(REP,"rep_dag_amb_defeat")
    SetVictoryMusic(CIS,"cis_dag_amb_victory")
    SetDefeatMusic(CIS,"cis_dag_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    AddCameraShot(-0.40489500761032,0.0009919999865815,-0.91435998678207,-0.0022400000598282,-85.539894104004,20.536296844482,141.6994934082)
    AddCameraShot(0.040922001004219,0.004048999864608,-0.99429899454117,0.098380997776985,-139.72952270508,17.546598434448,-34.360893249512)
    AddCameraShot(-0.31235998868942,0.016223000362515,-0.94854700565338,-0.049263000488281,-217.38148498535,20.150953292847,54.514324188232)
end

