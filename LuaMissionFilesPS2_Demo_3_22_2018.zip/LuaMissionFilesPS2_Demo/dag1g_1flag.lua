--dag1g_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("setup_teams")

function ScriptPostLoad()
    ctf = ObjectiveOneFlagCTF:New({ teamATT = 1, teamDEF = 2, textATT = "game.modes.1flag", textDEF = "game.modes.1flag2", captureLimit = 8, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "1flag_team1_capture", captureRegionATT = "1flag_team1_capture", captureRegionDEF = "1flag_team2_capture", capRegionMarkerATT = "hud_objective_icon_circle", capRegionMarkerDEF = "hud_objective_icon_circle", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3, multiplayerRules = true })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(2500000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\dag.lvl;dag1gcw")
    SetNumBirdTypes(2)
    SetBirdType(0,1,"bird")
    SetBirdType(1,1.5,"bird2")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    SetMaxFlyHeight(20)
    SetMaxPlayerFlyHeight(20)
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman_jungle","all_inf_rocketeer_jungle","all_inf_engineer","all_inf_sniper_jungle","all_inf_officer","all_inf_wookiee")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_officer","imp_inf_dark_trooper","imp_hero_darthvader")
    ReadDataFile("SIDE\\rep.lvl","rep_hero_yoda")
    ClearWalkers()
    SetMemoryPoolSize("EntityHover",0)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("Obstacle",136)
    SetMemoryPoolSize("Weapon",260)
    SetMemoryPoolSize("FlagItem",1)
    SetupTeams({ 
        all =         { team = 1, units = 25, reinforcements = 250, 
          soldier =           { "all_inf_rifleman_jungle", 10 }, 
          assault =           { "all_inf_rocketeer_jungle", 3 }, 
          engineer =           { "all_inf_engineer", 3 }, 
          sniper =           { "all_inf_sniper_jungle", 3 }, 
          officer =           { "all_inf_officer", 3 }, 
          special =           { "all_inf_wookiee", 3 }
         }, 
        imp =         { team = 2, units = 25, reinforcements = 250, 
          soldier =           { "imp_inf_rifleman", 10 }, 
          assault =           { "imp_inf_rocketeer", 3 }, 
          engineer =           { "imp_inf_engineer", 3 }, 
          sniper =           { "imp_inf_sniper", 3 }, 
          officer =           { "imp_inf_officer", 3 }, 
          special =           { "imp_inf_dark_trooper", 3 }
         }
       })
    SetHeroClass(1,"rep_hero_yoda")
    SetHeroClass(2,"imp_hero_darthvader")
    SetUnitCount(1,25)
    SetReinforcementCount(1,200)
    SetUnitCount(2,25)
    SetReinforcementCount(2,200)
    SetSpawnDelay(10,0.25)
    ReadDataFile("dag\\dag1.lvl","dag1_1flag","dag1_gcw")
    SetDenseEnvironment("false")
    SetAIViewMultiplier(0.34999999403954)
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\dag.lvl","dag1")
    OpenAudioStream("sound\\dag.lvl","dag1")
    SetBleedingVoiceOver(1,1,"all_off_com_report_us_overwhelmed",1)
    SetBleedingVoiceOver(1,2,"all_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(2,1,"imp_off_com_report_enemy_losing",1)
    SetBleedingVoiceOver(2,2,"imp_off_com_report_us_overwhelmed",1)
    SetLowReinforcementsVoiceOver(1,1,"all_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(1,2,"all_off_victory_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(2,2,"imp_off_defeat_im",0.10000000149012,1)
    SetLowReinforcementsVoiceOver(2,1,"imp_off_victory_im",0.10000000149012,1)
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(1,1,"all_dag_amb_start",0,1)
    SetAmbientMusic(1,0.89999997615814,"all_dag_amb_middle",1,1)
    SetAmbientMusic(1,0.10000000149012,"all_dag_amb_end",2,1)
    SetAmbientMusic(2,1,"imp_dag_amb_start",0,1)
    SetAmbientMusic(2,0.89999997615814,"imp_dag_amb_middle",1,1)
    SetAmbientMusic(2,0.10000000149012,"imp_dag_amb_end",2,1)
    SetVictoryMusic(1,"all_dag_amb_victory")
    SetDefeatMusic(1,"all_dag_amb_defeat")
    SetVictoryMusic(2,"imp_dag_amb_victory")
    SetDefeatMusic(2,"imp_dag_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(1)
    AddCameraShot(0.99765402078629,0.066982001066208,0.014139000326395,-0.00094900000840425,155.1371307373,0.91150498390198,-138.07707214355)
    AddCameraShot(0.72976100444794,0.019262000918388,0.68319398164749,-0.018032999709249,-98.584869384766,0.29528400301933,263.23928833008)
    AddCameraShot(0.69427698850632,0.0051000001840293,0.71967101097107,-0.0052869999781251,-11.105946540833,-2.7532069683075,67.982200622559)
end

