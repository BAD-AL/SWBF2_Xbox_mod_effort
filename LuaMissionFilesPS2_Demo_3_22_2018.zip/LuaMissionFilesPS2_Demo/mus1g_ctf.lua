--mus1g_ctf.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("setup_teams")
ScriptCB_DoFile("objectivectf")
ATT = 1
DEF = 2
IMP = ATT
ALL = DEF

function ScriptPostLoad()
    PlayAnimRise()
    DisableBarriers("BALCONEY")
    DisableBarriers("bALCONEY2")
    DisableBarriers("hallway_f")
    DisableBarriers("hackdoor")
    DisableBarriers("outside")
    OnObjectRespawnName(PlayAnimRise,"DingDong")
    OnObjectKillName(PlayAnimRise,"DingDong")
    SetProperty("FLAG1","GeometryName","com_icon_alliance_flag")
    SetProperty("FLAG1","CarriedGeometryName","com_icon_alliance_flag")
    SetProperty("FLAG2","GeometryName","com_icon_imperial_flag")
    SetProperty("FLAG2","CarriedGeometryName","com_icon_imperial_flag")
    SetClassProperty("com_item_flag","DroppedColorize",1)
    ctf = ObjectiveCTF:New({ teamATT = ATT, teamDEF = DEF, captureLimit = 8, textATT = "level.Kamino1.objectives.ctf.get", textDEF = "level.Kamino1.objectives.ctf.get1", multiplayerRules = true })
    ctf:AddFlag({ name = "FLAG1", homeRegion = "FLAG1_HOME", captureRegion = "FLAG2_HOME", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:AddFlag({ name = "FLAG2", homeRegion = "FLAG2_HOME", captureRegion = "FLAG1_HOME", capRegionMarker = "hud_objective_icon", capRegionMarkerScale = 3, icon = "", mapIcon = "flag_icon", mapIconScale = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function PlayAnimDrop()
    PauseAnimation("lava_bridge_raise")
    RewindAnimation("lava_bridge_drop")
    PlayAnimation("lava_bridge_drop")
    BlockPlanningGraphArcs("Connection82")
    BlockPlanningGraphArcs("Connection83")
    EnableBarriers("Bridge")
end

function PlayAnimRise()
    PauseAnimation("lava_bridge_drop")
    RewindAnimation("lava_bridge_raise")
    PlayAnimation("lava_bridge_raise")
    UnblockPlanningGraphArcs("Connection82")
    UnblockPlanningGraphArcs("Connection83")
    DisableBarriers("Bridge")
end

function ScriptInit()
    SetPS2ModelMemory(3400000)
    ReadDataFile("ingame.lvl")
    ReadDataFile("sound\\mus.lvl;mus1gcw")
    ReadDataFile("SIDE\\all.lvl","all_inf_rifleman","all_inf_rocketeer","all_inf_sniper","all_inf_engineer","all_inf_wookiee","all_inf_officer")
    ReadDataFile("SIDE\\imp.lvl","imp_inf_rifleman","imp_inf_rocketeer","imp_inf_engineer","imp_inf_sniper","imp_inf_dark_trooper","imp_inf_officer")
    ReadDataFile("SIDE\\rep.lvl","rep_hero_obiwan","rep_hero_anakin")
    ClearWalkers()
    SetMemoryPoolSize("EntityHover",0)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityDroid",10)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("Obstacle",250)
    SetMemoryPoolSize("Weapon",260)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("EntitySoundStatic",175)
    SetupTeams({ 
        all =         { team = ALL, units = 25, reinforcements = -1, 
          soldier =           { "all_inf_rifleman" }, 
          assault =           { "all_inf_rocketeer" }, 
          engineer =           { "all_inf_engineer" }, 
          sniper =           { "all_inf_sniper" }, 
          officer =           { "all_inf_officer" }, 
          special =           { "all_inf_wookiee" }
         }
       })
    SetupTeams({ 
        imp =         { team = IMP, units = 25, reinforcements = -1, 
          soldier =           { "imp_inf_rifleman" }, 
          assault =           { "imp_inf_rocketeer" }, 
          engineer =           { "imp_inf_engineer" }, 
          sniper =           { "imp_inf_sniper" }, 
          officer =           { "imp_inf_officer" }, 
          special =           { "imp_inf_dark_trooper" }
         }
       })
    SetHeroClass(ALL,"rep_hero_obiwan")
    SetHeroClass(IMP,"rep_hero_anakin")
    SetSpawnDelay(10,0.25)
    SetMemoryPoolSize("FlagItem",2)
    ReadDataFile("mus\\mus1.lvl","mus1_ctf")
    SetDenseEnvironment("false")
    voiceSlow = OpenAudioStream("sound\\global.lvl","all_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","all_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","imp_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","gcw_music")
    OpenAudioStream("sound\\mus.lvl","mus1")
    OpenAudioStream("sound\\mus.lvl","mus1")
    SetOutOfBoundsVoiceOver(1,"allleaving")
    SetOutOfBoundsVoiceOver(2,"impleaving")
    SetAmbientMusic(ALL,1,"all_mus_amb_start",0,1)
    SetAmbientMusic(ALL,0.89999997615814,"all_mus_amb_middle",1,1)
    SetAmbientMusic(ALL,0.10000000149012,"all_mus_amb_end",2,1)
    SetAmbientMusic(IMP,1,"imp_mus_amb_start",0,1)
    SetAmbientMusic(IMP,0.89999997615814,"imp_mus_amb_middle",1,1)
    SetAmbientMusic(IMP,0.10000000149012,"imp_mus_amb_end",2,1)
    SetVictoryMusic(ALL,"all_mus_amb_victory")
    SetDefeatMusic(ALL,"all_mus_amb_defeat")
    SetVictoryMusic(IMP,"imp_mus_amb_victory")
    SetDefeatMusic(IMP,"imp_mus_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.99765402078629,0.066982001066208,0.014139000326395,-0.00094900000840425,155.1371307373,0.91150498390198,-138.07707214355)
    AddCameraShot(0.72976100444794,0.019262000918388,0.68319398164749,-0.018032999709249,-98.584869384766,0.29528400301933,263.23928833008)
    AddCameraShot(0.69427698850632,0.0051000001840293,0.71967101097107,-0.0052869999781251,-11.105946540833,-2.7532069683075,67.982200622559)
end

