--yav1c_1flag.lua
-- Decompiled with SWBF2CodeHelper
ScriptCB_DoFile("ObjectiveOneFlagCTF")
ScriptCB_DoFile("setup_teams")
ATT = 1
DEF = 2
REP = ATT
CIS = DEF

function ScriptPostLoad()
    ctf = ObjectiveOneFlagCTF:New({ teamATT = 1, teamDEF = 2, textATT = "level.naboo2.1flag.att", textDEF = "level.naboo2.1flag.def", captureLimit = 5, flag = "flag", flagIcon = "flag_icon", flagIconScale = 3, homeRegion = "HomeRegion", captureRegionATT = "Team1Capture", captureRegionDEF = "Team2Capture", capRegionMarkerATT = "listbox_cursor", capRegionMarkerDEF = "listbox_cursor", capRegionMarkerScaleATT = 3, capRegionMarkerScaleDEF = 3 })
    ctf:Start()
    EnableSPHeroRules()
end

function ScriptInit()
    SetPS2ModelMemory(2500000)
    ReadDataFile("ingame.lvl")
    SetMaxFlyHeight(14)
    SetMaxPlayerFlyHeight(14)
    SetMaxFlyHeight(-17)
    ReadDataFile("sound\\yav.lvl;yav1cw")
    ReadDataFile("SIDE\\rep.lvl","rep_inf_ep2_rifleman","rep_inf_ep2_rocketeer","rep_inf_ep2_engineer","rep_inf_ep2_sniper","rep_inf_ep2_officer","rep_inf_ep2_jettrooper","rep_hero_macewindu","rep_hover_barcspeeder")
    ReadDataFile("SIDE\\cis.lvl","cis_inf_rifleman","cis_inf_rocketeer","cis_inf_engineer","cis_inf_sniper","cis_inf_officer","cis_inf_droideka","cis_hero_darthmaul","cis_hover_aat","cis_hover_stap")
    SetupTeams({ 
        rep =         { team = REP, units = 25, reinforcements = 200, 
          soldier =           { "rep_inf_ep2_rifleman", 11 }, 
          assault =           { "rep_inf_ep2_rocketeer", 4 }, 
          engineer =           { "rep_inf_ep2_engineer", 3 }, 
          sniper =           { "rep_inf_ep2_sniper", 2 }, 
          officer =           { "rep_inf_ep2_officer", 2 }, 
          special =           { "rep_inf_ep2_jettrooper", 3 }
         }, 
        cis =         { team = CIS, units = 25, reinforcements = 200, 
          soldier =           { "cis_inf_rifleman", 11 }, 
          assault =           { "cis_inf_rocketeer", 4 }, 
          engineer =           { "cis_inf_engineer", 3 }, 
          sniper =           { "cis_inf_sniper", 2 }, 
          officer =           { "cis_inf_officer", 2 }, 
          special =           { "cis_inf_droideka", 3 }
         }
       })
    SetHeroClass(CIS,"cis_hero_darthmaul")
    SetHeroClass(REP,"rep_hero_macewindu")
    AddWalkerType(0,3)
    AddWalkerType(1,0)
    AddWalkerType(2,0)
    AddWalkerType(3,0)
    SetMemoryPoolSize("Aimer",22)
    SetMemoryPoolSize("BaseHint",1000)
    SetMemoryPoolSize("EntityCarrier",0)
    SetMemoryPoolSize("EntityFlyer",0)
    SetMemoryPoolSize("EntityLight",40)
    SetMemoryPoolSize("FlagItem",2)
    SetMemoryPoolSize("MountedTurret",13)
    SetMemoryPoolSize("Obstacle",750)
    SetMemoryPoolSize("PassengerSlot",0)
    SetMemoryPoolSize("SoundSpaceRegion",48)
    SetMemoryPoolSize("TreeGridStack",500)
if ScriptCB_GetPlatform() == "PS2" then
        SetMemoryPoolSize("AmmoCounter",168)
        SetMemoryPoolSize("Combo::DamageSample",256)
        SetMemoryPoolSize("EnergyBar",168)
        SetMemoryPoolSize("EntityDroid",4)
        SetMemoryPoolSize("EntityMine",20)
        SetMemoryPoolSize("EntitySoundStream",4)
        SetMemoryPoolSize("EntitySoundStatic",20)
        SetMemoryPoolSize("Navigator",47)
        SetMemoryPoolSize("Ordnance",80)
        SetMemoryPoolSize("PathFollower",47)
        SetMemoryPoolSize("PathNode",256)
        SetMemoryPoolSize("UnitAgent",47)
        SetMemoryPoolSize("UnitController",47)
end
    SetMemoryPoolSize("Weapon",168)
    SetSpawnDelay(10,0.25)
    ReadDataFile("YAV\\yav1.lvl","Yavin1_CTF_CenterFlag")
    SetDenseEnvironment("false")
    SetNumBirdTypes(2)
    SetBirdType(0,1,"bird")
    SetBirdType(1,1.5,"bird2")
    SetNumFishTypes(1)
    SetFishType(0,0.80000001192093,"fish")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    voiceSlow = OpenAudioStream("sound\\global.lvl","rep_unit_vo_slow")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_slow",voiceSlow)
    AudioStreamAppendSegments("sound\\global.lvl","global_vo_slow",voiceSlow)
    voiceQuick = OpenAudioStream("sound\\global.lvl","rep_unit_vo_quick")
    AudioStreamAppendSegments("sound\\global.lvl","cis_unit_vo_quick",voiceQuick)
    OpenAudioStream("sound\\global.lvl","cw_music")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1")
    OpenAudioStream("sound\\yav.lvl","yav1_emt")
    SetOutOfBoundsVoiceOver(1,"cisleaving")
    SetOutOfBoundsVoiceOver(2,"repleaving")
    SetAmbientMusic(REP,1,"rep_yav_amb_start",0,1)
    SetAmbientMusic(REP,0.89999997615814,"rep_yav_amb_middle",1,1)
    SetAmbientMusic(REP,0.10000000149012,"rep_yav_amb_end",2,1)
    SetAmbientMusic(CIS,1,"cis_yav_amb_start",0,1)
    SetAmbientMusic(CIS,0.89999997615814,"cis_yav_amb_middle",1,1)
    SetAmbientMusic(CIS,0.10000000149012,"cis_yav_amb_end",2,1)
    SetVictoryMusic(REP,"rep_yav_amb_victory")
    SetDefeatMusic(REP,"rep_yav_amb_defeat")
    SetVictoryMusic(CIS,"cis_yav_amb_victory")
    SetDefeatMusic(CIS,"cis_yav_amb_defeat")
    SetSoundEffect("ScopeDisplayZoomIn","binocularzoomin")
    SetSoundEffect("ScopeDisplayZoomOut","binocularzoomout")
    SetSoundEffect("SpawnDisplayUnitChange","shell_select_unit")
    SetSoundEffect("SpawnDisplayUnitAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplaySpawnPointChange","shell_select_change")
    SetSoundEffect("SpawnDisplaySpawnPointAccept","shell_menu_enter")
    SetSoundEffect("SpawnDisplayBack","shell_menu_exit")
    SetAttackingTeam(ATT)
    AddCameraShot(0.92569398880005,-0.056832000613213,0.37327700853348,0.022917000576854,132.35606384277,-65.527252197266,-25.416561126709)
    AddCameraShot(0.36135500669479,-0.024311000481248,-0.93000900745392,-0.062568999826908,93.845817565918,-52.247051239014,-194.74313354492)
    AddCameraShot(0.93407398462296,0.077334001660347,-0.34741699695587,0.028764000162482,102.66004943848,-30.127220153809,-335.16714477539)
end

